# LimeControl Eco

Motyw ekologiczny: leśna zieleń, ciepłe papierowe tło, naturalne zaokrąglenia. Zgodny z WCAG 2.2 AA.

Motyw ankiety dla LimeSurvey 6.0+ (dziedziczy po wbudowanym motywie „fruity_twentythree”).
Wersja 1.0.0 · licencja GPL-2.0-or-later · https://limecontrol.eu/szablony.html

## Instalacja

1. Zaloguj się do LimeSurvey jako administrator.
2. Konfiguracja → Motywy → zakładka „Motywy ankiet” → przycisk „Importuj”.
3. Wskaż plik lc_eco.zip (nie zmieniaj jego nazwy) i kliknij „Importuj”.
4. Ankieta → Ustawienia → Ustawienia ogólne → Motyw: „LimeControl Eco” → Zapisz.

Instalacja ręczna (FTP/SSH): rozpakuj ZIP do katalogu upload/themes/survey/lc_eco/
(plik config.xml musi leżeć bezpośrednio w tym katalogu), a następnie w
Konfiguracja → Motywy kliknij „Zainstaluj” przy motywie.

## Dostosowanie

- Kolory i fonty: css/lc-theme.css (zmienne --lc-*).
- Logo: Motywy → LimeControl Eco → Opcje motywu → Obrazy → Logo: Tak (wgraj PNG/JPG).
- Własne poprawki CSS dodawaj w edytorze motywu do css/custom.css.

## Dostępność (WCAG 2.2 AA)

Kontrast tekstu >= 4.5:1, obramowań i fokusu >= 3:1, natywne pola wyboru
(tryb wysokiego kontrastu), cele dotykowe >= 44 px, link „Przejdź do pytań”,
błędy oznaczone kolorem, obramowaniem i tekstem, aria-invalid/aria-required,
obsługa prefers-reduced-motion i forced-colors.
