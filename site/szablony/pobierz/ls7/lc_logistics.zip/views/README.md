Views are inherited from the fruity_twentythree theme.
To override a view, copy its .twig file here from the parent theme (e.g. with the LimeSurvey theme editor).

Widoki są dziedziczone z motywu fruity_twentythree.
Aby nadpisać widok, skopiuj tu plik .twig z motywu bazowego (np. przez Edytor motywów w LimeSurvey).
