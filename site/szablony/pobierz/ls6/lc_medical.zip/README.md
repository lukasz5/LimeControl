# LimeControl Medical — LimeSurvey 6.x

Version 1.2.0 · GPL-2.0-or-later · https://limecontrol.eu/en/themes.html

- [English](#english)
- [Polski](#polski)

## English

A theme for healthcare surveys: a calm teal and blue palette, 18 px body text and large choice fields. WCAG 2.2 AA compliant.

A survey theme for LimeSurvey 6.x (it extends the built-in "fruity_twentythree" theme).
Tested on LimeSurvey 6.15.12. For the other LimeSurvey version download the other variant.

### Installation

1. Log in to LimeSurvey as an administrator.
2. Configuration → Themes → "Upload & install" (the "Survey themes" tab).
3. Choose lc_medical.zip (do not rename it) and confirm.
4. In a survey: Survey settings → General → Theme: "LimeControl Medical" → Save.

Manual installation (FTP/SSH): unpack the ZIP into upload/themes/survey/lc_medical/
(config.xml must sit directly in that directory), then click "Install" next to the theme
in Configuration → Themes.

### Customisation

- Colours and fonts: css/lc-theme.css (the --lc-* variables).
- Logo: in a survey, Theme options → Images → Logo: Yes (upload a PNG/JPG).
- Several logos in the header, a logo strip in the footer (e.g. partners or EU funding) and your brand
  colour: the free LimeControlBranding plugin — https://limecontrol.eu/en/themes.html#branding
- Your own CSS tweaks: Theme editor → css/custom.css.
- Interviewer instructions: give a question the CSS class "lc-interviewer"
  (Question settings → Display → CSS class) to highlight it as a script or an interviewer-only field.

### Accessibility (WCAG 2.2 AA)

Text contrast >= 4.5:1, borders and focus >= 3:1, native form controls (high-contrast mode),
touch targets >= 44 px, a "Skip to questions" link, errors marked with colour, border and text,
aria-invalid/aria-required, on-page validation messages, prefers-reduced-motion and forced-colors support.

## Polski

Motyw dla ankiet medycznych: spokojna paleta turkusowo-niebieska, tekst bazowy 18 px, duże pola wyboru. Zgodny z WCAG 2.2 AA.

Motyw ankiety dla LimeSurvey 6.x (dziedziczy po wbudowanym motywie „fruity_twentythree”).
Przetestowano na LimeSurvey 6.15.12. Dla drugiej wersji LimeSurvey pobierz drugi wariant:
https://limecontrol.eu/szablony.html

### Instalacja

1. Zaloguj się do LimeSurvey jako administrator.
2. Konfiguracja → Motywy → przycisk „Prześlij i zainstaluj” (zakładka „Motywy ankiet”).
3. Wskaż plik lc_medical.zip (nie zmieniaj jego nazwy) i potwierdź.
4. W ankiecie: Ustawienia ankiety → Ogólne → Motyw: „LimeControl Medical” → Zapisz.

Instalacja ręczna (FTP/SSH): rozpakuj ZIP do katalogu upload/themes/survey/lc_medical/
(plik config.xml musi leżeć bezpośrednio w tym katalogu), a następnie w
Konfiguracja → Motywy kliknij „Zainstaluj” przy motywie.

### Dostosowanie

- Kolory i fonty: css/lc-theme.css (zmienne --lc-*).
- Logo: w ankiecie Opcje motywu → Obrazy → Logo: Tak (wgraj PNG/JPG).
- Kilka logotypów w nagłówku, pasek logotypów w stopce (np. partnerzy, fundusze UE) i kolor marki:
  darmowa wtyczka LimeControlBranding — https://limecontrol.eu/szablony.html#branding
- Własne poprawki CSS: Edytor motywów → css/custom.css.
- Wskazówki dla ankietera: nadaj pytaniu klasę CSS „lc-interviewer”
  (Ustawienia pytania → Wyświetlanie → Klasa CSS), aby wyróżnić je jako skrypt lub pole ankietera.

### Dostępność (WCAG 2.2 AA)

Kontrast tekstu >= 4.5:1, obramowań i fokusu >= 3:1, natywne pola wyboru
(tryb wysokiego kontrastu), cele dotykowe >= 44 px, link „Przejdź do pytań”,
błędy oznaczone kolorem, obramowaniem i tekstem, aria-invalid/aria-required,
komunikaty walidacji na stronie, obsługa prefers-reduced-motion i forced-colors.
