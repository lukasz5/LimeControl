Widoki są dziedziczone z motywu fruity_twentythree.
Aby nadpisać widok, skopiuj tu plik .twig z motywu bazowego (np. przez Edytor motywów w LimeSurvey).
