# LimeControl Professional — LimeSurvey 6.x

Motyw biznesowy: granatowa paleta, nagłówki szeryfowe, wąskie zaokrąglenia. Zgodny z WCAG 2.2 AA.

Motyw ankiety dla LimeSurvey 6.x (dziedziczy po wbudowanym motywie „fruity_twentythree”).
Przetestowano na LimeSurvey 6.15.12. Dla drugiej wersji LimeSurvey pobierz drugi wariant:
https://limecontrol.eu/szablony.html
Wersja 1.0.0 · licencja GPL-2.0-or-later

## Instalacja

1. Zaloguj się do LimeSurvey jako administrator.
2. Konfiguracja → Motywy → przycisk „Prześlij i zainstaluj” (zakładka „Motywy ankiet”).
3. Wskaż plik lc_professional.zip (nie zmieniaj jego nazwy) i potwierdź.
4. W ankiecie: Ustawienia ankiety → Ogólne → Motyw: „LimeControl Professional” → Zapisz.

Instalacja ręczna (FTP/SSH): rozpakuj ZIP do katalogu upload/themes/survey/lc_professional/
(plik config.xml musi leżeć bezpośrednio w tym katalogu), a następnie w
Konfiguracja → Motywy kliknij „Zainstaluj” przy motywie.

## Dostosowanie

- Kolory i fonty: css/lc-theme.css (zmienne --lc-*).
- Logo: w ankiecie Opcje motywu → Obrazy → Logo: Tak (wgraj PNG/JPG).
- Własne poprawki CSS: Edytor motywów → css/custom.css.

## Dostępność (WCAG 2.2 AA)

Kontrast tekstu >= 4.5:1, obramowań i fokusu >= 3:1, natywne pola wyboru
(tryb wysokiego kontrastu), cele dotykowe >= 44 px, link „Przejdź do pytań”,
błędy oznaczone kolorem, obramowaniem i tekstem, aria-invalid/aria-required,
komunikaty walidacji na stronie, obsługa prefers-reduced-motion i forced-colors.
