<?php
// SPDX-License-Identifier: GPL-2.0-or-later
// Reproducible excerpt of the 2018 selection and 2024 verification bundled with this release.
$selectionFile = dirname(__DIR__) . '/data/design-selection.json';
$evidence = is_file($selectionFile) ? json_decode(file_get_contents($selectionFile), true) : null;
if (empty($evidence['plans'])) {
    return;
}
$roles = [
    'coverage' => 'Pokrycie bliskie 95%',
    'limited' => 'Ograniczona obsada',
    'joint' => 'Najczęściej wyznaczony i trafny przedział',
];
$designs = [];
foreach ($evidence['plans'] as $planRow) {
    $key = $planRow['n'] . '/' . $planRow['k'];
    $designs[$key]['labels'][] = $roles[$planRow['role']];
    $designs[$key]['plan'] = $planRow;
}
?>
<details class="ep-section">
    <summary>Jak dobrać liczbę obwodów i krok?</summary>
    <p>Porównaliśmy 16 planów na wynikach wyborów do sejmików. Każdy plan sprawdziliśmy w 85 okręgach, po <?= (int) $evidence['repetitions'] ?> losowań na okręg i rok. Poniższe scenariusze zakładają, że każda zaproszona osoba odpowiada z prawdopodobieństwem 80%, niezależnie od oddanego głosu.</p>
    <p>Plany wybrano na danych z 2018 r. Za bliskie nominalnemu poziomowi przyjęto pokrycie od 94% do 96% wśród wyznaczonych przedziałów. Jeśli żaden plan w rozpatrywanej grupie nie osiągał tego zakresu, wybierano najbliższy. Wariant z ograniczoną obsadą dopuszczał najwyżej cztery obwody na warstwę i krok równy 5 lub 10. W 2024 r. sprawdzono te same plany.</p>
    <div class="ep-scroll" role="region" tabindex="0" aria-label="Porównanie planów exit poll">
        <table class="table ep-table">
            <caption>Symulacja na ważnych głosach w okręgach sejmikowych</caption>
            <thead><tr><th scope="col">Cel doboru</th><th scope="col">Obwody na warstwę</th><th scope="col">Krok</th><th scope="col">Rok</th><th scope="col">Pokrycie wyznaczonych</th><th scope="col">Wyznaczone / planowane</th><th scope="col">Wyznaczone i trafne / planowane</th><th scope="col">Śr. obwody / okręg</th><th scope="col">Śr. zaproszenia / okręg</th></tr></thead>
            <tbody>
            <?php foreach ($designs as $design):
                $planRow = $design['plan'];
                foreach ([$evidence['basis_year'], $evidence['validation_year']] as $year):
                    $data = $planRow['years'][$year]; ?>
                    <tr><th scope="row"><?= $h(implode(' · ', $design['labels'])) ?></th>
                        <td><?= (int) $planRow['n'] ?></td><td><?= (int) $planRow['k'] ?></td><td><?= (int) $year ?></td>
                        <?php foreach (['conditional', 'available', 'joint'] as $metric): ?><td><?= number_format($data[$metric], 2, ',', ' ') ?>%</td><?php endforeach; ?>
                        <td><?= number_format($data['stations'], 1, ',', ' ') ?></td><td><?= number_format($data['invited'], 0, ',', ' ') ?></td>
                    </tr>
                <?php endforeach;
            endforeach; ?>
            </tbody>
        </table>
    </div>
    <p>Warstwą w tym porównaniu był powiat lub jego część w okręgu. Przy innym operacie albo odmowach zależnych od preferencji pokrycie może być inne. Krok 1 oznacza zaproszenie każdej wychodzącej osoby.</p>
</details>
