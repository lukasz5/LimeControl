<?php
// SPDX-License-Identifier: GPL-2.0-or-later
$year = (int) $model['year'];
$organ = $model['organ'] ?? 'sejmik';
?>
<nav class="ep-actions" aria-label="Rodzaj wyborów">
    <?php foreach (LcepLocalArchive::ORGANS as $key => $label):
        $supported = $key === 'sejmik' ? LcepPkwCatalog::years() : LcepLocalArchive::years($key);
        $targetYear = in_array($year, $supported, true) ? $year : max($supported);
    ?>
        <a class="ep-year" href="<?= $h($url(['tab'=>'history','year'=>$targetYear,'organ'=>$key])) ?>"<?= $key === $organ ? ' aria-current="page"' : '' ?>><?= $h($label) ?></a>
    <?php endforeach; ?>
</nav>
<?php
if ($organ !== 'sejmik') {
    require __DIR__ . '/localHistory.php';
    return;
}
$area = $model['area'] ?? null;
$meta = $model['metadata'] ?? [];
$levels = ['kraj' => 'Kraj', 'wojewodztwo' => 'Województwo', 'powiat' => 'Powiat lub miasto na prawach powiatu', 'gmina' => 'Gmina', 'obwod' => 'Obwód', 'okreg' => 'Okręg', 'dzielnica' => 'Dzielnica'];
$historyUrl = static function ($y, $code) use ($url) {
    return $url(['tab' => 'history', 'year' => $y, 'area' => $code]);
};
?>
<p>Oficjalne wyniki wyborów do sejmików województw.</p>
<nav class="ep-actions" aria-label="Rok wyborów"><strong>Wybory</strong>
    <?php foreach ($model['years'] as $y):
        $currentYear = (int) $y === $year;
        $yearArea = $currentYear && $area ? $area['code'] : ($model['yearAreas'][$y] ?? 'PL');
    ?>
        <a class="ep-year" href="<?= $h($historyUrl($y, $yearArea)) ?>"<?= $currentYear ? ' aria-current="page"' : '' ?>><?= $h($y) ?></a>
    <?php endforeach; ?>
</nav>
<?php if ($area && $area['code'] !== 'PL'): ?>
    <p class="ep-help">Przy zmianie roku wyszukujemy ten sam kod jednostki administracyjnej. Jej granice mogły się zmienić. Dla obwodów, okręgów i kodów nieobecnych w danym roczniku otwiera się wynik Polski.</p>
<?php endif; ?>
<?php if (!$area): ?>
    <p class="ep-section">Brak danych dla wybranego obszaru i roku. <a href="<?= $h($historyUrl($year, 'PL')) ?>">Przejdź do wyniku Polski</a>.</p>
<?php else:
    $valid = $area['valid_votes'];
?>
    <section class="ep-section">
        <?php if (!empty($area['parent'])): ?>
            <nav class="ep-actions" aria-label="Poziom terytorialny">
                <a href="<?= $h($historyUrl($year, 'PL')) ?>">Polska</a>
                <?php if ($area['parent'] !== 'PL'): ?><a href="<?= $h($historyUrl($year, $area['parent'])) ?>">Obszar nadrzędny</a><?php endif; ?>
            </nav>
        <?php endif; ?>
        <h2><?= $h($area['name']) ?></h2>
        <?php if ($canEdit && in_array($area['level'], ['kraj', 'wojewodztwo', 'powiat', 'gmina'], true)): ?>
            <p><a href="<?= $h($url(['tab' => 'setup', 'scope' => $area['code']])) ?>">Użyj tego obszaru w ustawieniach fal</a></p>
        <?php endif; ?>
        <dl class="ep-facts">
            <div><dt>Głosy ważne</dt><dd class="ep-total"><?= $h($number($valid)) ?></dd></div>
            <div><dt>Poziom wyniku</dt><dd><?= $h($levels[$area['level']] ?? $area['level']) ?></dd></div>
            <?php if (!empty($meta['date'])): ?><div><dt>Data głosowania</dt><dd><?= $h($date($meta['date'])) ?></dd></div><?php endif; ?>
        </dl>
        <div class="ep-scroll" tabindex="0" role="region" aria-label="Tabela głosów na komitety">
            <table class="table ep-table">
                <caption>Wyniki komitetów w <?= $year ?> r.</caption>
                <thead><tr><th scope="col">Komitet</th><th scope="col" class="ep-num">Głosy</th><th scope="col" class="ep-num">Udział w ważnych</th></tr></thead>
                <tbody>
                <?php foreach ($area['committees'] as $committee): ?>
                    <tr><th scope="row"><?= $h($committee['name']) ?>
                        <?php if (isset($committee['list_number'])): ?>
                            <small>Lista nr <?= $h($committee['list_number']) ?></small>
                        <?php elseif (isset($committee['covered_districts'], $area['district_count'])): ?>
                            <small>Lista zarejestrowana w <?= $h($number($committee['covered_districts'])) ?> z <?= $h($number($area['district_count'])) ?> okręgów</small>
                        <?php endif; ?>
                    </th><td class="ep-num"><?= $h($number($committee['votes'])) ?></td>
                        <td class="ep-num"><?= $valid > 0 ? $h($number(100 * $committee['votes'] / $valid, 2)) . '%' : '—' ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
    <?php if ($area['level'] === 'okreg' && !empty($model['ballotUrls'][1]) && !empty($model['ballotUrls'][2])): ?>
        <section class="ep-section">
            <h2>Ankiety dla tego okręgu</h2>
            <p>Obie ankiety odtwarzają na potrzeby badania wybór spośród list zarejestrowanych w tym okręgu w <?= $year ?> r. Każdy plik LSS zaimportuj do LimeSurvey jako osobną ankietę.</p>
            <div class="ep-actions">
                <?php foreach ([1, 2] as $wave): ?>
                    <a class="btn" href="<?= $h($model['ballotUrls'][$wave]) ?>">Pobierz falę <?= $wave ?> (LSS)</a>
                <?php endforeach; ?>
                <?php if (!empty($model['exitPresetUrl'])): ?><a class="btn" href="<?= $h($model['exitPresetUrl']) ?>">Przygotuj exit poll dla tej karty</a><?php endif; ?>
            </div>
        </section>
    <?php endif; ?>
    <?php foreach (['children' => 'Jednostki w tym obszarze', 'districts' => 'Okręgi wyborcze'] as $group => $heading):
        if (empty($area[$group])) { continue; }
    ?>
        <section class="ep-section">
            <h2><?= $h($heading) ?></h2>
            <ul class="ep-links">
                <?php foreach ($area[$group] as $child): ?>
                    <li><a href="<?= $h($historyUrl($year, $child['code'])) ?>"><?= $h($child['name']) ?></a></li>
                <?php endforeach; ?>
            </ul>
        </section>
    <?php endforeach; ?>
    <?php if (!empty($meta['source_page'])): ?>
        <details class="ep-section ep-source"><summary>Pochodzenie danych</summary>
            <p><a href="<?= $h($meta['source_page']) ?>" rel="noreferrer">Krajowe Biuro Wyborcze · wybory samorządowe <?= $year ?></a></p>
            <?php if (!empty($meta['source_url'])): ?><p><a href="<?= $h($meta['source_url']) ?>" rel="noreferrer">Pobierz oryginalny plik wyborczy</a></p><?php endif; ?>
            <?php if (!empty($meta['sha256'])): ?><p>Suma SHA-256 źródła <code><?= $h($meta['sha256']) ?></code></p><?php endif; ?>
        </details>
    <?php endif; ?>
<?php endif; ?>
