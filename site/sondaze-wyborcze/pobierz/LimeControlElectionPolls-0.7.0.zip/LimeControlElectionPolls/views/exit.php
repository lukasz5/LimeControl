<?php
// SPDX-License-Identifier: GPL-2.0-or-later
$h = static function ($v) { return htmlspecialchars(is_scalar($v) ? (string)$v : '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); };
$url = static function ($action, array $args = []) use ($sid, $h) { return $h(LcepAdmin::url($sid, $action, $args)); };
$csrf = '<input type="hidden" name="' . $h($request->csrfTokenName) . '" value="' . $h($request->csrfToken) . '">';
$interviews = ['invited'=>'Zaproszeni ogółem','refused'=>'Odmówili udziału','missed'=>'Pominięci mimo wskazania przez krok',
    'invalid'=>'Zadeklarowali nieważny głos','no_ballot'=>'Nie pobrali tej karty','declined'=>'Przyjęli ankietę i odmówili ujawnienia wyboru'];
$percent = static function ($v) {return number_format($v, 1, ',', ' ') . '%';};
$stepModes = ['fixed'=>'Stały krok w całym badaniu', 'size'=>'Krok proporcjonalny do wielkości obwodu', 'size_small'=>'Mniejszy krok w małych obwodach'];
?><!doctype html><html lang="pl" data-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow">
<title>Exit poll · LimeControl</title><link rel="stylesheet" href="<?= $h($assets) ?>/components.css"><link rel="stylesheet" href="<?= $h($assets) ?>/panel.css"></head>
<body><a class="ep-skip" href="#ep-main">Przejdź do treści</a>
<header class="ep-header"><div class="ep-shell ep-masthead"><strong>Exit poll</strong><a href="<?= $h(App()->createUrl('surveyAdministration/view',['surveyid'=>$sid])) ?>">Wróć do ankiety</a></div></header>
<main class="ep-shell" id="ep-main"><h1><?= $h($plan['title'] ?? 'Nowy exit poll') ?></h1>
<?php if ($error): ?><p class="alert alert-error" role="alert"><?= $h($error) ?></p><?php endif; ?>
<?php if ($notice): ?><p class="alert alert-success" role="status"><?= $h($notice) ?></p><?php endif; ?>
<?php if (!$project && $manage): ?>
<p>Projekt obejmuje jedną kartę i turę wyborów. Wczytaj kartę i historyczny operat z archiwum PKW lub wpisz zweryfikowane dane planowanego badania.</p>
<p><a href="<?= $url('panel',['tab'=>'history']) ?>">Przejdź do archiwum wyborów</a></p>
<form class="ep-section" action="<?= $url('exitCreate') ?>" method="post"><?= $csrf ?>
<h2>Populacja i karta</h2><div class="ep-grid">
<label class="ep-field">Nazwa badania, organ i tura<input class="input" name="title" maxlength="200" required value="<?= $h($draft['title'] ?? '') ?>"></label>
<label class="ep-field">Data głosowania<input class="input" type="date" name="date" required value="<?= $h($draft['date'] ?? '') ?>"></label>
<label class="ep-field">Źródło i wersja operatu<input class="input" name="source" maxlength="600" required value="<?= $h($draft['source'] ?? '') ?>"></label></div>
<label class="ep-field">Populacja badana i wyłączenia<textarea class="textarea" name="scope" required rows="3" maxlength="1000"><?= $h($draft['scope'] ?? '') ?></textarea></label>
<p class="ep-help">Opisz zwykłe i odrębne obwody, głosowanie korespondencyjne i przez pełnomocnika. Sprawdź granice, listę opcji i możliwość objęcia wszystkich wyjść.</p>
<label class="ep-field">Opcje na karcie, po jednej w każdym wierszu<textarea class="textarea" name="options_text" required rows="6" placeholder="A;Lista A"><?= $h($draft['options_text'] ?? '') ?></textarea></label>
<p class="ep-help">Wiersz zawiera kod i etykietę rozdzielone średnikiem. Dla głosowania nad jednym kandydatem wpisz osobne opcje TAK i NIE.</p>
<label class="ep-field">Operat obwodów<textarea class="textarea" name="frame_text" required rows="7" placeholder="MIASTO;O:146501:1;Obwód nr 1"><?= $h($draft['frame_text'] ?? '') ?></textarea></label>
<p class="ep-help">Jeden wiersz na obwód. Podaj kod warstwy, unikalny kod punktu i jego nazwę, oddzielone średnikami. Dobór prowadź tylko dla jednej zgodnej karty. Uwzględnij odrębne strumienie osób, gdy w budynku pracuje kilka komisji.</p>
<h2>Dobór i zmiany</h2><div class="ep-grid">
<label class="ep-field">Liczba obwodów z każdej warstwy<input class="input" type="number" min="1" max="2000" name="per_stratum" required value="<?= $h($draft['per_stratum'] ?? 2) ?>"></label>
<label class="ep-field">Sposób doboru kroku<select class="select" name="step_mode"><?php foreach ($stepModes as $key=>$label): ?><option value="<?= $key ?>"<?= ($draft['step_mode'] ?? 'fixed') === $key ? ' selected' : '' ?>><?= $h($label) ?></option><?php endforeach; ?></select></label>
<label class="ep-field">Krok odniesienia (k)<input class="input" type="number" min="1" max="1000" name="step" required value="<?= $h($draft['step'] ?? 5) ?>"></label>
<?php foreach (['opening'=>['Otwarcie','07:00'],'change'=>['Zmiana obsady','14:00'],'closing'=>['Planowane zakończenie','21:00']] as $key=>[$label,$default]): ?>
<label class="ep-field"><?= $h($label) ?><input class="input" type="time" name="<?= $key ?>" required value="<?= $h($draft[$key] ?? $default) ?>"></label><?php endforeach; ?>
<label class="ep-field">Ziarno dla odtworzenia losowania (opcjonalnie)<input class="input" name="seed" maxlength="64" value="<?= $h($draft['seed'] ?? '') ?>"></label></div>
<p>Przy stałym kroku 5 ankieter zaprasza co piątą osobę. Przy zmiennym kroku ta wartość wyznacza łączny planowany nakład. W mniejszych obwodach ankieter zaprasza osoby częściej. Wariant dla małych obwodów stosuje wspólny krok od jednej czwartej średniej wielkości obwodu wzwyż.</p>
<details class="ep-section"<?= in_array($draft['step_mode'] ?? '', ['size','size_small'], true) ? ' open' : '' ?>><summary>Wielkości obwodów do planowania zmiennego kroku</summary>
<label class="ep-field">Źródło i data danych o wielkości<input class="input" name="size_source" maxlength="600" value="<?= $h($draft['size_source'] ?? '') ?>"></label>
<label class="ep-field">Kod obwodu i jego wielkość<textarea class="textarea" name="sizes_text" rows="6" placeholder="O:146501:1;950"><?= $h($draft['sizes_text'] ?? '') ?></textarea></label>
<p class="ep-help">Przed losowaniem podaj wielkość każdego obwodu z operatu, po jednym wierszu w formacie kod;liczba. Użyj tej samej miary dla całego obszaru, np. liczby zarejestrowanych wyborców według stanu z jednego dnia. Wpisz zero jedynie wtedy, gdy źródło rzeczywiście podaje zero. Przy stałym kroku te pola są opcjonalne.</p></details>
<p>W każdej warstwie losowane są obwody bez zwracania, z jednakowym prawdopodobieństwem. Gdy żądana liczba przekracza wielkość warstwy, wchodzą wszystkie obwody. Aby wyznaczyć przedział ufności, w każdej warstwie obejmij wszystkie obwody albo wylosuj co najmniej dwa. Puste pole ziarna oznacza losowanie przez serwer. Zapis utrwala operat i dobór dla tej ankiety.</p>
<?php require __DIR__ . '/exitAdaptiveEvidence.php'; ?>
<?php require __DIR__ . '/exitDesignEvidence.php'; ?>
<button class="btn btn-primary" type="submit">Zapisz projekt i wylosuj obwody</button></form>
<?php elseif (!$project): ?><p>Koordynator może utworzyć projekt i przydzielić punkty.</p>
<?php else: ?>
<p><?= $h($plan['date']) ?> · <?= $closed ? 'Teren zamknięty' : 'Realizacja terenowa' ?></p>
<details class="ep-section"><summary>Operat, źródło i dobór próby</summary><p><?= $h($plan['scope']) ?></p><p>Źródło: <?= $h($plan['source']) ?></p>
<p><?= $h($stepModes[$plan['step_mode'] ?? 'fixed']) ?>. Krok odniesienia wynosi <?= (int)$plan['step'] ?>.</p>
<?php if (!empty($plan['size_source'])): ?><p>Wielkości obwodów pochodzą ze źródła „<?= $h($plan['size_source']) ?>”.</p><?php endif; ?>
<p>Liczba obwodów w operacie: <?= count($plan['frame']) ?>. Ziarno: <code><?= $h($plan['seed']) ?></code>. Algorytm: <code><?= $h($plan['algorithm']) ?></code>.</p><p class="ep-source">SHA-256 operatu: <code><?= $h($plan['frame_hash']) ?></code></p>
<table class="table ep-table"><thead><tr><th>Warstwa</th><th>W operacie</th><th>W próbie</th><th>Szansa wyboru</th></tr></thead><tbody>
<?php foreach ($plan['strata'] as $key=>$stratum): ?><tr><td><?= $h($key) ?></td><td><?= $stratum['total'] ?></td><td><?= $stratum['sample'] ?></td><td><?= $percent(100*$stratum['sample']/$stratum['total']) ?></td></tr><?php endforeach; ?>
</tbody></table></details>
<section class="ep-section"><h2>Praca terenowa</h2>
<p>Odszukaj obwód i zmianę w tabeli. Po wyjściu z lokalu zaproś osobę o wylosowanym numerze, a kolejne zgodnie z krokiem przypisanym do tego obwodu. Krok 1 oznacza zapraszanie każdej osoby. Po odmowie kontynuuj liczenie. Zapewnij prywatne wypełnienie ankiety i odnotuj przerwy w obsadzie.</p>
<p><a href="<?= $url('exitPoll',['paper'=>1]) ?>">Otwórz anonimową kartę do wydruku</a></p>
<p>Rozliczone zmiany: <?= count($batches) ?> z <?= 2*count($plan['points']) ?>.</p>
<div class="ep-scroll" tabindex="0" role="region" aria-label="Wylosowane obwody i zmiany"><table class="table ep-table"><thead><tr><th scope="col">Punkt</th><th scope="col">Warstwa</th><th scope="col">Krok w obwodzie</th><th scope="col">Zmiana 1 (<?= $h($plan['opening'].'–'.$plan['change']) ?>)</th><th scope="col">Zmiana 2 (<?= $h($plan['change'].'–'.$plan['closing']) ?>)</th></tr></thead><tbody>
<?php foreach ($plan['points'] as $code=>$item): ?><tr><th scope="row"><?= $h($item['label']) ?><small><?= $h($code) ?></small></th><td><?= $h($item['stratum']) ?></td><td><?= (int)LcepExitStep::forPoint($plan, $item) ?></td>
<?php foreach ([1,2] as $n): $b=$byPoint[$code][$n] ?? null; ?><td>Start od osoby nr <?= $item['starts'][$n] ?>. <?= $b ? 'Zapisano zmianę' : 'Oczekuje' ?>.
<?php if ($b): ?><small>Zaproszenia <?= $b['invited'] ?> · ukończenia <?= $b['completed'] ?> · odmowy <?= $b['refused'] ?> · pominięcia <?= $b['missed'] ?></small><?php if ($b['interruption'] !== ''): ?><small><?= $h($b['interruption']) ?></small><?php endif; ?><?php endif; ?>
<?php if (!$closed && $field && (!$b || $manage)): ?><a href="<?= $url('exitPoll',['point'=>$code,'shift'=>$n]) ?>#entry"><?= $b ? 'Skoryguj' : 'Rozlicz' ?> zmianę <?= $n ?></a><?php endif; ?>
</td><?php endforeach; ?></tr><?php endforeach; ?>
</tbody></table></div></section>
<?php if (!$closed && $field && $point !== ''): $current = $byPoint[$point][$shift] ?? null;
if (!$current || $manage): $entry = $action === 'exitBatch' ? $draft : []; ?>
<form class="ep-section" id="entry" action="<?= $url('exitBatch') ?>" method="post"><?= $csrf ?><h2>Paczka terenowa</h2>
<p><?= $h($plan['points'][$point]['label']) ?> · <?= $h($point) ?> · zmiana <?= $shift ?>. Rozlicz wszystkie ankiety i odmowy z jednej zmiany w tym obwodzie.</p>
<p>Start od osoby nr <?= (int)$plan['points'][$point]['starts'][$shift] ?>. Krok w tym obwodzie wynosi <?= (int)LcepExitStep::forPoint($plan, $plan['points'][$point]) ?>.</p>
<input type="hidden" name="point" value="<?= $h($point) ?>"><input type="hidden" name="shift" value="<?= $shift ?>">
<?php if ($current): ?><input type="hidden" name="previous" value="<?= $h($entry['previous'] ?? $current['fingerprint']) ?>"><p>Korekta zastępuje cały zapis tej zmiany. Podaj ponownie wszystkie liczniki z paczki.</p><?php endif; ?>
<label class="ep-field">Numer paczki<input class="input" name="batch_id" required maxlength="56" value="<?= $h($entry['batch_id'] ?? ($current['batch_id'] ?? '')) ?>"></label>
<div class="ep-grid"><?php foreach ($interviews as $key=>$label): ?><label class="ep-field"><?= $h($label) ?><input class="input" type="number" min="0" max="999999" name="<?= $key ?>" required value="<?= $h($entry[$key] ?? ($current ? '' : 0)) ?>"></label><?php endforeach; ?></div>
<fieldset class="fieldset ep-fieldset"><legend class="fieldset-legend">Deklarowane głosy ważne</legend><div class="ep-grid"><?php foreach ($plan['options'] as $key=>$name): ?><label class="ep-field"><?= $h($name) ?><input class="input" type="number" min="0" max="999999" required name="votes[<?= $h($key) ?>]" value="<?= $h($entry['votes'][$key] ?? ($current ? '' : 0)) ?>"></label><?php endforeach; ?></div></fieldset>
<label class="ep-field">Przerwy i odstępstwa od planu<textarea class="textarea" name="interruption" maxlength="600"><?= $h($entry['interruption'] ?? '') ?></textarea></label>
<button class="btn btn-primary" type="submit">Zapisz paczkę</button></form>
<?php endif; endif; ?>
<?php if (!$closed && $manage): ?>
<form class="ep-section" action="<?= $url('exitFreeze') ?>" method="post"><?= $csrf ?><h2>Zamknięcie terenu</h2>
<p>Zamrożenie utrwala uzgodnione paczki i otwiera prywatny raport dla osób z prawem odczytu. Zaczekaj na rzeczywiste zakończenie głosowania, także przy jego przedłużeniu.</p>
<label class="ep-field">Podstawa potwierdzenia zakończenia głosowania<input class="input" name="source" maxlength="600" required></label>
<label><input type="checkbox" name="confirmation" value="1" required> Potwierdzam zakończenie głosowania i kompletność rozliczeń terenowych.</label>
<p><button class="btn" type="submit">Zamroź exit poll</button></p></form>
<?php elseif (!$closed): ?><p>Wyniki preferencji pozostają zablokowane do zamknięcia terenu.</p><?php endif; ?>
<?php if ($closed && $canRead): ?>
<section class="ep-section"><h2>Raport prywatny</h2><p>Stan exit poll zamrożony <?= $h($project['closed']) ?> (UTC). Potwierdzenie: <?= $h($project['source']) ?>.</p>
<?php foreach (['Exit poll'=>$exit,'Late poll'=>$late] as $kind=>$result): if (!$result) {continue;} ?>
<h3><?= $kind ?></h3>
<?php if ($result['status'] === 'ready'): ?>
<div class="ep-scroll" role="region" tabindex="0" aria-label="<?= $h('Udziały opcji · ' . $kind) ?>">
<table class="table ep-table"><thead><tr>
    <th scope="col">Ważne wskazanie</th><th scope="col">Szacowany udział</th>
    <?php if ($kind === 'Exit poll'): ?><th scope="col">95% przedział ufności</th><?php endif; ?>
</tr></thead><tbody>
<?php foreach ($result['shares'] as $c=>$share): ?>
<tr><th scope="row"><?= $h($plan['options'][$c]) ?></th>
    <td><?= $percent($share) ?> <meter min="0" max="100" value="<?= $h($share) ?>" aria-label="<?= $h($plan['options'][$c]) ?>"></meter></td>
    <?php if ($kind === 'Exit poll'): $interval = $result['intervals'][$c] ?? null; ?>
    <td><?php if ($interval && $interval['status'] === 'census'): ?>
        <?= $percent($share) ?> · pełne zliczenie w operacie
    <?php elseif ($interval): ?>
        <?= $percent(floor(10 * $interval['lower']) / 10) ?> – <?= $percent(ceil(10 * $interval['upper']) / 10) ?>
    <?php else: ?>
        <?= $h($result['interval_reasons'][$c] ?? 'Niedostępny') ?>
    <?php endif; ?></td>
    <?php endif; ?>
</tr>
<?php endforeach; ?></tbody></table></div>
<?php if ($kind === 'Exit poll'): ?>
    <?php if (!empty($result['interval_note'])): ?><p><?= $h($result['interval_note']) ?></p><?php endif; ?>
    <?php if (!empty($result['intervals'])): ?>
    <p>Poziom 95% dotyczy każdej opcji oddzielnie. Przedział uwzględnia losowanie obwodów w warstwach i przybliża zmienność doboru osób na obu zmianach. Interpretacja zakłada losową kolejność wychodzących oraz podobne preferencje osób z odpowiedzią i bez niej w danej zmianie. Braki w operacie i systematyczne różnice w odpowiedziach mogą przesunąć wynik poza przedział.</p>
    <details><summary>Jak często przedziały obejmowały wynik PKW w symulacji?</summary>
        <p>W wyborach do sejmików z 2024 r. powtórzyliśmy losowanie 300 razy dla każdego z 85 okręgów. Przy czterech obwodach na warstwę, doborze co piątej osoby i pełnej odpowiedzi oficjalny wynik listy znalazł się w 99 415 ze 106 503 wyznaczonych przedziałów (93,34%). Plan obejmował 211 800 przedziałów. Przy symulowanych odpowiedziach 60% wśród wyborców prowadzącej listy i 85% wśród pozostałych pokrycie wyznaczonych przedziałów spadło do 79,75%.</p>
    </details>
    <?php endif; ?>
<?php endif; ?>
<?php else: ?><p><?= $h($result['note']) ?></p><?php endif; ?>
<?php if ($kind==='Late poll'): ?><p>Zweryfikowane protokoły: <?= $result['protocol_count'] ?> z <?= $result['sample_points'] ?> wylosowanych punktów, obejmują <?= $result['official_valid'] ?> oficjalnych głosów ważnych.<?php if ($result['estimated_official_share']!==null): ?> Udział źródła protokolarnego w ważonej sumie: <?= $percent($result['estimated_official_share']) ?>.<?php endif; ?></p><?php endif; ?>
<?php endforeach; ?>
<?php if ($sensitivity): ?>
<h3>Wrażliwość na odmowy udziału</h3>
<?php if ($sensitivity['status'] === 'ready'): ?>
<p>Jak zmieniłby się wynik, gdyby osoby odmawiające udziału częściej lub rzadziej wybierały daną opcję? W modelu przypada na nie <?= $percent($sensitivity['refusal_share_percent']) ?> ważnych wskazań po uwzględnieniu wag.</p>
<div class="ep-scroll" role="region" tabindex="0" aria-label="Scenariusze odmów udziału">
<table class="table ep-table"><caption>Udział opcji w całym badaniu przy zmianie jej szansy wśród odmawiających</caption>
<thead><tr><th scope="col">Opcja</th>
<?php foreach (LcepExitSensitivity::ODDS_MULTIPLIERS as $odds): ?>
    <th scope="col"><?= $h(str_replace('.', ',', (string)$odds)) ?> ×<?= $odds === 1.0 ? ' (exit poll)' : '' ?></th>
<?php endforeach; ?></tr></thead><tbody>
<?php foreach ($sensitivity['shares'] as $code => $scenarios): ?>
<tr><th scope="row"><?= $h($plan['options'][$code]) ?></th>
<?php foreach ($scenarios as $share): ?><td><?= $percent($share) ?></td><?php endforeach; ?></tr>
<?php endforeach; ?></tbody></table></div>
<p>Wartość 1 × odtwarza zamrożony exit poll. Szansa oznacza stosunek udziału opcji do udziału wszystkich pozostałych, czyli p/(1 − p). Wartość 2 × podwaja tę szansę u odmawiających względem założenia bazowego. Każdy wiersz opisuje osobny scenariusz dla jednej opcji wobec reszty. Udziały z różnych wierszy w kolumnie scenariuszowej mogą więc sumować się do wartości innej niż 100%.</p>
<details><summary>Założenia analizy odmów</summary>
<p>W każdej zmianie odsetek odmawiających, którym przypisujemy ważne wskazanie, odpowiada odsetkowi ujawnionych ważnych wskazań w ukończonych ankietach. Bazowy podział tych głosów między opcje pochodzi z odpowiedzi w tej zmianie. Scenariusz zmienia szansę wybranej opcji po zsumowaniu tak przypisanych głosów z całego badania.</p>
<p>Zakres obejmuje odmowy udziału w wywiadzie. Osoby pominięte zachowują bazową korektę wagi. Odmowa ujawnienia wyboru, głos nieważny i brak karty pozostają poza ważnymi wskazaniami. Mnożnik zachowuje bazowe udziały 0% i 100% wśród przypisanych głosów. Kolumny ilustrują przyjęte założenia o brakujących odpowiedziach. Przedziały ufności podano osobno przy wyniku exit poll.</p>
</details>
<?php elseif ($sensitivity['status'] === 'no_refusals'): ?>
<p>W rozliczonych zmianach nikt nie odmówił udziału w wywiadzie. Zmiana założeń o tej grupie daje ten sam udział co zamrożony exit poll.</p>
<?php elseif ($sensitivity['status'] === 'protected'): ?>
<p>Utajniono scenariusze, ponieważ liczebności lub układ odmów pozwalają wyodrębnić małą grupę albo pojedynczy obwód.</p>
<?php elseif ($sensitivity['status'] === 'no_valid_refusals'): ?>
<p>W zmianach z odmowami nie odnotowano ważnego wskazania w ukończonych ankietach. Brakuje podstawy do przypisania preferencji odmawiającym.</p>
<?php else: ?><p>Do obliczeń potrzebne jest pełne rozliczenie ukończonych wywiadów i odmów udziału.</p><?php endif; ?>
<?php endif; ?>
<p>Podstawą udziałów są ważne wskazania na tej karcie. Waga terenowa uwzględnia odwrotność prawdopodobieństwa wyboru punktu, krok zapisany dla tego obwodu i korektę odpowiedzi w obrębie zmiany (osoby wybrane / ukończone). Korekta zakłada podobne preferencje uczestników i pominiętych lub odmawiających osób z tego punktu i czasu. Głosy nieważne, brak karty i odmowy odpowiedzi nie wchodzą do mianownika.</p>
<p>Szacunek dotyczy zadeklarowanego zakresu operatu. Late poll zastępuje całą estymację punktu oficjalnym protokołem tej samej karty, z wagą pierwszego etapu. Różnice w zakresie głosowania poza lokalem mogą wpływać na porównanie.</p>
<?php if ($protocols): ?>
<h3>Exit poll wobec protokołów z tych samych obwodów</h3>
<p>Porównanie obejmuje <?= count($protocols) ?> obwodów z dostępnym protokołem. Udziały z ankiet uwzględniają dobór wychodzących i realizację zmian. Udziały protokolarne pochodzą z sumy ważnych głosów w tych obwodach. Kolejność spływu protokołów może wpływać na skład porównywanej grupy.</p>
<?php if ($comparison): ?><div class="ep-scroll" tabindex="0" role="region" aria-label="Błąd exit poll w obwodach z protokołami"><table class="table ep-table"><thead><tr><th>Opcja karty</th><th>Exit poll</th><th>Protokoły</th><th>Różnica (p.p.)</th></tr></thead><tbody>
<?php foreach ($comparison as $code=>$matched): ?><tr><th><?= $h($plan['options'][$code]) ?></th><td><?= $percent($matched['exit']) ?></td><td><?= $percent($matched['official']) ?></td><td><?= number_format($matched['difference'], 1, ',', ' ') ?></td></tr><?php endforeach; ?></tbody></table></div>
<?php else: ?><p>Porównanie stanie się dostępne, gdy obie próby w tych obwodach spełnią kryteria kompletności i minimalnych liczebności.</p><?php endif; ?>
<details><summary>Protokoły i czas odcięcia (UTC)</summary><ul><?php foreach ($protocols as $p): ?><li><?= $h($p['point']) ?> · <?= $h($p['recorded']) ?> · <?= $h($p['reference']) ?></li><?php endforeach; ?></ul></details><?php endif; ?></section>
<?php if ($manage && count($protocols) < count($plan['points'])): $existing = array_column($protocols,null,'point'); $protoDraft = $action === 'exitProtocol' ? $draft : []; ?>
<form class="ep-section" action="<?= $url('exitProtocol') ?>" method="post"><?= $csrf ?><h2>Zweryfikowany protokół do late poll</h2>
<label class="ep-field">Obwód i karta projektu<select class="select" name="point"><?php foreach ($plan['points'] as $code=>$item): if(isset($existing[$code])) {continue;} ?><option value="<?= $h($code) ?>"<?= (string)($protoDraft['point'] ?? '')===(string)$code ? ' selected' : '' ?>><?= $h($code . ' · ' . $item['label']) ?></option><?php endforeach; ?></select></label>
<label class="ep-field">Źródło i numer protokołu<input class="input" name="reference" required maxlength="600" value="<?= $h($protoDraft['reference'] ?? '') ?>"></label>
<label class="ep-field">Głosy ważne ogółem<input class="input" name="valid" type="number" min="0" required value="<?= $h($protoDraft['valid'] ?? '') ?>"></label>
<div class="ep-grid"><?php foreach ($plan['options'] as $code=>$label): ?><label class="ep-field"><?= $h($label) ?><input class="input" type="number" min="0" name="votes[<?= $h($code) ?>]" required value="<?= $h($protoDraft['votes'][$code] ?? '') ?>"></label><?php endforeach; ?></div>
<button class="btn" type="submit">Dodaj zweryfikowany protokół</button></form><?php endif; endif; ?>
<?php endif; ?></main></body></html>
