<?php
// SPDX-License-Identifier: GPL-2.0-or-later
$h = static function ($v) {return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');};
?><!doctype html><html lang="pl"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Karta exit poll</title>
<link rel="stylesheet" href="<?= $h($assets) ?>/components.css"><link rel="stylesheet" href="<?= $h($assets) ?>/panel.css"></head>
<body><main class="ep-shell"><h1><?= $h($plan['title']) ?></h1><p>Anonimowa i dobrowolna ankieta po głosowaniu. <?= $h($plan['date']) ?></p>
<h2>Jak wyglądał Pani/Pana wybór na tej karcie?</h2><p>Proszę zaznaczyć jedną odpowiedź, złożyć kartkę i samodzielnie wrzucić ją do pojemnika badania.</p>
<ul><!-- native symbols keep paper usable with styles disabled --><?php foreach ($plan['options'] as $label): ?><li>□ <?= $h($label) ?></li><?php endforeach; ?>
<li>□ Oddałam/oddałem głos nieważny</li><li>□ Nie pobrałam/nie pobrałem tej karty</li><li>□ Wolę nie ujawniać wyboru</li></ul>
</main></body></html>
