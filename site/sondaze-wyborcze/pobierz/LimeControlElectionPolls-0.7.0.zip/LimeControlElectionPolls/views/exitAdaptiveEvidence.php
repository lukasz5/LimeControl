<?php
// SPDX-License-Identifier: GPL-2.0-or-later
$adaptiveFile = dirname(__DIR__) . '/data/adaptive-evidence.json';
$adaptiveEvidence = is_file($adaptiveFile) ? json_decode(file_get_contents($adaptiveFile), true) : null;
if (empty($adaptiveEvidence['rows']) || empty($adaptiveEvidence['replications'])) {
    return;
}
?>
<details class="ep-section"><summary>Czy zmienny krok pomaga przy podobnej liczbie wywiadów?</summary>
<p>Na wynikach sejmików porównaliśmy trzy sposoby doboru przy czterech obwodach na warstwę i kroku odniesienia 10. Tabela pokazuje dodatkową serię <?= (int)$adaptiveEvidence['replications'] ?> losowań na każdy z 85 okręgów i rok. Każda zaproszona osoba odpowiadała z prawdopodobieństwem 80%. Za bliskie 95% przyjęliśmy pokrycie od 94% do 96%, a za podobny nakład różnicę do 5% ukończonych wywiadów względem stałego kroku.</p>
<div class="ep-scroll" role="region" tabindex="0" aria-label="Wyniki porównania kroku zmiennego i stałego">
<table class="table ep-table"><caption>Dobór kroku przy czterech obwodach na warstwę</caption><thead><tr>
<th scope="col">Reguła</th><th scope="col">Rok</th><th scope="col">Śr. wywiady na okręg</th><th scope="col">Wyznaczono przedział</th><th scope="col">Pokrycie wyznaczonych</th><th scope="col">Wyznaczono i objął wynik PKW</th>
</tr></thead><tbody>
<?php foreach ($adaptiveEvidence['rows'] as $row): ?>
<tr><th scope="row"><?= $h($stepModes[$row['mode']]) ?></th><td><?= (int)$row['year'] ?></td><td><?= number_format($row['completed'], 0, ',', ' ') ?></td>
<?php foreach (['available','coverage','joint'] as $key): ?><td><?= number_format($row[$key], 2, ',', ' ') ?>%</td><?php endforeach; ?></tr>
<?php endforeach; ?></tbody></table></div>
<p>Każda lista w każdym okręgu stanowi odrębny wynik. Kolumna pokrycia pokazuje, jaka część wyznaczonych przedziałów objęła wynik PKW. Ostatnia kolumna pokazuje, jak często udało się zarówno obliczyć przedział, jak i objąć nim wynik, spośród wszystkich zaplanowanych porównań.</p></details>
