<?php
// SPDX-License-Identifier: GPL-2.0-or-later
if (!$config): ?>
    <div class="ep-section">
        <h2>Połącz dwie fale badania</h2>
        <p>Do porównania potrzebne są dwie ankiety LimeSurvey, kody pytań o wybór listy i faktyczne daty prowadzenia wywiadów.</p>
        <?php if ($canEdit): ?><p class="ep-actions"><a class="btn btn-primary" href="<?= $h($url(['tab' => 'setup'])) ?>">Skonfiguruj fale</a></p><?php endif; ?>
    </div>
<?php else:
    $waves = $report['waves'] ?? [];
    $historical = $model['historicalLinks'] ?? [];
    $areaName = $config['area'] === 'PL' ? 'Polska' : $config['area'];
    foreach ($historical as $link) {
        if (!empty($link['name'])) {
            $areaName = $link['name'];
        }
    }
    $weighted = !empty($config['wave1']['weight']);
    $percent = static function ($value) use ($number) {
        return is_numeric($value) ? $number($value, 1) . '%' : '—';
    };
    $points = static function ($value) use ($number) {
        return is_numeric($value) ? ($value > 0 ? '+' : '') . $number($value, 1) : '—';
    };
    $rows = [];
    foreach ($waves as $waveIndex => $wave) {
        if ($wave['status'] !== 'ready') { continue; }
        foreach ($wave['rows'] as $row) {
            $key = $row['code'];
            $rows[$key]['label'] = $row['label'];
            $rows[$key]['kind'] = $row['kind'];
            $rows[$key]['waves'][$waveIndex] = $row;
        }
    }
    foreach ($report['changes'] ?? [] as $change) {
        if (isset($rows[$change['code']])) {
            $rows[$change['code']]['change'] = $change;
        }
    }
?>
    <section class="ep-section">
        <h2><?= $h($config['title']) ?></h2>
        <dl class="ep-facts">
            <div><dt>Badany obszar</dt><dd><?= $h($areaName) ?></dd></div>
            <div><dt>Zleceniodawca</dt><dd><?= $h($config['sponsor']) ?></dd></div>
            <div><dt>Rekrutacja</dt><dd><?= $h($config['method']) ?></dd></div>
            <div><dt>Schemat</dt><dd><?= $config['design'] === 'independent_srs' ? 'Dwie niezależne proste próby losowe' : 'Opis odpowiedzi uczestników' ?></dd></div>
        </dl>
        <?php if ($historical): ?>
            <nav class="ep-actions" aria-label="Archiwum wyborów w badanym obszarze"><span>Wyniki sejmikowe PKW</span>
                <?php foreach ($historical as $link): ?>
                    <a href="<?= $h($link['url']) ?>"><?= $h($link['label'] ?? $link['year']) ?></a>
                <?php endforeach; ?>
            </nav>
        <?php endif; ?>
        <?php if (!empty($model['exportUrl'])): ?><div class="ep-actions"><a class="btn" href="<?= $h($model['exportUrl']) ?>">Pobierz raport CSV</a></div><?php endif; ?>
    </section>
    <?php if (!$waves): ?>
        <p class="ep-section">Raport z fal jest obecnie niedostępny.</p>
    <?php else: ?>
        <div class="ep-grid">
        <?php foreach ($waves as $index => $wave): ?>
            <section class="ep-section">
                <h2>Fala <?= (int) $index + 1 ?></h2>
                <p><?= $h($period($wave['start'], $wave['end'])) ?></p>
                <?php if ($wave['status'] === 'ready'): ?>
                    <dl class="ep-facts">
                        <div><dt>Ukończone wywiady</dt><dd class="ep-total"><?= $h($number($wave['total'])) ?></dd></div>
                        <div><dt>Zdecydowani</dt><dd class="ep-total"><?= $h($number($wave['decided'])) ?></dd></div>
                        <?php if (($wave['effective_n'] ?? null) !== null): ?><div><dt>Efektywna liczebność Kisha</dt><dd><?= $h($number($wave['effective_n'], 1)) ?></dd></div><?php endif; ?>
                    </dl>
                <?php else: ?>
                    <p class="ep-status"><?= $wave['status'] === 'suppressed' ? 'Wynik objęty ochroną małych liczebności' : 'Wynik fali niedostępny' ?></p>
                <?php endif; ?>
                <?php if (!empty($wave['reason'])): ?><p class="ep-help"><?= $h($wave['reason']) ?></p><?php endif; ?>
            </section>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php if (!empty($report['comparison_note'])): ?><p class="ep-help"><?= $h($report['comparison_note']) ?></p><?php endif; ?>
    <?php foreach ([true, false] as $lists):
        $group = array_filter($rows, static function ($entry) use ($lists) { return ($entry['kind'] === 'list') === $lists; });
        if (!$group) { continue; }
        $caption = $lists ? 'Wybór listy wśród zdecydowanych' : 'Pozostałe odpowiedzi wśród uczestników';
    ?>
        <section class="ep-section">
            <h2><?= $h($caption) ?></h2>
            <p class="ep-help"><?= $lists ? 'Mianownik obejmuje osoby, które wskazały jedną z list.' : 'Mianownik obejmuje wszystkie ukończone wywiady w danej fali.' ?>
                <?= $weighted ? 'Główny odsetek i zmiana uwzględniają wagi.' : 'Odsetki obliczono bez wag.' ?></p>
            <div class="ep-scroll" tabindex="0" role="region" aria-label="<?= $h($caption) ?>">
                <table class="table ep-table"><thead><tr>
                    <th scope="col">Odpowiedź</th><th scope="col" class="ep-num">Fala 1</th><th scope="col" class="ep-num">Fala 2</th><th scope="col" class="ep-num">Zmiana w p.p.</th>
                </tr></thead><tbody>
                <?php foreach ($group as $entry): ?>
                    <tr><th scope="row"><?= $h($entry['label']) ?></th>
                    <?php foreach ([0, 1] as $wi): $row = $entry['waves'][$wi] ?? null; ?>
                        <td class="ep-num">
                            <?php if ($row !== null): ?>
                                <?= $h($percent($row['percent'])) ?><small>n = <?= $h($number($row['count'])) ?></small>
                                <?php if ($weighted): ?><small>Bez wag <?= $h($percent($row['raw_percent'])) ?></small><?php endif; ?>
                                <?php if (isset($row['ci'][0], $row['ci'][1])): ?><small>95%: <?= $h($percent($row['ci'][0])) ?> – <?= $h($percent($row['ci'][1])) ?></small><?php endif; ?>
                            <?php else: ?>—<?php endif; ?>
                        </td>
                    <?php endforeach; ?>
                    <td class="ep-num"><?= $h($points($entry['change']['delta'] ?? null)) ?>
                        <?php if (isset($entry['change']['ci'][0], $entry['change']['ci'][1])): ?><small>95%: <?= $h($points($entry['change']['ci'][0])) ?> do <?= $h($points($entry['change']['ci'][1])) ?> p.p.</small><?php endif; ?>
                    </td></tr>
                <?php endforeach; ?>
                </tbody></table>
            </div>
        </section>
    <?php endforeach; ?>
    <?php $events = $report['events'] ?? $model['events'] ?? []; require __DIR__ . '/timeline.php'; ?>
<?php endif; ?>
