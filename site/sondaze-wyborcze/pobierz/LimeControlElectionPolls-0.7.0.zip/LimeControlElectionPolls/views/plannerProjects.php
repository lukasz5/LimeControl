<?php
// SPDX-License-Identifier: GPL-2.0-or-later
$h = static function ($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
};
?><!doctype html>
<html lang="pl" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Planery kampanii · Sondaże wyborcze</title>
    <link rel="stylesheet" href="<?= $h($model['assets']) ?>/components.css">
    <link rel="stylesheet" href="<?= $h($model['assets']) ?>/panel.css">
</head>
<body>
<a class="ep-skip" href="#ep-main">Przejdź do treści</a>
<header class="ep-header"><div class="ep-shell ep-masthead">
    <div><strong>Sondaże wyborcze</strong><span class="ep-brand">LimeControl</span></div>
    <a href="<?= $h($model['backUrl']) ?>">Wróć do panelu LimeSurvey</a>
</div></header>
<main class="ep-shell" id="ep-main" tabindex="-1">
    <h1>Planery kampanii</h1>
    <div class="ep-section">
    <?php if ($model['projects']): ?>
        <ul class="ep-events">
        <?php foreach ($model['projects'] as $project): ?>
            <li><a href="<?= $h($project['url']) ?>"><?= $h($project['title']) ?></a>
                <div><small><?= $project['area'] === 'PL' ? 'Polska' : $h($project['area']) ?> · Ankieta <?= (int) $project['sid'] ?></small></div>
            </li>
        <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>Na tym koncie nie ma dostępnych planerów. Jeśli uczestniczysz w kampanii, poproś koordynatora o dostęp do planera w ankiecie jej pierwszej fali.</p>
    <?php endif; ?>
    </div>
</main>
</body>
</html>
