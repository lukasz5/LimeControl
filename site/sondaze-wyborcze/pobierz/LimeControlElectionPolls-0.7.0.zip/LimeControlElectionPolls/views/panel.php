<?php
// SPDX-License-Identifier: GPL-2.0-or-later
/** @var array $model Populated by the permission-checked controller. */
$h = static function ($value) {
    return htmlspecialchars(is_scalar($value) ? (string) $value : '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
};
$number = static function ($value, $precision = 0) {
    return is_numeric($value) ? number_format((float) $value, $precision, ',', "\u{00a0}") : '—';
};
$date = static function ($value) {
    if (is_string($value) && preg_match('/^(\d{4})-(\d{2})-(\d{2})$/D', $value, $m)) {
        return $m[3] . '.' . $m[2] . '.' . $m[1];
    }
    return '—';
};
$period = static function ($start, $end) use ($date) {
    return $start === $end ? $date($start) : $date($start) . ' – ' . $date($end);
};
$url = $model['panelUrl'];
$csrf = static function () use ($model, $h) {
    return '<input type="hidden" name="' . $h($model['csrfName']) . '" value="' . $h($model['csrfToken']) . '">';
};
$config = $model['config'] ?? null;
$report = $model['report'] ?? null;
$canEdit = !empty($model['canEdit']);
$tab = $model['tab'] ?? 'report';
$tabs = ['report' => 'Wyniki sondażu', 'planner' => 'Planer kampanii', 'events' => 'Wydarzenia kampanii', 'history' => 'Archiwum PKW'];
if (!empty($model['plannerOnly'])) {
    $tabs = ($model['canReadPlanner'] ?? true) ? ['planner' => 'Planer kampanii'] : [];
} elseif ($model['canConfigure'] ?? $canEdit) {
    $tabs['setup'] = 'Ustawienia fal';
}
if (!empty($model['canReadCommittee'])) {
    $tabs += ['committee' => 'Raport dla komitetu'];
}
if (!isset($tabs[$tab])) {
    $tab = 'report';
}
?><!doctype html>
<html lang="pl" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title><?= $h($tabs[$tab]) ?> · Sondaże wyborcze</title>
    <link rel="stylesheet" href="<?= $h($model['assets']) ?>/components.css">
    <link rel="stylesheet" href="<?= $h($model['assets']) ?>/panel.css">
</head>
<body>
<a href="#ep-main" class="ep-skip">Przejdź do treści</a>
<header class="ep-header"><div class="ep-shell ep-masthead">
    <div><strong>Sondaże wyborcze</strong><span class="ep-brand">LimeControl</span></div>
    <a href="<?= $h($model['backUrl']) ?>"><?= empty($model['plannerOnly']) ? 'Wróć do ankiety' : 'Wróć do listy planerów' ?></a>
</div></header>
<div class="ep-nav"><nav aria-label="Panel sondażu" class="ep-shell">
    <?php foreach ($tabs as $key => $label): ?>
        <a href="<?= $h($url(['tab' => $key])) ?>"<?= $key === $tab ? ' aria-current="page"' : '' ?>><?= $h($label) ?></a>
    <?php endforeach; ?>
    <?php if (empty($model['plannerOnly']) && !empty($model['exitUrl'])): ?><a href="<?= $h($model['exitUrl']) ?>">Exit poll</a><?php endif; ?>
</nav></div>
<main id="ep-main" class="ep-shell" tabindex="-1">
    <?php if (!empty($model['error'])): ?><p class="alert alert-error ep-notice" role="alert"><?= $h($model['error']) ?></p><?php endif; ?>
    <?php if (!empty($model['notice'])): ?><p class="alert alert-success ep-notice" role="status"><?= $h($model['notice']) ?></p><?php endif; ?>
    <h1><?= $h($tabs[$tab]) ?></h1>
    <?php require __DIR__ . '/' . $tab . '.php'; ?>
</main>
</body>
</html>
