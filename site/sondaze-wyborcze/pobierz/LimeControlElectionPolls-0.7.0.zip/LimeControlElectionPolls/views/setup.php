<?php
// SPDX-License-Identifier: GPL-2.0-or-later
$form = !empty($model['projectInput']) ? $model['projectInput'] : ($config ?? []);
?>
<form method="post" action="<?= $h($model['saveUrl']) ?>" class="ep-section">
    <?= $csrf() ?>
    <input type="hidden" name="revision" value="<?= $h($form['revision'] ?? 0) ?>">
    <h2>Projekt badania</h2>
    <div class="ep-grid">
        <label class="ep-field">Nazwa projektu
            <input class="input" name="title" required value="<?= $h($form['title'] ?? '') ?>">
        </label>
        <label class="ep-field">Badany obszar
            <input class="input" name="area" required list="ep-areas" aria-describedby="ep-area-help" value="<?= $h($model['projectInput']['area'] ?? (!empty($model['scope']) ? $model['scope'] : ($form['area'] ?? 'PL'))) ?>">
        </label>
        <label class="ep-field">Zleceniodawca
            <input class="input" name="sponsor" required value="<?= $h($form['sponsor'] ?? '') ?>">
        </label>
    </div>
    <datalist id="ep-areas"><option value="PL">Polska</option></datalist>
    <p class="ep-help" id="ep-area-help">Wybierz obszar w <a href="<?= $h($url(['tab' => 'history'])) ?>">archiwum PKW</a> albo podaj kod kraju (PL), województwa (np. W:22), powiatu (P:2204), gminy (G:220404) lub dzielnicy Warszawy (B:146502).</p>
    <div class="ep-grid ep-form-note">
        <label class="ep-field">Sposób rekrutacji
            <input class="input" name="method" required placeholder="np. zaproszenia do panelu internetowego" value="<?= $h($form['method'] ?? '') ?>">
        </label>
        <label class="ep-field">Schemat do porównania fal
            <select class="select" name="design" aria-describedby="ep-design-help">
                <option value="descriptive">Opis odpowiedzi uczestników</option>
                <option value="independent_srs"<?= ($form['design'] ?? '') === 'independent_srs' ? ' selected' : '' ?>>Dwie niezależne proste próby losowe</option>
            </select>
        </label>
    </div>
    <p class="ep-help" id="ep-design-help">Wariant losowy oznacza potwierdzenie, że obie próby wylosowano niezależnie i prosto, a wyniki są nieważone. Przy kwotach, ochotnikach, panelu powtórzonym lub doborze obwodów wybierz opis odpowiedzi.</p>
    <?php foreach ([1, 2] as $index):
        $key = 'wave' . $index;
        $wave = is_array($form[$key] ?? null) ? $form[$key] : [];
    ?>
        <fieldset class="fieldset ep-fieldset">
            <legend class="fieldset-legend">Fala <?= $index ?></legend>
            <div class="ep-grid">
                <label class="ep-field">Identyfikator ankiety
                    <input class="input" type="number" min="1" step="1" required name="<?= $key ?>[sid]" value="<?= $h($index === 1 ? $model['sid'] : ($wave['sid'] ?? '')) ?>"<?= $index === 1 ? ' readonly' : '' ?>>
                </label>
                <label class="ep-field">Kod pytania o wybór listy
                    <input class="input" required name="<?= $key ?>[question]" value="<?= $h($wave['question'] ?? '') ?>" aria-describedby="ep-question-help">
                </label>
                <label class="ep-field">Kod pytania z wagą (opcjonalnie)
                    <input class="input" name="<?= $key ?>[weight]" value="<?= $h($wave['weight'] ?? '') ?>" aria-describedby="ep-weight-help">
                </label>
                <label class="ep-field">Kod pytania o obszar (opcjonalnie)
                    <input class="input" name="<?= $key ?>[geo]" value="<?= $h($wave['geo'] ?? '') ?>" aria-describedby="ep-geo-help">
                </label>
                <label class="ep-field">Początek wywiadów
                    <input class="input" type="date" required name="<?= $key ?>[start]" value="<?= $h($wave['start'] ?? '') ?>">
                </label>
                <label class="ep-field">Koniec wywiadów
                    <input class="input" type="date" required name="<?= $key ?>[end]" value="<?= $h($wave['end'] ?? '') ?>">
                </label>
            </div>
        </fieldset>
    <?php endforeach; ?>
    <p class="ep-help" id="ep-geo-help">Aby porównać obszary w raporcie dla komitetu, wskaż w obu falach zamknięte pytanie jednokrotnego wyboru o obszar respondenta (typ L lub !). W obu pytaniach użyj tych samych jednostek na jednym poziomie. Dla województw i powiatów możesz podać kod bezpośrednio w kodzie odpowiedzi, np. <code>W22</code> lub <code>P2204</code>. Dla gmin i dzielnic Warszawy nadaj odpowiedzi krótki kod, np. <code>A01</code>, i zacznij jej etykietę od kodu PKW. Przykładowe etykiety to <code>G:220404 · Pruszcz Gdański</code> i <code>B:146502 · Bemowo</code>. Odpowiedź pusta, <code>DK</code> lub <code>REF</code> pozostaje bez przypisania do obszaru. Przy pustych polach raport prezentuje poparcie dla całego projektu.</p>
    <p class="ep-help" id="ep-weight-help">W obu falach możesz wskazać numeryczne pytanie z dodatnią wagą przygotowaną przez pracownię. Dla ważonych wyników wybierz opis odpowiedzi.</p>
    <p id="ep-question-help" class="ep-help">Użyj dwóch osobnych anonimowych ankiet i pytań listowych jednokrotnego wyboru (typ L lub !), bez otwartej opcji „Inne”. Kody i etykiety odpowiedzi muszą być takie same w obu ankietach. Kody specjalne to <code>DK</code> (niezdecydowanie), <code>REF</code> (odmowa) oraz <code>NOST</code> (zamiar niegłosowania). Pozostałe kody oznaczają wybór listy.</p>
    <p class="ep-help">Podaj faktyczne dni wywiadów. Druga fala musi rozpocząć się po zakończeniu pierwszej. Gdy brak rzeczywistych dat odpowiedzi, do fali zaliczają się wszystkie ukończone odpowiedzi z tej ankiety.</p>
    <div class="ep-actions"><button class="btn btn-primary" type="submit">Zapisz ustawienia fal</button></div>
</form>
