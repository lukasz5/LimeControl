<?php
// SPDX-License-Identifier: GPL-2.0-or-later
$isEventForm = $kind === 'event';
$editing = $isEventForm ? $model['editEvent'] : $model['editTask'];
$draft = $isEventForm ? $model['plannerEventInput'] : $model['plannerTaskInput'];
$values = $editing ?? [];
foreach (['planned_cost', 'actual_cost'] as $key) {
    $values[$key] = isset($values[$key]) ? $amount($values[$key], false) : '';
}
$values = $draft + $values;
$formHeading = ($editing ? 'Edytuj ' : 'Dodaj ') . ($isEventForm ? 'wydarzenie' : 'zadanie');
$action = $isEventForm ? $model['plannerEventUrl'] : $model['plannerTaskUrl'];
$statuses = $isEventForm ? $eventStatuses : $taskStatuses;
$formId = 'ep-planner-' . $kind;
?>
<form class="ep-section" method="post" action="<?= $h($action) ?>" id="<?= $formId ?>" aria-labelledby="<?= $formId ?>-heading">
    <?= $csrf() ?>
    <input type="hidden" name="id" value="<?= $h($editing['id'] ?? '') ?>">
    <input type="hidden" name="revision" value="<?= $h($draft['revision'] ?? $planner['revision']) ?>">
    <input type="hidden" name="request_id" value="<?= $h($draft['request_id'] ?? bin2hex(random_bytes(16))) ?>">
    <h2 id="<?= $formId ?>-heading"><?= $formHeading ?></h2>
    <div class="ep-grid">
        <label class="ep-field"><?= $isEventForm ? 'Nazwa wydarzenia' : 'Nazwa zadania' ?>
            <input class="input" name="title" maxlength="180" required value="<?= $h($values['title'] ?? '') ?>">
        </label>
        <label class="ep-field">Osoba odpowiedzialna<?= $isEventForm ? ' (opcjonalnie)' : '' ?>
            <input class="input" name="responsible" maxlength="180"<?= $isEventForm ? '' : ' required' ?> value="<?= $h($values['responsible'] ?? '') ?>">
        </label>
        <label class="ep-field">Status
            <select class="select" name="status"><?php foreach ($statuses as $code => $label): ?>
                <option value="<?= $h($code) ?>"<?= ($values['status'] ?? '') === $code ? ' selected' : '' ?>><?= $h($label) ?></option>
            <?php endforeach; ?></select>
        </label>
        <?php if ($isEventForm): ?>
            <label class="ep-field">Początek wydarzenia
                <input class="input" type="date" name="start" required value="<?= $h($values['start'] ?? '') ?>">
            </label>
            <label class="ep-field">Koniec wydarzenia
                <input class="input" type="date" name="end" required value="<?= $h($values['end'] ?? '') ?>">
            </label>
            <label class="ep-field">Obszar wydarzenia
                <input class="input" name="area" maxlength="8" list="ep-planner-areas" required aria-describedby="ep-area-format" value="<?= $h($values['area'] ?? $config['area']) ?>">
            </label>
            <label class="ep-field">Źródło informacji
                <input class="input" name="source" maxlength="500" required value="<?= $h($values['source'] ?? '') ?>">
            </label>
        <?php else: ?>
            <label class="ep-field">Termin zadania
                <input class="input" type="date" name="due" required value="<?= $h($values['due'] ?? '') ?>">
            </label>
            <label class="ep-field">Powiązanie
                <select class="select" name="link">
                    <?php foreach (['project', 'wave1', 'wave2'] as $key): ?>
                        <option value="<?= $key ?>"<?= ($values['link'] ?? '') === $key ? ' selected' : '' ?>><?= $h($linkedTitles[$key]) ?></option>
                    <?php endforeach; ?>
                    <?php if ($planner['events']): ?><optgroup label="Wydarzenia">
                        <?php foreach ($planner['events'] as $option): $ref = 'event:' . $option['id']; ?>
                            <option value="<?= $h($ref) ?>"<?= ($values['link'] ?? '') === $ref ? ' selected' : '' ?>><?= $h($option['title'] . ' · ' . $date($option['start'])) ?></option>
                        <?php endforeach; ?>
                    </optgroup><?php endif; ?>
                </select>
            </label>
        <?php endif; ?>
        <?php foreach (['planned_cost' => 'Koszt planowany (zł)', 'actual_cost' => 'Koszt rzeczywisty (zł)'] as $key => $label): ?>
            <label class="ep-field"><?= $label ?>
                <input class="input" type="text" name="<?= $key ?>" inputmode="decimal" placeholder="0,00" aria-describedby="<?= $formId ?>-cost" value="<?= $h($values[$key]) ?>">
            </label>
        <?php endforeach; ?>
    </div>
    <?php if ($isEventForm): ?>
        <datalist id="ep-planner-areas"><option value="PL">Polska</option>
            <?php if ($config['area'] !== 'PL'): ?><option value="<?= $h($config['area']) ?>">Obszar projektu</option><?php endif; ?>
        </datalist>
        <p class="ep-help" id="ep-area-format">Użyj kodu PKW obszaru objętego wydarzeniem, np. W:22, P:2204 lub G:220404.</p>
    <?php endif; ?>
    <p class="ep-help" id="<?= $formId ?>-cost">Podaj koszty w złotych, z dokładnością do grosza. Pozostaw pole puste, jeśli kwota jest jeszcze nieznana.</p>
    <div class="ep-actions">
        <button class="btn btn-primary" type="submit"><?= $isEventForm ? 'Zapisz wydarzenie' : 'Zapisz zadanie' ?></button>
        <?php if ($editing || $draft): ?><a href="<?= $h($url(['tab' => 'planner', 'month' => $monthKey])) ?>#ep-planner-month"><?= $draft ? 'Wczytaj aktualny planer' : 'Anuluj edycję' ?></a><?php endif; ?>
    </div>
</form>
