<?php
// SPDX-License-Identifier: GPL-2.0-or-later
if (!$config): ?>
    <div class="ep-section"><p>Dodawanie wydarzeń będzie dostępne po połączeniu dwóch fal badania.</p>
        <?php if ($canEdit): ?><a href="<?= $h($url(['tab' => 'setup'])) ?>">Skonfiguruj fale</a><?php endif; ?>
    </div>
<?php else:
    $events = $report['events'] ?? $model['events'] ?? [];
    $event = $model['eventInput'] ?? [];
?>
    <?php require __DIR__ . '/timeline.php'; ?>
    <?php if ($canEdit): ?>
        <form class="ep-section" method="post" action="<?= $h($model['eventUrl']) ?>">
            <?= $csrf() ?>
            <input type="hidden" name="revision" value="<?= $h($config['revision']) ?>">
            <input type="hidden" name="request_id" value="<?= $h($event['request_id'] ?? bin2hex(random_bytes(16))) ?>">
            <h2>Dodaj wydarzenie</h2>
            <div class="ep-grid">
                <label class="ep-field">Nazwa wydarzenia
                    <input class="input" name="title" required placeholder="np. debata publiczna" value="<?= $h($event['title'] ?? '') ?>">
                </label>
                <label class="ep-field">Status
                    <select class="select" name="status">
                        <option value="held">Odbyło się</option>
                        <option value="planned"<?= ($event['status'] ?? '') === 'planned' ? ' selected' : '' ?>>Planowane</option>
                    </select>
                </label>
                <label class="ep-field">Początek wydarzenia
                    <input class="input" type="date" name="start" required value="<?= $h($event['start'] ?? '') ?>">
                </label>
                <label class="ep-field">Koniec wydarzenia
                    <input class="input" type="date" name="end" required value="<?= $h($event['end'] ?? '') ?>">
                </label>
                <label class="ep-field">Obszar wydarzenia
                    <input class="input" name="area" list="ep-event-areas" required aria-describedby="ep-event-area-help" value="<?= $h($event['area'] ?? $config['area']) ?>">
                </label>
                <label class="ep-field">Źródło informacji
                    <input class="input" name="source" required placeholder="np. program debaty lub link do ogłoszenia" value="<?= $h($event['source'] ?? '') ?>">
                </label>
            </div>
            <datalist id="ep-event-areas"><option value="PL">Polska</option>
                <?php if ($config['area'] !== 'PL'): ?><option value="<?= $h($config['area']) ?>">Obszar badania</option><?php endif; ?>
            </datalist>
            <p class="ep-help" id="ep-event-area-help">Podaj kod PKW obszaru badania, jego części albo obszaru nadrzędnego. Dla wydarzenia ogólnopolskiego wpisz PL.</p>
            <div class="ep-actions"><button class="btn btn-primary" type="submit">Dodaj wydarzenie</button></div>
        </form>
    <?php endif; ?>
<?php endif; ?>
