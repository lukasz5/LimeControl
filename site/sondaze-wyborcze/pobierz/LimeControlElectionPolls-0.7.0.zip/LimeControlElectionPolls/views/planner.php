<?php
// SPDX-License-Identifier: GPL-2.0-or-later
$planner = $model['planner'] ?? null;
if (!$config || !$planner): ?>
    <section class="ep-section">
        <h2>Połącz fale z kalendarzem kampanii</h2>
        <p>Planer korzysta z obszaru projektu i terminów wywiadów w obu falach badania.</p>
        <?php if (!empty($model['canConfigure']) && empty($model['plannerOnly'])): ?><a class="btn" href="<?= $h($url(['tab' => 'setup'])) ?>">Skonfiguruj fale</a><?php endif; ?>
    </section>
<?php return; endif;

// Keep exact grosze through presentation, including negative differences and decimals in edit forms.
$amount = static function (int $cents, bool $display = true): string {
    $whole = (string) intdiv(abs($cents), 100);
    $fraction = str_pad((string) (abs($cents) % 100), 2, '0', STR_PAD_LEFT);
    if ($display) {
        $whole = preg_replace('/\B(?=(\d{3})+(?!\d))/', "\u{00a0}", $whole);
    }
    return ($cents < 0 ? '−' : '') . $whole . ',' . $fraction . ($display ? ' zł' : '');
};
$budget = $planner['budget'];
$incomplete = $budget['planned_missing'] || $budget['actual_missing'];
$delta = $budget['actual_cost'] - $budget['planned_cost'];
$eventStatuses = ['planned' => 'Planowane', 'held' => 'Odbyło się'];
$taskStatuses = ['todo' => 'Do zrobienia', 'doing' => 'W toku', 'done' => 'Zakończone'];
$linkedTitles = ['project' => 'Cała kampania', 'wave1' => 'Fala 1', 'wave2' => 'Fala 2'];
$agenda = [];
foreach (['wave1' => 'Fala 1', 'wave2' => 'Fala 2'] as $key => $title) {
    $agenda[] = ['type' => 'wave', 'start' => $planner[$key]['start'], 'end' => $planner[$key]['end'], 'title' => $title, 'id' => $key];
}
foreach ($planner['events'] as $event) {
    $linkedTitles['event:' . $event['id']] = $event['title'];
    $agenda[] = ['type' => 'event'] + $event;
}
foreach ($planner['tasks'] as $task) {
    $agenda[] = ['type' => 'task', 'start' => $task['due'], 'end' => $task['due']] + $task;
}
$typeOrder = ['wave' => 0, 'event' => 1, 'task' => 2];
usort($agenda, static function ($a, $b) use ($typeOrder) {
    return [$a['start'], $typeOrder[$a['type']], $a['title'], $a['id']]
        <=> [$b['start'], $typeOrder[$b['type']], $b['title'], $b['id']];
});
?>
<p><?= $h($config['title']) ?> · <?= $config['area'] === 'PL' ? 'Polska' : $h($config['area']) ?></p>
<nav class="ep-actions" aria-label="W planerze kampanii">
    <a href="#ep-planner-month">Kalendarz miesięczny</a><a href="#ep-calendar">Lista terminów</a><a href="#ep-budget">Budżet</a>
    <?php if ($canEdit): ?>
        <a href="#ep-planner-event"><?= empty($model['editEvent']) ? 'Dodaj wydarzenie' : 'Edytuj wydarzenie' ?></a>
        <a href="#ep-planner-task"><?= empty($model['editTask']) ? 'Dodaj zadanie' : 'Edytuj zadanie' ?></a>
    <?php endif; ?>
</nav>
<section class="ep-section" aria-labelledby="ep-budget">
    <h2 id="ep-budget">Budżet kampanii</h2>
    <dl class="ep-facts">
        <?php foreach (['planned' => 'Koszty planowane', 'actual' => 'Koszty rzeczywiste'] as $key => $label):
            $missing = $budget[$key . '_missing']; ?>
            <div><dt><?= $label ?></dt>
                <dd class="ep-total"><?= $missing > 0 && $missing === $budget['items'] ? 'Brak kwot' : $h($amount($budget[$key . '_cost'])) ?></dd>
                <?php if ($missing): ?><dd><small>Brak kwoty w <?= (int) $missing ?> z <?= (int) $budget['items'] ?> pozycji.</small></dd><?php endif; ?>
            </div>
        <?php endforeach; ?>
        <div><dt>Różnica (wykonanie − plan)</dt>
            <dd class="ep-total"><?= $incomplete ? 'Brak pełnych danych' : ($delta > 0 ? '+' : '') . $h($amount($delta)) ?></dd>
        </div>
    </dl>
    <p class="ep-help">Budżet sumuje wpisane kwoty ze wszystkich wydarzeń i zadań. Jeśli wydatek rozliczasz w zadaniu, pomiń go w kosztach wydarzenia. Kwota 0 zł oznacza brak kosztu.</p>
</section>
<?php require __DIR__ . '/plannerCalendar.php'; ?>
<section class="ep-section" aria-labelledby="ep-calendar">
    <h2 id="ep-calendar">Kalendarz kampanii i badań</h2>
    <ol class="ep-events ep-planner-agenda">
        <?php foreach ($agenda as $item):
            $isEvent = $item['type'] === 'event';
            $isWave = $item['type'] === 'wave'; ?>
            <li id="ep-planner-item-<?= $h($item['type'] . '-' . $item['id']) ?>">
                <div><time datetime="<?= $h($item['start']) ?>"><?= $h($date($item['start'])) ?></time><?php if ($item['start'] !== $item['end']): ?>
                    – <time datetime="<?= $h($item['end']) ?>"><?= $h($date($item['end'])) ?></time><?php endif; ?>
                    <small> · <?= $isWave ? 'Wywiady' : ($isEvent ? 'Wydarzenie' : 'Termin zadania') ?></small>
                </div>
                <div><h3><?= $h($item['title']) ?></h3>
                <?php if (!$isWave): ?>
                    <p><strong><?= $h(($isEvent ? $eventStatuses : $taskStatuses)[$item['status']]) ?></strong> · <?= $h($item['wave_label']) ?></p>
                    <dl class="ep-facts">
                        <div><dt>Osoba odpowiedzialna</dt><dd><?= $item['responsible'] === '' ? 'Nieprzypisana' : $h($item['responsible']) ?></dd></div>
                        <?php if ($isEvent): ?>
                            <div><dt>Obszar</dt><dd><?= $item['area'] === 'PL' ? 'Polska' : $h($item['area']) ?></dd></div>
                        <?php else: ?>
                            <div><dt>Powiązanie</dt><dd><?= $h($linkedTitles[$item['link']]) ?></dd></div>
                        <?php endif; ?>
                        <?php foreach (['planned_cost' => 'Koszt planowany', 'actual_cost' => 'Koszt rzeczywisty'] as $key => $label): ?>
                            <div><dt><?= $label ?></dt><dd><?= $item[$key] === null ? 'Brak kwoty' : $h($amount($item[$key])) ?></dd></div>
                        <?php endforeach; ?>
                        <?php if ($item['planned_cost'] !== null && $item['actual_cost'] !== null): $itemDelta = $item['actual_cost'] - $item['planned_cost']; ?>
                            <div><dt>Różnica (wykonanie − plan)</dt><dd><?= ($itemDelta > 0 ? '+' : '') . $h($amount($itemDelta)) ?></dd></div>
                        <?php endif; ?>
                    </dl>
                    <?php if ($isEvent): ?><p><small>Źródło informacji · <?= $h($item['source']) ?></small></p><?php endif; ?>
                    <?php if ($canEdit):
                        $editLabel = $isEvent ? 'Edytuj wydarzenie' : 'Edytuj zadanie';
                        $editKey = $isEvent ? 'edit_event' : 'edit_task'; ?>
                        <a href="<?= $h($url(['tab' => 'planner', 'month' => $monthKey, $editKey => $item['id']])) ?>#ep-planner-<?= $isEvent ? 'event' : 'task' ?>" aria-label="<?= $h($editLabel . ' „' . $item['title'] . '”') ?>"><?= $editLabel ?></a>
                    <?php endif; ?>
                <?php endif; ?></div>
            </li>
        <?php endforeach; ?>
    </ol>
    <?php if (empty($model['plannerOnly'])): ?><a href="<?= $h($url(['tab' => 'report'])) ?>">Zobacz wyniki obu fal</a><?php endif; ?>
</section>
<?php if ($canEdit):
    foreach (['event', 'task'] as $kind) {
        require __DIR__ . '/plannerForm.php';
    }
endif; ?>
