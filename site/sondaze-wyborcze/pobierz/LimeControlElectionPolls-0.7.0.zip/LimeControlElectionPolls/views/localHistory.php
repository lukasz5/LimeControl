<?php
// SPDX-License-Identifier: GPL-2.0-or-later
$page = $model['local'];
$race = $page['race'];
$localUrl = static function (array $params = []) use ($url, $page) {
    return $url(['tab' => 'history'] + $params + LcepLocalArchive::query($page));
};
$statusLabel = static function ($status) {
    return ['voted' => 'Przeprowadzono głosowanie', 'uncontested' => 'Mandat obsadzony bez głosowania',
        'vacant' => 'Mandat nieobsadzony', 'no_vote' => 'Bez głosowania', 'unknown' => 'Brak informacji o głosowaniu'][$status] ?? (string) $status;
};
$linkForArea = static function ($code) use ($localUrl) {
    return $localUrl(['area' => $code, 'district' => 0, 'round' => 1]);
};
?>
<nav class="ep-actions" aria-label="Rok wyborów"><strong>Wybory</strong>
    <?php foreach ($model['years'] as $y): ?>
        <a class="ep-year" href="<?= $h($y === $year ? $localUrl() : $localUrl(['year' => $y, 'area' => $model['localYearAreas'][$y] ?? 'PL', 'district' => 0, 'round' => 1])) ?>"<?= $y === $year ? ' aria-current="page"' : '' ?>><?= $h($y) ?></a>
    <?php endforeach; ?>
</nav>
<section class="ep-section">
    <?php if ($page['parent']): ?><nav class="ep-actions" aria-label="Poziom terytorialny">
        <a href="<?= $h($linkForArea('PL')) ?>">Polska</a>
        <?php if ($page['parent'] !== 'PL'): ?><a href="<?= $h($linkForArea($page['parent'])) ?>">Obszar nadrzędny</a><?php endif; ?>
        <?php if ($page['district']): ?><a href="<?= $h($linkForArea($page['area'])) ?>">Wszystkie okręgi tej rady</a><?php endif; ?>
    </nav><?php endif; ?>
    <h2><?= $h($page['name']) ?></h2>
    <p><?= $h(LcepLocalArchive::ORGANS[$organ]) ?> · <?= $year ?><?php if ($page['area'] !== 'PL'): ?> · <?= $h($page['area']) ?><?php endif; ?></p>
    <?php if ($canEdit): ?><p><a href="<?= $h($url(['tab' => 'setup', 'scope' => $page['area']])) ?>">Użyj tego obszaru w ustawieniach fal</a></p><?php endif; ?>
    <?php if (!$race && $organ !== 'mayor'):
        $totals = LcepCouncilCatalog::totals($year, $organ, $page['area']);
        if ($totals): ?>
        <dl class="ep-facts">
            <?php foreach (['units' => 'Rady', 'districts' => 'Okręgi', 'valid_votes' => 'Głosy ważne', 'uncontested' => 'Okręgi z obsadą bez głosowania', 'vacant' => 'Okręgi bez obsadzonych mandatów'] as $key => $label): ?>
                <div><dt><?= $h($label) ?></dt><dd><?= $h($number($totals[$key])) ?></dd></div>
            <?php endforeach; ?>
        </dl>
        <?php endif; ?>
    <?php elseif (!$race): ?>
        <table class="table ep-table"><caption>Wybory włodarzy na tym obszarze</caption>
        <thead><tr><th>Tura</th><th>Gminy w archiwum tury</th><th>Gminy z głosowaniem</th><th>Głosy ważne</th><th>Głosy nieważne</th></tr></thead><tbody>
        <?php foreach ([1,2] as $r): $t = LcepMayorCatalog::totals($year, $page['area'], $r); if (!$t) { continue; } ?>
            <tr><th scope="row"><?= $r === 1 ? 'I' : 'II' ?></th><?php foreach (['units','voted','valid_votes','invalid_votes'] as $key): ?>
            <td><?= $h($number($t[$key])) ?></td><?php endforeach; ?></tr>
        <?php endforeach; ?></tbody></table>
        <?php if ($year === 2014): ?><p class="ep-help">W pierwszej turze 2014 r. arkusze gminne KBW i obwieszczenie krajowe różnią się co do liczby kandydatów i uprawnionych. Źródłem tego zestawienia są arkusze gminne.</p><?php endif; ?>
    <?php endif; ?>
    <?php if ($page['children']): ?>
        <ul class="ep-links">
            <?php foreach ($page['children'] as $child): ?>
                <li><a href="<?= $h($linkForArea($child['code'])) ?>"><?= $h($child['name']) ?> <small><?= $h($child['code']) ?></small></a></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
    <?php if (!$page['district'] && $page['districts']): ?>
        <table class="table ep-table"><caption>Okręgi tej rady</caption>
            <thead><tr><th scope="col">Okręg</th><th scope="col">Głosowanie</th><th scope="col" class="ep-num">Głosy ważne</th></tr></thead>
            <tbody><?php foreach ($page['districts'] as $d): ?>
                <tr><th scope="row"><a href="<?= $h($localUrl(['district' => $d['code']])) ?>"><?= $h($d['name']) ?></a></th>
                    <td><?= $h($statusLabel($d['status'])) ?></td><td class="ep-num"><?= $h($number($d['valid_votes'])) ?></td></tr>
            <?php endforeach; ?></tbody>
        </table>
    <?php endif; ?>
    <?php if ($page['rounds']): ?>
        <nav class="ep-actions" aria-label="Tura wyborów">
            <?php foreach ($page['rounds'] as $r): ?>
                <a class="ep-year" href="<?= $h($localUrl(['round' => $r])) ?>"<?= $r === $page['round'] ? ' aria-current="page"' : '' ?>><?= $r === 1 ? 'I tura' : 'II tura' ?></a>
            <?php endforeach; ?>
        </nav>
    <?php endif; ?>
</section>
<?php if ($race):
    $isMayor = $organ === 'mayor';
    $opts = $race['options'];
    $selected = $model['precinct'] ?? null;
    $precinct = $selected !== null ? $race['precincts'][$selected] : null;
    $counts = $precinct ? ($isMayor ? ($precinct['options'] ?? null) : ($precinct['votes'] ?? null)) : null;
    $valid = ($precinct ?? $race)['valid_votes'] ?? null;
?>
<section class="ep-section">
    <h2><?= $h(LcepLocalArchive::title($page)) ?></h2>
    <?php if ($precinct): ?>
        <p><?= $h($precinct['name']) ?> · <?= $h($selected) ?> · <a href="<?= $h($localUrl()) ?>">Wynik całego głosowania</a></p>
    <?php endif; ?>
    <?php if (!$isMayor): ?><p><?= $h($statusLabel($race['status'])) ?></p>
    <?php elseif (!empty($race['outcome'])): ?><p><?= $h($race['outcome']) ?></p><?php endif; ?>
    <dl class="ep-facts">
        <div><dt>Głosy ważne</dt><dd class="ep-total"><?= $h($number($valid)) ?></dd></div>
        <?php foreach (['invalid_votes' => 'Głosy nieważne', 'eligible' => 'Uprawnieni'] as $field => $label): ?>
            <?php if (isset(($precinct ?? $race)[$field])): ?><div><dt><?= $h($label) ?></dt><dd><?= $h($number(($precinct ?? $race)[$field])) ?></dd></div><?php endif; ?>
        <?php endforeach; ?>
    </dl>
    <?php if ($precinct && $counts === null): ?><p>Archiwum udostępnia dla tego obwodu liczbę głosów ważnych. Wyniki kandydatów są dostępne dla całego okręgu.</p><?php endif; ?>
    <?php if ($opts && (!$precinct || $counts !== null)): ?>
    <div class="ep-scroll" tabindex="0" role="region" aria-label="Wyniki głosowania"><table class="table ep-table">
        <caption><?= ($race['card_type'] ?? '') === 'yes_no' ? 'Głosowanie na jednego kandydata' : 'Kandydaci w tym głosowaniu' ?></caption>
        <thead><tr><th scope="col">Opcja na karcie</th><th scope="col">Komitet</th><th scope="col" class="ep-num">Głosy</th><th scope="col" class="ep-num">% ważnych</th><?php if (!$precinct): ?><th scope="col">Wynik kandydata</th><?php endif; ?></tr></thead>
        <tbody><?php foreach ($opts as $index => $item):
            $votes = $precinct ? ($counts[$index] ?? $counts[$item['code']] ?? null) : ($item['votes'] ?? null);
        ?>
            <tr><th scope="row"><?= $h($item['label'] ?? $item['name']) ?></th><td><?= $h($item['committee'] ?? '') ?></td>
                <td class="ep-num"><?= $h($number($votes)) ?></td><td class="ep-num"><?= $valid > 0 && $votes !== null ? $h($number($votes * 100 / $valid, 2)) . '%' : '—' ?></td>
                <?php if (!$precinct): ?><td><?= $h($isMayor ? ($item['status'] ?? '') : (!empty($item['elected']) ? 'Mandat' : '')) ?></td><?php endif; ?>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php if (!$isMayor && $valid !== null):
        $assigned = $precinct ? array_sum($counts) : array_sum(array_column($opts, 'votes'));
        if ($valid > $assigned): ?><p>Głosy ważne bez przypisania do kandydata w zestawieniu PKW: <strong><?= $h($number($valid - $assigned)) ?></strong>.</p><?php endif; ?>
    <?php endif; endif; ?>
    <?php if ($model['ballotUrls']): ?>
    <div class="ep-actions">
        <?php foreach ($model['ballotUrls'] as $wave => $link): ?><a class="btn" href="<?= $h($link) ?>">Pobierz falę <?= (int) $wave ?> (LSS)</a><?php endforeach; ?>
        <?php if ($model['exitPresetUrl']): ?><a class="btn" href="<?= $h($model['exitPresetUrl']) ?>">Przygotuj exit poll dla tej karty</a><?php endif; ?>
    </div>
    <?php endif; ?>
</section>
<?php if (!empty($race['precincts'])): ?>
<details class="ep-section"><summary>Obwody dla tej karty (<?= count($race['precincts']) ?>)</summary>
    <ul class="ep-links"><?php foreach ($race['precincts'] as $id => $row): ?>
        <li><a href="<?= $h($localUrl(['precinct' => $id])) ?>"><?= $h($row['name'] ?: 'Obwód') ?> <small><?= $h($id) ?></small></a></li>
    <?php endforeach; ?></ul>
</details>
<?php elseif (LcepLocalArchive::hasBallot($page)): ?><p class="ep-help">Ten zbiór nie zawiera przypisania obwodów do tej karty. Do losowania punktów exit poll potrzebny jest odrębny operat.</p><?php endif; ?>
<?php endif; ?>
<p class="ep-help">Źródło danych i definicje archiwalne · <a href="<?= $h([2014 => 'https://danewyborcze.kbw.gov.pl/index555d.html?title=Samorz%C4%85d_2014', 2018 => 'https://danewyborcze.kbw.gov.pl/indexd795.html', 2024 => 'https://danewyborcze.kbw.gov.pl/indexbea2.html'][$year]) ?>">KBW <?= $year ?></a></p>
