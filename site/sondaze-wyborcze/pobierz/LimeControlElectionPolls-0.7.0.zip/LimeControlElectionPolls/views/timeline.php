<?php
// SPDX-License-Identifier: GPL-2.0-or-later
$entries = [];
foreach (['wave1', 'wave2'] as $i => $key) {
    if (isset($config[$key])) {
        $entries[] = ['type' => 'wave', 'item' => $config[$key], 'title' => 'Fala ' . ($i + 1)];
    }
}
foreach ($events as $eventItem) {
    $entries[] = ['type' => 'event', 'item' => $eventItem, 'title' => $eventItem['title']];
}
usort($entries, static function ($a, $b) {
    return [$a['item']['start'], $a['type'] === 'event', $a['title']] <=> [$b['item']['start'], $b['type'] === 'event', $b['title']];
});
?>
<section class="ep-section" aria-labelledby="ep-timeline-title">
    <h2 id="ep-timeline-title">Oś czasu kampanii</h2>
    <?php if (!$events): ?><p>Brak wydarzeń w dzienniku tej kampanii.</p><?php endif; ?>
    <ol class="ep-events">
    <?php foreach ($entries as $entry):
        $item = $entry['item'];
    ?>
        <li>
            <small><?= $h($period($item['start'], $item['end'])) ?></small>
            <h3><?= $h($entry['title']) ?></h3>
            <?php if ($entry['type'] === 'wave'): ?>
                <p class="ep-muted">Okres prowadzenia wywiadów</p>
            <?php else: ?>
                <p><span class="ep-status"><?= $item['status'] === 'planned' ? 'Planowane' : 'Odbyło się' ?></span> · <?= $h($item['area']) ?></p>
                <?php if (!empty($item['note'])): ?><p><?= $h($item['note']) ?></p><?php endif; ?>
                <small>Źródło: <?= $h($item['source']) ?></small>
            <?php endif; ?>
        </li>
    <?php endforeach; ?>
    </ol>
    <?php if ($events): ?><p class="ep-help">Daty pozwalają ustalić kolejność wydarzeń i wywiadów. Wpływ wydarzenia na głosowanie wymaga odrębnego badania.</p><?php endif; ?>
</section>
