<?php
// SPDX-License-Identifier: GPL-2.0-or-later
$zone = new DateTimeZone('Europe/Warsaw');
$today = (new DateTimeImmutable('now', $zone))->format('Y-m-d');
$monthKey = $model['calendarMonth'] ?? null;
if ($monthKey === null) {
    $inProject = $agenda[0]['start'] <= $today && $today <= max(array_column($agenda, 'end'));
    $monthKey = substr($inProject ? $today : $planner['wave1']['start'], 0, 7);
}
$firstDay = new DateTimeImmutable($monthKey . '-01', $zone);
$last = (int) $firstDay->format('t');
$monthEnd = $firstDay->format('Y-m-t');
$offset = (int) $firstDay->format('N') - 1;
$months = [1 => 'Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec', 'Lipiec', 'Sierpień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień'];
$monthTitle = $months[(int) $firstDay->format('n')] . ' ' . $firstDay->format('Y');
$days = [];
foreach ($agenda as $index => $entry) {
    if ($entry['end'] < $monthKey . '-01' || $entry['start'] > $monthEnd) {
        continue;
    }
    $from = max($monthKey . '-01', $entry['start']);
    $to = min($monthEnd, $entry['end']);
    for ($i = (int) substr($from, -2); $i <= (int) substr($to, -2); ++$i) {
        $days[$i][] = $index;
    }
}
?>
<section class="ep-section" aria-labelledby="ep-planner-month">
    <h2 id="ep-planner-month">Kalendarz miesięczny</h2>
    <nav class="ep-actions ep-month-nav" aria-label="Zmiana miesiąca">
        <?php foreach (['-1 month' => 'Poprzedni miesiąc', '+1 month' => 'Następny miesiąc'] as $interval => $label):
            $target = $firstDay->modify($interval)->format('Y-m');
            if ($target >= '1900-01' && $target <= '9998-12'): ?>
                <a href="<?= $h($url(['tab' => 'planner', 'month' => $target])) ?>#ep-planner-month"><?= $label ?></a>
            <?php endif;
        endforeach; ?>
    </nav>
    <table class="table ep-month-table">
        <caption><?= $h($monthTitle) ?></caption>
        <thead><tr>
            <?php foreach (['Pon.' => 'Poniedziałek', 'Wt.' => 'Wtorek', 'Śr.' => 'Środa', 'Czw.' => 'Czwartek', 'Pt.' => 'Piątek', 'Sob.' => 'Sobota', 'Ndz.' => 'Niedziela'] as $short => $full): ?>
                <th scope="col" aria-label="<?= $full ?>"><?= $short ?></th>
            <?php endforeach; ?>
        </tr></thead>
        <tbody>
            <?php for ($start = 1 - $offset; $start <= $last; $start += 7): ?><tr>
                <?php for ($day = $start; $day < $start + 7; ++$day):
                    if ($day < 1 || $day > $last): ?><td></td><?php continue; endif;
                    $iso = sprintf('%s-%02d', $monthKey, $day); ?>
                    <td data-date="<?= $h($iso) ?>">
                        <time datetime="<?= $h($iso) ?>"<?= $iso === $today ? ' aria-current="date"' : '' ?>><?= $day ?></time>
                        <?php foreach ($days[$day] ?? [] as $index): $entry = $agenda[$index]; ?>
                            <a href="#ep-planner-item-<?= $h($entry['type'] . '-' . $entry['id']) ?>" aria-label="<?= $h($entry['title'] . ' · ' . $date($iso)) ?>">
                                <span class="ep-month-title"><?= $h($entry['title']) ?></span>
                                <span class="ep-month-mark" aria-hidden="true"><?php if ($entry['type'] === 'wave'): ?>F<?= (int) substr($entry['id'], -1) ?><?php else: ?><?= $entry['type'] === 'event' ? 'W' : 'Z' ?><?php endif; ?></span>
                            </a>
                        <?php endforeach; ?>
                    </td>
                <?php endfor; ?>
            </tr><?php endfor; ?>
        </tbody>
    </table>
    <?php if ($days): ?><p class="ep-help ep-month-key">F1 i F2 oznaczają fale, W oznacza wydarzenie, a Z zadanie. Wybierz wpis, aby przejść do szczegółów.</p>
    <?php else: ?><p class="ep-help">Brak wpisów w tym miesiącu.</p><?php endif; ?>
</section>
