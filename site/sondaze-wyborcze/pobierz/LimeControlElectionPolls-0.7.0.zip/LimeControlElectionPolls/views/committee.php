<?php
// SPDX-License-Identifier: GPL-2.0-or-later
$committee = $model['committee'] ?? null;
if (!$committee): ?>
    <section class="ep-section">
        <h2>Raport wymaga dwóch połączonych fal</h2>
        <?php if (!empty($model['canConfigure'])): ?>
            <a href="<?= $h($url(['tab' => 'setup'])) ?>">Skonfiguruj fale sondażu</a>
        <?php else: ?><p>Osoba prowadząca badanie może połączyć ankiety w ustawieniach fal.</p><?php endif; ?>
    </section>
<?php return; endif;

$catalog = $committee['catalog'];
$selected = $committee['selected'];
$selectionUrl = $url(['tab' => 'committee']);
// GET forms replace the action's query, which may also contain Yii's route.
parse_str((string) parse_url($selectionUrl, PHP_URL_QUERY), $routingParams);
$inputAreas = $committee['inputAreas'] ?? ($selected === [$committee['area']] ? [] : $selected);
$areaName = static function ($code) use ($catalog) { return $catalog[$code] ?? $code; };
?>
<p class="ep-committee-context"><strong><?= $h($committee['title']) ?></strong> · <?= $h($areaName($committee['area'])) ?></p>
<dl class="ep-facts ep-wave-dates">
    <?php foreach ([1, 2] as $n): $wave = $committee['wave' . $n]; ?>
        <div><dt>Wywiady w fali <?= $n ?></dt><dd><?= $h($period($wave['start'], $wave['end'])) ?></dd></div>
    <?php endforeach; ?>
</dl>
<form class="ep-section" method="get" action="<?= $h($selectionUrl) ?>" aria-labelledby="ep-compare-filter">
    <?php foreach ($routingParams as $key => $value): if (!is_scalar($value)) { continue; } ?>
        <input type="hidden" name="<?= $h($key) ?>" value="<?= $h($value) ?>">
    <?php endforeach; ?>
    <h2 id="ep-compare-filter">Wybór obszarów</h2>
    <p class="ep-help" id="ep-compare-help">Wyszukaj po nazwie lub kodzie i wybierz podpowiedź. Możesz zestawić maksymalnie cztery rozłączne obszary. Pozostaw wszystkie pola puste, aby zobaczyć cały projekt.</p>
    <div class="ep-grid ep-form-note ep-area-inputs">
        <?php for ($i = 0; $i < 4; $i++): ?>
            <label class="ep-field">Obszar <?= $i + 1 ?>
                <input class="input" type="text" name="areas[]" list="ep-committee-areas" autocomplete="off" aria-describedby="ep-compare-help" value="<?= $h($inputAreas[$i] ?? '') ?>">
            </label>
        <?php endfor; ?>
    </div>
    <datalist id="ep-committee-areas">
        <?php foreach ($catalog as $code => $name): ?><option value="<?= $h($code) ?>" label="<?= $h($name . ' · ' . $code) ?>"></option><?php endforeach; ?>
    </datalist>
    <div class="ep-actions">
        <button class="btn btn-primary" type="submit">Porównaj obszary</button>
        <?php if ($inputAreas): ?><a href="<?= $h($selectionUrl) ?>">Pokaż cały projekt</a><?php endif; ?>
    </div>
</form>
<?php
if (!$selected || !isset($committee['activity'])) { return; }
$activity = $committee['activity'];
$support = $committee['support'];
$formatMoney = static function (int $cents) use ($number): string {
    return $number(intdiv($cents, 100)) . ',' . str_pad((string) ($cents % 100), 2, '0', STR_PAD_LEFT) . ' zł';
};
$formatBudget = static function (array $budget, string $type) use ($formatMoney): string {
    if (!$budget['items']) {
        return 'Brak działań';
    }
    if ($budget[$type . '_missing'] === $budget['items']) {
        return 'Brak kwot';
    }
    return $formatMoney($budget[$type . '_cost']);
};
$formatChange = static function ($value) use ($number): string {
    return ($value > 0 ? '+' : '') . $number($value, 1);
};
$index = [];
$labels = [];
$showNotes = false;
foreach ($selected as $code) {
    $area = $support[$code];
    foreach ($area['waves'] as $wi => $wave) {
        $showNotes = $showNotes || $wave['status'] !== 'ready';
        foreach ($wave['rows'] as $row) {
            if ($row['kind'] !== 'list') { continue; }
            $labels[$row['code']] = $row['label'];
            $index[$code][$row['code']][$wi] = $row;
        }
    }
    foreach ($area['changes'] as $change) {
        $index[$code][$change['code']]['change'] = $change;
    }
}
?>
<section class="ep-section" aria-labelledby="ep-comparison-heading">
    <h2 id="ep-comparison-heading">Poparcie i koszty działań</h2>
    <p class="ep-help">Udziały oznaczają odsetek zdecydowanych w danej fali. Zmiana to różnica między drugą i pierwszą falą, w punktach procentowych.
        <?= $committee['weighted'] ? 'Odsetki i zmiany uwzględniają wagi badania.' : 'Odsetki obliczono bez wag.' ?>
        Daty pozwalają zestawić działania z terminami pomiarów. Ustalenie wpływu działania na poparcie wymaga osobnego badania.</p>
    <?php if (!$committee['mapped']): ?><p class="ep-help">W projekcie nie wskazano pytań o obszar. Poparcie jest dostępne dla całego projektu. Działania można zestawiać według ich obszaru.</p><?php endif; ?>
    <div class="ep-scroll" tabindex="0" role="region" aria-label="Tabela porównania obszarów">
        <table class="table ep-table ep-comparison">
            <caption>Porównanie obszarów</caption>
            <thead><tr><th scope="col">Wskaźnik</th>
                <?php foreach ($selected as $code): ?><th scope="col" data-area="<?= $h($code) ?>"><?= $h($areaName($code)) ?><small><?= $h($code) ?></small></th><?php endforeach; ?>
            </tr></thead>
            <tbody>
                <?php foreach (['planned' => 'Koszt planowany', 'actual' => 'Koszt rzeczywisty'] as $kind => $label): ?>
                    <tr data-metric="<?= $kind ?>_cost"><th scope="row"><?= $label ?></th>
                        <?php foreach ($selected as $code): $budget = $activity['areas'][$code]['budget']; ?>
                            <td data-area="<?= $h($code) ?>"><?= $h($formatBudget($budget, $kind)) ?>
                                <?php if ($budget[$kind . '_missing'] > 0): ?><small>Bez kwoty w <?= (int) $budget[$kind . '_missing'] ?> z <?= (int) $budget['items'] ?> poz.</small><?php endif; ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
                <?php foreach (['total' => 'Ukończone wywiady', 'decided' => 'Zdecydowani'] as $metric => $label): ?>
                    <tr data-metric="<?= $metric ?>"><th scope="row"><?= $label ?></th>
                        <?php foreach ($selected as $code): ?><td data-area="<?= $h($code) ?>">
                            <?php foreach ($support[$code]['waves'] as $wi => $wave): ?>
                                <span class="ep-wave-value" data-wave="<?= $wi + 1 ?>">Fala <?= $wi + 1 ?> · <?= $wave['status'] === 'ready' ? $h($number($wave[$metric])) : '—' ?></span>
                            <?php endforeach; ?>
                        </td><?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
                <?php foreach ($labels as $listCode => $label): ?>
                    <tr data-option="<?= $h($listCode) ?>"><th scope="row"><?= $h($label) ?></th>
                        <?php foreach ($selected as $code): $values = $index[$code][$listCode] ?? []; $delta = $values['change'] ?? null; ?>
                            <td data-area="<?= $h($code) ?>">
                                <?php foreach ([0, 1] as $wi): $value = $values[$wi]['percent'] ?? null; ?>
                                    <span class="ep-wave-value" data-wave="<?= $wi + 1 ?>">Fala <?= $wi + 1 ?> · <?= $value === null ? '—' : $h($number($value, 1) . '%') ?></span>
                                    <?php if (isset($values[$wi]['ci'][0], $values[$wi]['ci'][1])): ?>
                                        <small>95% PU <?= $h($number($values[$wi]['ci'][0], 1) . '–' . $number($values[$wi]['ci'][1], 1) . '%') ?></small>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                                <strong><?= $delta !== null ? $h($formatChange($delta['delta']) . ' p.p.') : 'Brak porównania' ?></strong>
                                <?php if (isset($delta['ci'][0], $delta['ci'][1])): ?>
                                    <small>95% przedział ufności zmiany<br><?= $h($formatChange($delta['ci'][0]) . ' do ' . $formatChange($delta['ci'][1]) . ' p.p.') ?></small>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if (!$labels): ?><p>Brak dostępnych udziałów list dla wybranych obszarów.</p><?php endif; ?>
    <details class="ep-source ep-report-notes"<?= $showNotes || !$labels ? ' open' : '' ?>>
        <summary>Podstawa porównania i dostępność wyników</summary>
        <?php if ($committee['design'] === 'independent_srs'): ?><p class="ep-help">Badacz zadeklarował dwie niezależne proste próby losowe. PU oznacza przybliżony 95% przedział ufności dla pojedynczego oszacowania.</p><?php endif; ?>
        <?php foreach ($selected as $code): ?>
            <h3><?= $h($areaName($code)) ?></h3>
            <?php foreach ($support[$code]['waves'] as $wi => $wave): ?>
                <p class="ep-help"><strong>Fala <?= $wi + 1 ?>.</strong> <?= $h($wave['reason']) ?>
                    <?php if (($wave['effective_n'] ?? null) !== null): ?>Efektywna liczebność Kisha wynosi <?= $h($number($wave['effective_n'], 1)) ?>.<?php endif; ?>
                </p>
            <?php endforeach; ?>
        <?php endforeach; ?>
    </details>
</section>
<?php
$statusLabels = ['planned' => 'Planowane', 'held' => 'Odbyło się', 'todo' => 'Do zrobienia', 'doing' => 'W toku', 'done' => 'Zakończone'];
$groups = $activity['areas'];
$groups['shared'] = $activity['shared'];
?>
<section class="ep-section" aria-labelledby="ep-report-activities">
    <h2 id="ep-report-activities">Działania na obszarach</h2>
    <p class="ep-help">Zestawienie obejmuje wydarzenia trwające choć jeden dzień od początku pierwszej do końca drugiej fali oraz zadania, których termin przypada w tym okresie. Koszt zadania dotyczy obszaru powiązanego wydarzenia.</p>
    <?php if (!empty($activity['outside_count'])): ?><p class="ep-help">Poza okresem porównania pozostaje <?= (int) $activity['outside_count'] ?> poz.</p><?php endif; ?>
    <?php foreach ($groups as $code => $group):
        $shared = $code === 'shared';
        $heading = $shared ? 'Działania wspólne' : $areaName($code);
        $headingId = 'ep-activity-' . str_replace(':', '-', $code);
    ?>
        <section class="ep-activity-group" data-area="<?= $h($code) ?>" aria-labelledby="<?= $h($headingId) ?>">
            <h3 id="<?= $h($headingId) ?>"><?= $h($heading) ?></h3>
            <?php if ($shared): ?>
                <p class="ep-help">Tu ujęto wydatki obejmujące szerszy teren oraz zadania przypisane do kampanii lub fali. Każda pozycja wspólna jest wykazana raz, poza kosztami poszczególnych obszarów.</p>
                <?php if ($group['items']): ?>
                    <dl class="ep-facts">
                        <?php foreach (['planned' => 'Wspólny koszt planowany', 'actual' => 'Wspólny koszt rzeczywisty'] as $type => $label): ?>
                            <div><dt><?= $label ?></dt><dd><?= $h($formatBudget($group['budget'], $type)) ?></dd>
                                <?php if ($group['budget'][$type . '_missing']): ?><dd><small>Brak kwoty w <?= (int) $group['budget'][$type . '_missing'] ?> poz.</small></dd><?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </dl>
                <?php endif; ?>
            <?php endif; ?>
            <?php if (!$group['items']): ?><p class="ep-muted">Brak działań w okresie porównania.</p>
            <?php else: ?>
                <div class="ep-scroll" tabindex="0" role="region" aria-label="<?= $h('Wykaz działań · ' . $heading) ?>">
                    <table class="table ep-table ep-activity-table">
                        <thead><tr><th scope="col">Działanie</th><th scope="col">Termin</th><th scope="col" class="ep-num">Koszt planowany</th><th scope="col" class="ep-num">Koszt rzeczywisty</th></tr></thead>
                        <tbody>
                            <?php foreach ($group['items'] as $entry): ?>
                                <tr><th scope="row"><span><?= $h($entry['title']) ?></span>
                                    <small><?= $entry['kind'] === 'event' ? 'Wydarzenie' : 'Zadanie' ?> · <?= $h($statusLabels[$entry['status']] ?? $entry['status']) ?></small>
                                    <?php if (!empty($entry['area_name'])): ?><small><?= $h($entry['area_name']) ?><?= !empty($entry['historical']) ? ' · obszar historyczny' : '' ?></small><?php endif; ?>
                                    <?php if (!empty($entry['event_title'])): ?><small>Wydarzenie · <?= $h($entry['event_title']) ?></small>
                                    <?php elseif ($entry['kind'] === 'task'): ?><small><?= $h(['wave1' => 'Fala 1', 'wave2' => 'Fala 2', 'project' => 'Cała kampania'][$entry['link']] ?? '') ?></small><?php endif; ?>
                                </th>
                                <td><?= $h($period($entry['start'], $entry['end'])) ?><small><?= $h($entry['wave_label']) ?></small></td>
                                <?php foreach (['planned_cost', 'actual_cost'] as $cost): ?><td class="ep-num"><?= $entry[$cost] === null ? 'Brak kwoty' : $h($formatMoney($entry[$cost])) ?></td><?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
    <?php endforeach; ?>
</section>
