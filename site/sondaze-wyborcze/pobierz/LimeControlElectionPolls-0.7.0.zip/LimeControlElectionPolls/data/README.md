# Wyniki PKW do sejmików

Wtyczka zawiera komplet głosów na listy w wyborach z 21 października 2018 r. i 7 kwietnia 2024 r. Dane pochodzą z oficjalnych protokołów obwodowych publikowanych przez KBW. Panel odczytuje je z zainstalowanej paczki, także bez dostępu do internetu. Każdy wynik ma mianownik równy sumie głosów ważnych na tej karcie. Udział procentowy obszaru wynika z liczby głosów. [KBW 2018](https://danewyborcze.kbw.gov.pl/indexd795.html) · [KBW 2024](https://danewyborcze.kbw.gov.pl/indexbea2.html)

| Elekcja | Obwody | Okręgi | Województwa / powiaty / gminy | Ważne głosy | Głosy w powiecie gdańskim |
| --- | ---: | ---: | ---: | ---: | ---: |
| 2018 | 26 983 | 85 | 16 / 380 / 2 477 | 15 433 536 | 43 134 |
| 2024 | 31 456 | 85 | 16 / 380 / 2 477 | 14 417 065 | 45 247 |

W obu latach wystartowało po 28 komitetów. Numer listy zależy od okręgu. W 2018 r. identyfikację zapewnia oznaczenie rejestracyjne komitetu w nagłówku protokołu. W 2024 r. dwa komitety o nazwie „KWW RUCH OBRONY POLSKI” otrzymały odrębne identyfikatory i dopisek województwa. Ich wyniki to 22 953 głosy w podkarpackim i 14 330 w śląskim. W kodach odpowiedzi, np. `C2401`, dwie cyfry oznaczają rok elekcji. Automatyczne łączenie komitetów po nazwie między latami prowadziłoby do błędnych porównań. [PKW, podkarpackie](https://samorzad2024.pkw.gov.pl/samorzad2024/pl/sejmik_wojewodztwa/okregi/180000) · [PKW, śląskie](https://samorzad2024.pkw.gov.pl/samorzad2024/pl/sejmik_wojewodztwa/okregi/240000)

Geografia przechowuje historyczne kody wyborcze PKW. Warszawa ma poziom miasta na prawach powiatu, gminy i 18 dzielnic. Dzielnice dzielą łączną sumę miasta. Dla każdej jednostki zachowane są właściwe okręgi i zestaw startujących tam list wraz z numerami. Pustą pozycję niedostępnej listy importer pomija. Wartość zero zachowuje jako zarejestrowaną listę bez głosów. Lista historyczna pokazuje stan konkretnej elekcji.

## Odtworzenie paczek

W katalogu projektu wtyczki uruchom poniższe polecenia. Wymagany jest Python 3.9 lub nowszy ze standardową biblioteką. PHP odczytuje standardowe pliki JSON dopuszczone przez instalator LimeSurvey. Kompresję zapewnia instalacyjny ZIP.

```sh
python3 -B scripts/import-pkw.py 2018
python3 -B scripts/import-pkw.py 2024
php tests/pkw.php
```

Importer pobiera tylko wskazane rewizje oficjalnych plików HTTPS, sprawdza ich SHA-256, dodaje odtwarzalne fragmenty danych i na koniec atomowo przełącza manifest danego roku. W środowisku offline można wskazać lokalne ZIP-y za pomocą `--protocols` i `--reference`, a dla 2024 r. dodatkowo `--candidates`. Opcja `--retrieved-on 2026-11-26` odtwarza datę pobrania dostarczonych plików. Opcja `--output KATALOG` pozwala zweryfikować nową wersję w odrębnym katalogu. Zmiana SHA źródła wymaga przeglądu jego schematu i kontroli sum przed aktualizacją przypiętej rewizji.

Pełne adresy, SHA-256 wejść i fragmentów wynikowych, wersja schematu, daty i raport uzgodnień są zapisane w [manifeście 2018](../LimeControlElectionPolls/data/pkw/2018.json) i [manifeście 2024](../LimeControlElectionPolls/data/pkw/2024.json).

## Jak sprawdzono wyniki

1. Każdy obwód ma dokładnie jeden protokół sejmikowy. Suma zarejestrowanych list zgadza się w każdym wierszu z liczbą głosów ważnych. Liczba obwodów, okręgów i ważnych głosów dla kraju zgadza się z rozdziałem 6 obwieszczenia danej elekcji. [Obwieszczenie 2018](https://eli.gov.pl/eli/DU/2018/2069/ogl) · [Obwieszczenie 2024](https://eli.gov.pl/eli/DU/2024/543/ogl)
2. Drugi zbiór, niezależnie opublikowane arkusze terytorialne XLSX, potwierdza rozkład głosów każdego z 28 komitetów w całym wektorze 2 494 jednostek najniższego poziomu. Są to gminy i dzielnice Warszawy. Arkusz gminny z 2024 r. pomija 65 innych miast na prawach powiatu, dla których odpowiedni wiersz znajduje się w arkuszu powiatowym. Porównano także mianowniki we wszystkich 380 powiatach i 16 województwach. [Arkusze 2018](https://danewyborcze.kbw.gov.pl/dane/2018/samorzad/2018-sejmiki.zip) · [Arkusze 2024](https://danewyborcze.kbw.gov.pl/dane/2024/samorzad/wyniki_glosowania_na_listy_kandydatow_do_sejmikow_wojewodztw.zip)
3. W użytej rewizji pomocniczego XLSX z 2024 r. w wierszu powiatu Warszawa widnieją 768 082 głosy ważne, a liczby we wszystkich kolumnach komitetów tego samego wiersza dają 237 990. Analogiczna niespójność kolumn występuje w 16 wierszach wojewódzkich. Każdy z tych przypadków jest wyszczególniony w `incomplete_reference_rows`. Panel prezentuje sumy z protokołów obwodowych. W 2018 r. sumy list we wszystkich sprawdzonych wierszach terytorialnych są zgodne.
4. Dodatkowe sprawdzenie 2024 r. wykorzystuje wynik każdego kandydata z osobnego eksportu. W 701 spośród 706 list okręgowych suma głosów kandydatów dokładnie odtwarza wynik listy. Dla pozostałych pięciu list arkusz ma sześć rekordów kandydatów z pustą liczbą głosów, a suma dostępnych wartości jest niższa od liczby głosów na listę w protokole. Odpowiednie pary wartości i okręgi zapisano w `partial_candidate_subtotals`. [Arkusz kandydatów KBW 2024](https://danewyborcze.kbw.gov.pl/dane/2024/samorzad/kandydaci_sejmiki_wojewodztw_csv.zip)
