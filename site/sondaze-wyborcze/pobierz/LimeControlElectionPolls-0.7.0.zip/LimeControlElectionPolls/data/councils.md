# Rady gmin, powiatów i dzielnic Warszawy

Archiwum obejmuje wybory powszechne z 16 listopada 2014, 21 października 2018 i 7 kwietnia 2024. Każdy rocznik zawiera 2477 rad gmin i miast, 314 rad powiatów i 18 rad dzielnic Warszawy. Podział terytorialny, okręgi, listy i kandydatury pochodzą z danego roku. Rady miast na prawach powiatu są dostępne wśród rad gmin. W Warszawie można osobno wybrać radę miasta albo radę dzielnicy. [Archiwum KBW 2014](https://danewyborcze.kbw.gov.pl/index555d.html?title=Samorz%C4%85d_2014), [2018](https://danewyborcze.kbw.gov.pl/indexd795.html) i [2024](https://danewyborcze.kbw.gov.pl/indexbea2.html).

| Rok | Organ | Okręgi | Głosy ważne | Wybrani radni | Rekordy obwód × okręg |
|---|---|---:|---:|---:|---:|
| 2014 | Rady gmin i miast | 38 139 | 13 432 331 | 39 536 | — |
| 2014 | Rady powiatów | 1 332 | 8 631 840 | 6 276 | — |
| 2014 | Rady dzielnic | 75 | 599 466 | 423 | — |
| 2018 | Rady gmin i miast | 33 429 | 15 617 257 | 39 524 | 42 645 |
| 2018 | Rady powiatów | 1 329 | 10 584 901 | 6 244 | 20 417 |
| 2018 | Rady dzielnic | 77 | 877 641 | 425 | 782 |
| 2024 | Rady gmin i miast | 33 566 | 14 259 304 | 39 416 | 44 830 |
| 2024 | Rady powiatów | 1 319 | 10 068 971 | 6 170 | 24 705 |
| 2024 | Rady dzielnic | 76 | 768 322 | 420 | 847 |

Mianownik w okręgu pochodzi z kolumny głosów ważnych w pliku kandydatów lub z sumy protokołów danego wyboru i okręgu. PKW podaje niekiedy głosy ważne, których eksport nie przypisuje indywidualnym kandydatom. To dotyczy 29 okręgów w 2014, 28 w 2018 i 13 w 2024. Raport powinien liczyć udziały kandydatów względem oficjalnego mianownika. W testach sumy krajowe mandatów i okręgów odniesiono do obwieszczeń. Za lata 2018 i 2024 sprawdzono także krajowe liczby głosów ważnych. [Obwieszczenia PKW z 2014](https://eli.gov.pl/eli/DU/2014/1640/ogl), [2018](https://eli.gov.pl/eli/DU/2018/2069/ogl) i [2024](https://eli.gov.pl/eli/DU/2024/543/ogl).

## Okręg i głosowanie

Karta dotyczy konkretnego organu, jednostki i okręgu. Opcje identyfikują kandydaturę w tym okręgu. Numery list i pozycje odtwarzają kolejność z archiwum. Dla gmin do 20 tys. w 2024 pole numeru pochodzi z kolumny „Numer na karcie do głosowania”. Dane zawierają nazwę komitetu i informację o mandacie. W 2024 oddzielono kandydatury z pustym polem liczby głosów i bez mandatu od kandydatów z oficjalnym wynikiem zero. Imiennicy zachowują osobne komitety, kody odpowiedzi i wyniki.

Status „bez głosowania” oznacza mandat przyznany bez oddania głosów w okręgu. Takich okręgów było 1733 w 2014, 3062 w 2018 i 3330 w 2024. Liczba głosów jest wtedy pusta. Dwa odrębne okręgi w 2018 miały wakat z powodu braku kandydatur. Są to okręg 6 w gminie o kodzie 160913 i okręg 5 w gminie 321602.

Operat z 2018 i 2024 obejmuje każdy okręg, w którym odbyło się głosowanie. Jeden obwód może obsługiwać kilka okręgów gminy. Rozmiar operatu w tabeli zlicza pary i nie mierzy liczby różnych lokali. Identyfikator obwodu łączy właściwy dla roku kod jednostki i numer komisji. W Warszawie uwzględnia kod dzielnicy. Sumę głosów ważnych i nazwę lokalu zapisano według protokołu. W 2018 dla większych gmin poza Warszawą arkusz obwodowy podaje głosy komitetów. Użytkownik widzi w takim obwodzie głosy ważne i pełny zestaw kandydatów z wynikiem dla całego okręgu. Indywidualne wyniki w obwodzie są dostępne, gdy można je uzgodnić z wynikami okręgu. W 2024 takie wyniki są dostępne dla wszystkich rekordów obwodowych. W 2014 wtyczka udostępnia wyniki okręgowe, bez przypisywania obwodów według granic z innych wyborów.

## Odtworzenie i kontrola

Importer wymaga Pythona 3.8 lub nowszego ze standardową biblioteką. Poniższe polecenia należy wykonać w katalogu projektu wtyczki. Pierwszy przebieg pobiera zestawy z KBW. Kolejne przebiegi mogą korzystać wyłącznie z plików w podanym katalogu. Importer sprawdza SHA-256 każdego archiwum względem pliku [council_sources.json](../scripts/council_sources.json). Manifest roku zawiera użyte adresy, sumy kontrolne, pokrycie i sumy terytorialne. Weryfikacja plików danych podczas odczytu wtyczki działa lokalnie.

```sh
python3 scripts/council_import.py --year 2014 --cache /tmp/lcep-pkw
python3 scripts/council_import.py --year 2018 --cache /tmp/lcep-pkw
python3 scripts/council_import.py --year 2024 --cache /tmp/lcep-pkw
php -d memory_limit=64M tests/councils.php
```

Importer zapisuje nowe dane w osobnym katalogu wersji i publikuje manifest roku przez atomową zamianę pliku. Test przechodzi przez wszystkie rady, okręgi i protokoły. Sprawdza sumy krajowe, zgodność mianowników na poziomach terytorialnych, zgodność kodów kandydatur, imienników i okręgi bez głosowania.
