# Wybory wójtów, burmistrzów i prezydentów miast

Wybierz rok, województwo, powiat i gminę. W gminie wybierz turę, aby zobaczyć kartę, liczbę uprawnionych, głosy ważne i nieważne oraz wynik każdego kandydata. W latach 2018 i 2024 można otworzyć też protokół obwodu. Udziały na karcie oblicza się względem głosów ważnych w wybranej turze i jednostce.

| Rok i tura | Gminy z głosowaniem | Karty TAK/NIE | Głosy ważne | Głosy nieważne | Wyniki obwodów w zbiorze |
|---|---:|---:|---:|---:|---:|
| 2014 I | 2 477 | 247 | 14 105 123 | 305 240 | tylko wynik gminny |
| 2014 II | 890 | 7 | 6 339 491 | 79 545 | tylko wynik gminny |
| 2018 I | 2 477 | 332 | 16 344 615 | 189 470 | 26 983 |
| 2018 II | 649 | 2 | 4 616 405 | 33 706 | 8 241 |
| 2024 I | 2 477 | 412 | 14 873 064 | 198 669 | 31 456 |
| 2024 II | 748 | 7 | 5 269 205 | 41 227 | 11 888 |

**Co oznaczają sumy na poziomie Polski, województwa i powiatu?** Liczba gmin w I turze obejmuje ówczesne jednostki terytorialne, a liczba głosowań obejmuje gminy, w których odbyły się wybory tego organu. W II turze zestawienie obejmuje gminy z ponownym głosowaniem. Głosy ważne i nieważne sumują się w obrębie pojedynczej tury. Kandydaci i komitety pozostają przypisani do swojej gminy.

**Kiedy pojawia się karta TAK/NIE?** W głosowaniu nad jedną kandydaturą archiwum pokazuje głosy za i przeciw, także w II turze. Przykładowo w gminie Daszyna w II turze 2018 r. spośród 1021 głosów ważnych oddano 740 za i 281 przeciw. Odrzucenie jedynego kandydata w danej turze jest oznaczone osobno. W tym przypadku wyboru dokonuje rada. Wskazanie wybranego w głosowaniu powszechnym pochodzi z pola mandatu w danych KBW. [Obwieszczenia PKW dla 2018 r., I tura](https://eli.gov.pl/eli/DU/2018/2070/ogl) i [II tura](https://eli.gov.pl/eli/DU/2018/2144/ogl).

**Dlaczego dla niektórych miejsc nie ma karty?** W listopadzie 2014 r. odrębne miasto i gmina wiejska Zielona Góra nie wybierały swoich organów. Po połączeniu jednostek wyznaczono głosowanie na 15 marca 2015 r. W 2018 r. szczególna ustawa wyłączyła gminę Ostrowice z wyborów. Takie rekordy mają status „bez głosowania”, puste opcje i brak liczbowego wyniku. Druga tura jest dostępna wyłącznie w gminach, w których się odbyła. [Wyjaśnienie PKW dla Zielonej Góry](https://samorzad2014.pkw.gov.pl/aktualnosci/0/91.html), [termin wyborów w 2015 r.](https://eli.gov.pl/eli/DU/2015/8/ogl), [ustawa dotycząca Ostrowic](https://eli.gov.pl/eli/DU/2018/1432/ogl).

**Skąd pochodzą liczby dla I tury 2014 r.?** Archiwum odwzorowuje arkusze gminne KBW. Zawierają 8029 kandydatów z wynikiem, 247 gmin z jedną kandydaturą i 30 439 334 uprawnionych. Obwieszczenie z 23 listopada podaje odpowiednio 8044 kandydatów, 251 gmin i 30 433 409 uprawnionych. Suma głosów ważnych i nieważnych z arkuszy to 14 410 363, a ogłoszona liczba ważnych kart to 14 409 923. Nazwiska osób wybranych w obu turach są zgodne z odrębnym wykazem wybranych KBW. Dokumenty zachowują własne zakresy i wartości. [Arkusze KBW 2014](https://danewyborcze.kbw.gov.pl/index555d.html?title=Samorz%C4%85d_2014), [obwieszczenie I tury](https://eli.gov.pl/eli/DU/2014/1642/ogl), [obwieszczenie II tury](https://eli.gov.pl/eli/DU/2014/1700/ogl).

**Jak archiwum może posłużyć do przygotowania exit poll?** Dla każdego głosowania z lat 2018 i 2024 dostępna jest lista rzeczywistych obwodów tej tury. Przed losowaniem do bieżącego badania trzeba sprawdzić aktualną listę obwodów i siedzib. Historyczna data oznacza ogólnopolski termin danej tury. Dla WBP w 2014 r. ten zestaw obejmuje dane gminne. Wykorzystanie takiego głosowania do losowania obwodów wymaga osobnego operatu. [KBW 2018](https://danewyborcze.kbw.gov.pl/indexd795.html), [KBW 2024](https://danewyborcze.kbw.gov.pl/indexbea2.html), [obwieszczenie PKW 2024 I tura](https://eli.gov.pl/eli/DU/2024/542/ogl), [II tura](https://eli.gov.pl/eli/DU/2024/617/ogl).

## Odtworzenie danych w repozytorium

Skrypt `scripts/mayor_import.py` i manifest `scripts/mayor_sources.json` zawierają bezpośrednie adresy archiwów, role plików i oczekiwane sumy SHA-256. W katalogu wtyczki wykonaj następujące polecenia. Python 3 i curl służą do budowy danych. Tylko do odczytu plików XLS z 2014 r. potrzebny jest pakiet xlrd. Dołączona paczka działa w PHP z lokalnych plików JSON.

```sh
python3 -m venv /tmp/lcep-pkw-tools
/tmp/lcep-pkw-tools/bin/pip install xlrd==2.0.2
/tmp/lcep-pkw-tools/bin/python scripts/mayor_import.py --year 2014 --source-dir /tmp/lcep-pkw --download
python3 scripts/mayor_import.py --year 2018 --source-dir /tmp/lcep-pkw --download
python3 scripts/mayor_import.py --year 2024 --source-dir /tmp/lcep-pkw --download
php -d memory_limit=32M tests/mayors.php
```

Opcja `--out` pozwala porównać odtworzony zestaw z paczką. Skrypt przelicza głosy każdego kandydata i obu odpowiedzi TAK/NIE, sprawdza sumy w każdym obwodzie i gminie oraz zgodność liczby głosów ważnych z odrębnym plikiem kandydatów. Dla I tury 2024 r. porównuje też nazwiska wybranych z odrębnym wykazem. Rekordy oznaczone w protokole jako skreślone lub pozbawione wyniku pozostają poza opcjami ankiety.

Każdy rocznik zawiera indeks i 16 plików wojewódzkich. Indeks podaje źródła oraz sumy SHA-256 plików. PHP sprawdza sumę pliku przed odczytem. `LcepMayorCatalog::area($year, 'G:020101', $round)` zwraca opcje oraz właściwe obwody. `totals($year, $area, $round)` dla PL, W, P i G zwraca liczbę jednostek, liczbę głosowań i sumy głosów ważnych i nieważnych. Brak tury zwraca `null`. Kody C001 i kolejne identyfikują kandydaturę w obrębie rocznika i gminy. Na karcie TAK/NIE stosowane są kody Y/N. W 2018 i 2024 opcje są ułożone według pozycji źródłowej na karcie, w 2014 zachowano kolejność w arkuszu KBW.
