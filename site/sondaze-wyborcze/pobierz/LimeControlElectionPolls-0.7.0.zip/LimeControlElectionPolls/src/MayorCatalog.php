<?php
// SPDX-License-Identifier: GPL-2.0-or-later

/** Official KBW executive election results, isolated by year, municipality and round. */
final class LcepMayorCatalog
{
    private const DATA = __DIR__ . '/../data/mayors/';
    private static $metadata = [];
    private static $shardKey;
    private static $records = [];

    public static function years(): array
    {
        return [2014, 2018, 2024];
    }

    public static function metadata(int $year): array
    {
        if (!in_array($year, self::years(), true)) {
            throw new InvalidArgumentException('Nieobsługiwany rok wyborów wójtów, burmistrzów i prezydentów miast.');
        }
        if (!isset(self::$metadata[$year])) {
            $raw = file_get_contents(self::DATA . $year . '.json');
            $index = $raw === false ? null : json_decode($raw, true);
            if (!is_array($index) || ($index['year'] ?? null) !== $year || empty($index['areas'])
                || !preg_match('/^' . $year . '-[a-f0-9]{16}$/D', $index['revision'] ?? '') || empty($index['totals'])
                || count($index['shards'] ?? []) !== 16 || count($index['dates'] ?? []) !== 2 || empty($index['sources'])) {
                throw new RuntimeException('Niekompletny indeks wyników wyborów PKW dla roku ' . $year . '.');
            }
            self::$metadata[$year] = $index;
        }
        return self::$metadata[$year];
    }

    public static function totals(int $year, string $area, int $round): ?array
    {
        if (!in_array($year, self::years(), true) || !in_array($round, [1,2], true)
            || !preg_match('/^(?:PL|W:[0-9]{2}|P:[0-9]{4}|G:[0-9]{6})$/D', $area)) {
            return null;
        }
        $values = self::metadata($year)['totals'][$area][$round] ?? null;
        if ($values === null) {
            return null;
        }
        return ['units' => $values[0], 'voted' => $values[1], 'valid_votes' => $values[2], 'invalid_votes' => $values[3]];
    }

    public static function area(int $year, string $code, int $round): ?array
    {
        if (!in_array($year, self::years(), true) || !preg_match('/^G:[0-9]{6}$/D', $code)
            || !in_array($round, [1,2], true)) {
            return null;
        }
        $meta = self::metadata($year);
        $area = $meta['areas'][$code] ?? null;
        if (!$area || !in_array($round, $area['rounds'], true)) {
            return null;
        }
        $province = substr($code, 2, 2);
        $key = $meta['revision'] . '/' . $province;
        if (self::$shardKey !== $key) {
            self::$records = [];
            self::$shardKey = null;
            $data = file_get_contents(self::DATA . $key . '.json');
            if ($data === false || hash('sha256', $data) !== ($meta['shards'][$province] ?? null)) {
                throw new RuntimeException('Uszkodzony plik wojewódzkich wyników wyborów PKW.');
            }
            self::$records = json_decode($data, true);
            if (!is_array(self::$records)) {
                throw new RuntimeException('Nie można odczytać wyników wyborów PKW.');
            }
            self::$shardKey = $key;
        }
        $record = self::$records[$code][$round] ?? null;
        if (!is_array($record)) {
            throw new RuntimeException('Brak wyników gminy lub tury wskazanej przez indeks PKW.');
        }
        foreach ($record['precincts'] as $number => $values) {
            $record['precincts'][$number] = [
                'name' => $values[0], 'eligible' => $values[1], 'invalid_votes' => $values[2],
                'valid_votes' => $values[3], 'options' => $values[4],
            ];
        }
        return ['code' => $code, 'year' => $year, 'round' => $round] + $area + $record;
    }
}
