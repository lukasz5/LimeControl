<?php
// SPDX-License-Identifier: GPL-2.0-or-later

require_once __DIR__ . '/PollAnalysis.php';

/** Maps only the selected survey columns using the API of the installed LimeSurvey version. */
final class LcEpPollSurvey
{
    private $survey;
    private $choice;
    private $weight;
    private $geoCode;
    private $geoQuestion;
    private $geoOptions;
    private $labels = [];

    public function __construct(array $wave)
    {
        $this->survey = Survey::model()->findByPk($wave['sid']);
        if (!$this->survey || !$this->survey->getIsAnonymized()) {
            throw new DomainException('Obie ankiety fal muszą istnieć i mieć włączone anonimowe odpowiedzi.');
        }
        $this->choice = $this->question($wave['question'], ['L', '!']);
        if ($this->choice->other === 'Y') {
            throw new DomainException('Użyj zamkniętej listy bez pola tekstowego „Inne”.');
        }
        if (($wave['weight'] ?? '') !== '') {
            $this->weight = $this->question($wave['weight'], ['N']);
        }
        $this->geoCode = $wave['geo'] ?? '';
        $rows = App()->db->createCommand()->select('a.code, l.answer')->from('{{answers}} a')
            ->join('{{answer_l10ns}} l', 'l.aid = a.aid')
            ->where('a.qid = :q AND a.scale_id = 0 AND l.language = :lang',
                [':q' => $this->choice->qid, ':lang' => $this->survey->language])
            ->order('a.sortorder, a.aid')->queryAll();
        foreach ($rows as $row) {
            $this->labels[(string)$row['code']] = self::plain($row['answer']);
        }
        if (count(array_diff_key($this->labels, LcEpPollAnalysis::SPECIAL)) === 0) {
            throw new DomainException('W pytaniu brakuje opcji głosowania w bazowym języku ankiety.');
        }
    }

    private static function plain($text)
    {
        return trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags((string)$text), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
    }

    private function question($code, array $types)
    {
        $matches = Question::model()->findAllByAttributes([
            'sid' => (int)$this->survey->sid, 'parent_qid' => 0, 'title' => $code,
        ]);
        if (count($matches) !== 1 || !in_array((string)$matches[0]->type, $types, true)) {
            throw new DomainException('Sprawdź kod i typ pytania w obu ankietach. Wybór wymaga listy pojedynczego wyboru, a waga pola liczbowego.');
        }
        return $matches[0];
    }

    /** Includes wording and order so a later questionnaire edit requires an explicit mapping review. */
    public function signature()
    {
        $wording = App()->db->createCommand()->select('question')->from('{{question_l10ns}}')
            ->where('qid = :q AND language = :l', [':q' => $this->choice->qid, ':l' => $this->survey->language])->queryScalar();
        $definition = [(string)$this->survey->language, self::plain($wording), $this->labels];
        return hash('sha256', json_encode($definition, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }

    /** Replacing a mapped question under its old code is a change even if its labels still match. */
    public function identity($includeGeography = true)
    {
        $ids = [(int)$this->choice->qid, $this->weight ? (int)$this->weight->qid : null];
        if ($includeGeography && $this->geoCode !== '') {
            $ids[] = (int)$this->geography()->qid;
        }
        return $ids;
    }

    private function geography()
    {
        if ($this->geoQuestion === null) {
            $question = $this->question($this->geoCode, ['L', '!']);
            if ((int)$question->qid === (int)$this->choice->qid || $question->other === 'Y') {
                throw new DomainException('Obszar wymaga osobnego pytania z zamkniętą listą pojedynczego wyboru.');
            }
            $this->geoQuestion = $question;
        }
        return $this->geoQuestion;
    }

    private function geoOptions()
    {
        if ($this->geoOptions !== null) {
            return $this->geoOptions;
        }
        $question = $this->geography();
        $options = App()->db->createCommand()->select('a.code, l.answer')->from('{{answers}} a')
            ->leftJoin('{{answer_l10ns}} l', 'l.aid = a.aid AND l.language = :lang', [':lang' => $this->survey->language])
            ->where('a.qid = :qid AND a.scale_id = 0', [':qid' => $question->qid])->queryAll();
        $labels = [];
        $seenAreas = [];
        $level = null;
        foreach ($options as $option) {
            $code = (string)$option['code'];
            $label = self::plain($option['answer']);
            if ($label === '' || !preg_match('/^[[:alnum:]]{1,5}$/uD', $code) || isset($labels[$code])) {
                throw new DomainException('Uzupełnij niepowtarzalne kody i etykiety obszarów w języku bazowym obu ankiet.');
            }
            $area = null;
            $prefix = preg_match('/^((?:W:[0-9]{2}|P:[0-9]{4}|[GB]:[0-9]{6}))(?=$|[\s·–—-])/u', $label, $match) ? $match[1] : null;
            if (!in_array($code, ['DK', 'REF'], true)) {
                // LimeSurvey limits a native answer code to five characters. A label prefix can carry a full gmina or borough code.
                $short = preg_match('/^(?:W[0-9]{2}|P[0-9]{4})$/D', $code) ? $code[0] . ':' . substr($code, 1) : null;
                $area = $prefix ?? $short;
                if ($area === null || ($short !== null && $short !== $area) || isset($seenAreas[$area])
                    || ($level !== null && $level !== $area[0])) {
                    throw new DomainException('Przypisz każdej opcji odrębny obszar jednego poziomu PKW. Etykietę rozpocznij np. od G:220404. Dla powiatu lub województwa możesz użyć kodu odpowiedzi P2204 lub W22.');
                }
                $seenAreas[$area] = true;
                $level = $area[0];
            } elseif ($prefix !== null) {
                throw new DomainException('Kody DK i REF są zarezerwowane dla odpowiedzi bez wskazanego obszaru.');
            }
            $labels[$code] = ['label' => $label, 'area' => $area];
        }
        if ($level === null) {
            throw new DomainException('Lista odpowiedzi na pytanie o obszar nie zawiera kodu PKW.');
        }
        ksort($labels, SORT_STRING);
        return $this->geoOptions = $labels;
    }

    /** Definition from the questionnaire, including options with no recorded interviews. */
    public function geoMap(): array
    {
        if ($this->geoCode === '') {
            return [];
        }
        $map = [];
        foreach ($this->geoOptions() as $code => $entry) {
            if ($entry['area'] !== null) {
                $map[$code] = $entry['area'];
            }
        }
        return $map;
    }

    public function geoCodes(): array
    {
        return array_values($this->geoMap());
    }

    public function geoSignature(): ?string
    {
        if ($this->geoCode === '') {
            return null;
        }
        $wording = App()->db->createCommand()->select('question')->from('{{question_l10ns}}')
            ->where('qid = :q AND language = :l', [':q' => $this->geography()->qid, ':l' => $this->survey->language])->queryScalar();
        $definition = [(string)$this->survey->language, self::plain($wording), $this->geoOptions()];
        return hash('sha256', json_encode($definition, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    }

    private function field($question, $schema)
    {
        foreach (createFieldMap($this->survey, 'full', true, (int)$question->qid, $this->survey->language) as $entry) {
            if ((int)$entry['qid'] === (int)$question->qid && (string)($entry['aid'] ?? '') === '') {
                $name = (string)$entry['fieldname'];
                if (isset($schema->columns[$name])) {
                    return $name;
                }
            }
        }
        throw new DomainException('Bieżąca tabela odpowiedzi nie zawiera przypisanego pytania.');
    }

    public function estimate(array $wave, $design)
    {
        [$groups, $note] = $this->buckets($wave, false);
        return $this->estimateBuckets($wave, $design, $groups[''] ?? [], $note);
    }

    public function estimateBuckets(array $wave, $design, array $buckets, string $note)
    {
        return LcEpPollAnalysis::estimate($wave, $this->labels, $buckets, $design, $note);
    }

    /** Only aggregate count, sum of weights and sum of squared weights leave this method. */
    public function buckets(array $wave, bool $geographic): array
    {
        if (!$this->survey->getIsActive()) {
            throw new DomainException('Brak aktywnej tabeli odpowiedzi. Po zakończeniu terenu ustaw datę wygaśnięcia ankiety zamiast jej dezaktywacji.');
        }
        $model = Response::model((int)$this->survey->sid);
        $schema = $model->getTableSchema();
        $field = $this->field($this->choice, $schema);
        $command = App()->db->createCommand()->from($model->tableName())->where('submitdate IS NOT NULL');
        if (isset($schema->columns['quota_exit'])) {
            $command->andWhere('(quota_exit IS NULL OR quota_exit = 0)');
        }
        if ($this->survey->getIsDateStamp()) {
            $exclusiveEnd = (new DateTimeImmutable($wave['end']))->modify('+1 day')->format('Y-m-d');
            $command->andWhere('submitdate >= :from AND submitdate < :until', [
                ':from' => $wave['start'] . ' 00:00:00', ':until' => $exclusiveEnd . ' 00:00:00',
            ]);
            $note = 'Ukończone wywiady z okresu fali według dat zapisu LimeSurvey.';
        } else {
            // LS stores a fixed submitdate (1980-01-01) when date stamping is off.
            $note = 'Termin zadeklarowany przez badacza. Zliczono wszystkie ukończone wywiady w ankiecie przeznaczonej wyłącznie dla tej fali.';
        }

        $groups = [];
        $columns = [$field . ' AS answer_code'];
        $groupBy = [$field];
        $geo = $geographic ? $this->geography() : null;
        if ($geo) {
            $areaField = $this->field($geo, $schema);
            $columns[] = $areaField . ' AS area_code';
            $groupBy[] = $areaField;
        }
        if (!$this->weight && $this->choice->encrypted !== 'Y' && (!$geo || $geo->encrypted !== 'Y')) {
            $columns[] = 'COUNT(*) AS responses';
            $rows = $command->select($columns)->group($groupBy)->queryAll();
            foreach ($rows as $row) {
                $area = (string)($row['area_code'] ?? '');
                $key = (string)$row['answer_code'];
                $n = (int)$row['responses'] + ($groups[$area][$key]['count'] ?? 0);
                $groups[$area][$key] = ['count' => $n, 'w' => $n, 'w2' => $n];
            }
        } else {
            if ($this->weight) {
                $columns[] = $this->field($this->weight, $schema) . ' AS survey_weight';
            }
            $reader = $command->select($columns)->query();
            try {
                foreach ($reader as $row) {
                    $key = $this->decode($row['answer_code'], $this->choice);
                    $area = $geo ? $this->decode($row['area_code'], $geo) : '';
                    $weight = 1.0;
                    if ($this->weight) {
                        $value = $this->decode($row['survey_weight'], $this->weight);
                        if (!is_numeric($value) || !is_finite((float)$value) || (float)$value <= 0) {
                            throw new DomainException('Ukończony wywiad ma pustą lub niepoprawną wagę. Uzupełnij dodatnie, skończone wagi przed raportowaniem.');
                        }
                        $weight = (float)$value;
                    }
                    if (!isset($groups[$area][$key])) {
                        $groups[$area][$key] = ['count' => 0, 'w' => 0.0, 'w2' => 0.0];
                    }
                    $groups[$area][$key]['count']++;
                    $groups[$area][$key]['w'] += $weight;
                    $groups[$area][$key]['w2'] += $weight * $weight;
                }
            } finally {
                $reader->close();
            }
        }
        return [$groups, $note];
    }

    private function decode($value, $question)
    {
        if ($value === null || $value === '' || $question->encrypted !== 'Y') {
            return (string)$value;
        }
        $decoded = Response::decryptSingle($value);
        if ($decoded === '') {
            throw new DomainException('Nie udało się odczytać zaszyfrowanego pola. Sprawdź klucz instalacji LimeSurvey.');
        }
        return $decoded;
    }
}
