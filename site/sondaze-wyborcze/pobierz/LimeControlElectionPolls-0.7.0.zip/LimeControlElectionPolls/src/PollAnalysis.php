<?php
// SPDX-License-Identifier: GPL-2.0-or-later

/** Survey estimates and fieldwork comparisons. Receives aggregates, never participant records. */
final class LcEpPollAnalysis
{
    const MIN_COMPLETED = 30;
    const MIN_CELL = 5;
    // The empty code is the missing answer. All other unreserved codes identify lists on the ballot.
    const SPECIAL = ['' => 'missing', 'DK' => 'undecided', 'REF' => 'refused', 'NOST' => 'nonvoter'];

    public static function unavailable(array $wave, $reason, $status = 'unavailable')
    {
        return $wave + [
            'status' => $status, 'reason' => $reason, 'total' => null, 'decided' => null,
            'effective_n' => null, 'rows' => [],
        ];
    }

    /**
     * Each bucket has count, w (sum of weights), w2 (sum of squared weights).
     * List shares use decided responses. Other categories use all completed responses.
     */
    public static function estimate(array $wave, array $labels, array $buckets, $design, $dateNote)
    {
        $labels[''] = 'Brak odpowiedzi';
        $total = 0;
        $decided = 0;
        $totalWeight = 0.0;
        $decidedWeight = 0.0;
        $sumSquared = 0.0;
        $small = false;
        foreach ($buckets as $code => $values) {
            if (!array_key_exists($code, $labels)) {
                return self::unavailable($wave, 'Odpowiedzi zawierają kod spoza aktualnego słownika. Sprawdź mapowanie pytania.');
            }
            $count = (int)$values['count'];
            $total += $count;
            $totalWeight += $values['w'];
            $sumSquared += $values['w2'];
            if (!isset(self::SPECIAL[$code])) {
                $decided += $count;
                $decidedWeight += $values['w'];
            }
            $small = $small || ($count > 0 && $count < self::MIN_CELL);
        }
        if ($total < self::MIN_COMPLETED || $small) {
            // Hide both denominators and *all* rows. Hiding a single cell would allow subtraction.
            return self::unavailable($wave, 'Wyniki ukryte ze względu na liczebność fali lub jednej z kategorii.', 'suppressed');
        }
        if (!is_finite($totalWeight) || !is_finite($sumSquared) || $totalWeight <= 0 || $sumSquared <= 0) {
            return self::unavailable($wave, 'Wagi fali mają niepoprawne wartości.');
        }
        $weighted = ($wave['weight'] ?? '') !== '';
        $rows = [];
        foreach ($labels as $code => $label) {
            $code = (string)$code;
            $kind = self::SPECIAL[$code] ?? 'list';
            $base = $kind === 'list' ? $decided : $total;
            $weightBase = $kind === 'list' ? $decidedWeight : $totalWeight;
            $n = (int)($buckets[$code]['count'] ?? 0);
            $w = $buckets[$code]['w'] ?? 0.0;
            $rows[] = [
                'code' => $code, 'label' => $label, 'kind' => $kind, 'count' => $n,
                'raw_percent' => $base ? 100.0 * $n / $base : null,
                'percent' => $weightBase > 0 ? 100.0 * $w / $weightBase : null,
                'ci' => $design === 'independent_srs' && !$weighted && $base ? self::wilson($n, $base) : null,
            ];
        }
        return $wave + [
            'status' => 'ready', 'reason' => $dateNote, 'total' => $total, 'decided' => $decided,
            'effective_n' => $weighted ? ($totalWeight / sqrt($sumSquared)) ** 2 : null,
            'rows' => $rows,
        ];
    }

    /** Wilson score interval, percentage units. */
    private static function wilson($count, $n)
    {
        $z = 1.959963984540054;
        $p = $count / $n;
        $d = 1 + $z * $z / $n;
        $middle = ($p + $z * $z / (2 * $n)) / $d;
        $radius = $z * sqrt($p * (1 - $p) / $n + $z * $z / (4 * $n * $n)) / $d;
        return [100 * max(0.0, $middle - $radius), 100 * min(1.0, $middle + $radius)];
    }

    public static function changes(array $first, array $second)
    {
        if ($first['status'] !== 'ready' || $second['status'] !== 'ready') {
            return [];
        }
        $prior = array_column($first['rows'], null, 'code');
        $changes = [];
        foreach ($second['rows'] as $row) {
            $code = $row['code'];
            $old = $prior[$code] ?? null;
            if (!$old || $old['percent'] === null || $row['percent'] === null) {
                continue;
            }
            $delta = $row['percent'] - $old['percent'];
            $interval = null;
            if ($row['ci'] && $old['ci']) {
                // Newcombe's unpaired difference interval from two Wilson score intervals.
                $interval = [
                    $delta - hypot($row['percent'] - $row['ci'][0], $old['ci'][1] - $old['percent']),
                    $delta + hypot($row['ci'][1] - $row['percent'], $old['percent'] - $old['ci'][0]),
                ];
            }
            $changes[] = ['code' => $code, 'label' => $row['label'], 'kind' => $row['kind'],
                'delta' => $delta, 'ci' => $interval];
        }
        return $changes;
    }

    /** Relations use inclusive calendar days of fieldwork, never a publication timestamp. */
    public static function eventRelation(array $event, array $first, array $second)
    {
        if ($event['status'] === 'planned') {
            return ['relation' => 'planned', 'note' => 'Wydarzenie planowane. Realizacja nie jest jeszcze potwierdzona.'];
        }
        $overlaps = [];
        foreach ([$first, $second] as $index => $wave) {
            if ($wave['start'] <= $event['end'] && $wave['end'] >= $event['start']) {
                $overlaps[] = (string)($index + 1);
            }
        }
        if ($overlaps) {
            return ['relation' => 'overlap', 'note' => 'Okres wydarzenia nakłada się na teren fali: ' . implode(' i ', $overlaps) . '.'];
        }
        if ($event['end'] < $first['start']) {
            return ['relation' => 'before', 'note' => 'Obie fale przeprowadzono po wydarzeniu.'];
        }
        if ($event['start'] > $second['end']) {
            return ['relation' => 'after', 'note' => 'Obie fale przeprowadzono przed wydarzeniem.'];
        }
        return ['relation' => 'between', 'note' => 'Fala 1 przed wydarzeniem, fala 2 po nim. Zbieżność w czasie nie dowodzi wpływu wydarzenia.'];
    }
}
