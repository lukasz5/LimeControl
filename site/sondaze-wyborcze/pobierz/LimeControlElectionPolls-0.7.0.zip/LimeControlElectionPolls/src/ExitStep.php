<?php
// SPDX-License-Identifier: GPL-2.0-or-later

/** Integer steps calibrated on the complete planning frame before drawing any precincts. */
final class LcepExitStep
{
    const MAX_STEP = 1000;

    public static function forPoint(array $plan, array $point): int
    {
        // Stored fixed designs from releases through 0.4 have only the project-wide step.
        $step = $point['step'] ?? null;
        if ($step === null && ($plan['step_mode'] ?? 'fixed') === 'fixed') {
            $step = $plan['step'] ?? null;
        }
        if (!is_int($step) || $step < 1 || $step > self::MAX_STEP) {
            throw new DomainException('W zapisanym planie brakuje poprawnego kroku obwodu.');
        }
        return $step;
    }

    /** Return point code => step, matching expected invitations under the fixed reference step. */
    public static function allocate(array $frame, int $perStratum, int $referenceStep, string $mode = 'size'): array
    {
        if (!$frame || $perStratum < 1 || $referenceStep < 1 || $referenceStep > self::MAX_STEP) {
            throw new DomainException('Sprawdź operat, liczbę obwodów na warstwę i krok referencyjny.');
        }
        if (!in_array($mode, ['size', 'size_small'], true)) {
            throw new DomainException('Nieznany sposób doboru kroku według wielkości obwodu.');
        }
        ksort($frame, SORT_STRING);
        $totals = [];
        foreach ($frame as $point) {
            if (!isset($point['stratum'], $point['size']) || !is_int($point['size']) || $point['size'] < 0
                || $point['size'] > 99999999) {
                throw new DomainException('Podaj nieujemną całkowitą wielkość każdego obwodu.');
            }
            $h = $point['stratum'];
            $totals[$h] = ($totals[$h] ?? 0) + 1;
        }
        // Group equal sizes; their local steps must be identical even at a rounding boundary.
        $masses = [];
        foreach ($frame as $point) {
            $size = $point['size'];
            if ($size > 0) {
                $total = $totals[$point['stratum']];
                $mass = $size * min($total, $perStratum) / $total;
                $masses[$size] = ($masses[$size] ?? 0.0) + $mass;
            }
        }
        if (!$masses) {
            throw new DomainException('Co najmniej jeden obwód musi mieć dodatnią wielkość.');
        }
        ksort($masses, SORT_NUMERIC);
        $totalMass = array_sum($masses);
        $target = $totalMass / $referenceStep;
        $cap = PHP_FLOAT_MAX;
        if ($mode === 'size_small') {
            $expectedPoints = 0;
            foreach ($totals as $total) {
                $expectedPoints += min($total, $perStratum);
            }
            $cap = 0.25 * $totalMass / $expectedPoints;
        }
        $lo = 0.0;
        $hi = $referenceStep / min(array_key_first($masses), $cap);
        // Expected invitations decrease in jumps. Retain both sides of the target crossing.
        for ($i = 0; $i < 70; ++$i) {
            $mid = ($lo + $hi) / 2;
            if ($mid === $lo || $mid === $hi) {
                break;
            }
            if (self::workload($masses, $mid, $cap) > $target) {
                $lo = $mid;
            } else {
                $hi = $mid;
            }
        }
        $above = self::workload($masses, $lo, $cap) - $target;
        $below = $target - self::workload($masses, $hi, $cap);
        // At equal absolute distance take the lower expected workload.
        $scale = $above + 16 * PHP_FLOAT_EPSILON * $target >= $below ? $hi : $lo;
        $steps = [];
        foreach ($frame as $code => $point) {
            $steps[$code] = self::stepAt(min($point['size'], $cap), $scale);
        }
        return $steps;
    }

    private static function stepAt(float $size, float $scale): int
    {
        return (int) max(1, min(self::MAX_STEP, floor($scale * $size + 0.5)));
    }

    private static function workload(array $masses, float $scale, float $cap): float
    {
        $expected = 0.0;
        foreach ($masses as $size => $mass) {
            $expected += $mass / self::stepAt(min($size, $cap), $scale);
        }
        return $expected;
    }
}
