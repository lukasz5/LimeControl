<?php
// SPDX-License-Identifier: GPL-2.0-or-later
require_once __DIR__ . '/ExitStep.php';

/** Project-level pattern-mixture scenarios for unit refusals on the frozen exit-poll ballot. */
final class LcepExitSensitivity
{
    const ODDS_MULTIPLIERS = [0.25, 0.5, 1.0, 2.0, 4.0];

    public static function calculate(array $plan, array $batches, array $exit): array
    {
        if ($exit['status'] !== 'ready' || $exit['protocol_count'] !== 0) {
            return ['status' => 'unavailable'];
        }
        $byPoint = [];
        foreach ($batches as $batch) {
            $byPoint[$batch['point']][$batch['shift']] = $batch;
        }
        $imputed = array_fill_keys(array_keys($exit['shares']), 0.0);
        $valid = 0.0;
        $refusals = 0;
        $refusalsWithDonors = 0;
        $points = 0;
        $exclusive = [];
        $groupVotes = [];
        foreach ($plan['points'] as $code => $point) {
            $stratum = $plan['strata'][$point['stratum']];
            $designWeight = LcepExitStep::forPoint($plan, $point) * $stratum['total'] / $stratum['sample'];
            $pointGroups = [];
            foreach ([1, 2] as $shift) {
                $batch = $byPoint[$code][$shift] ?? [];
                if (empty($batch['completed']) || !isset($batch['refused'])) {
                    return ['status' => 'unavailable'];
                }
                $done = $batch['completed'];
                $selected = $batch['invited'] + $batch['missed'];
                $refused = $batch['refused'];
                $refusals += $refused;
                $validInShift = array_sum($batch['votes']);
                if (!$validInShift) {
                    continue;
                }
                $refusalsWithDonors += $refused;
                $valid += $validInShift * $designWeight * $selected / $done;
                $group = self::fractionKey($refused, $selected);
                $pointGroups[$group] = true;
                foreach ($batch['votes'] as $option => $count) {
                    if ($count > 0) {
                        $imputed[$option] += $count * $designWeight * $refused / $done;
                        $groupVotes[$group][$option] = ($groupVotes[$group][$option] ?? 0) + $count;
                    }
                }
            }
            if ($pointGroups) {
                ++$points;
                if (count($pointGroups) === 1) {
                    $group = array_key_first($pointGroups);
                    $exclusive[$group] = ($exclusive[$group] ?? 0) + 1;
                }
            }
        }
        if ($refusals === 0) {
            return ['status' => 'no_refusals'];
        }
        if ($refusals < 5 || ($refusalsWithDonors > 0 && $refusalsWithDonors < 5)
            || !self::canRelease($groupVotes, $exclusive, $points)) {
            return ['status' => 'protected'];
        }
        $refusalValid = array_sum($imputed);
        if ($refusalValid <= 0.0 || $valid <= 0.0) {
            return ['status' => 'no_valid_refusals'];
        }
        $fraction = $refusalValid / $valid;
        $rows = [];
        foreach ($exit['shares'] as $option => $neutral) {
            $q = $imputed[$option] / $refusalValid;
            foreach (self::ODDS_MULTIPLIERS as $theta) {
                $adjusted = $theta * $q / (1.0 - $q + $theta * $q);
                $modeled = $neutral + 100.0 * $fraction * ($adjusted - $q);
                $rows[$option][] = $theta === 1.0 ? $neutral : max(0.0, min(100.0, $modeled));
            }
        }
        return ['status' => 'ready', 'refusal_share_percent' => 100.0 * $fraction, 'shares' => $rows];
    }

    /** Return an exact key for the ratio of imputed refusal weight to baseline weight in one shift. */
    private static function fractionKey(int $refused, int $selected): string
    {
        $a = $refused;
        $b = $selected;
        while ($b > 0) {
            [$a, $b] = [$b, $a % $b];
        }
        return intdiv($refused, $a) . '/' . intdiv($selected, $a);
    }

    private static function canRelease(array $groupVotes, array $exclusive, int $points): bool
    {
        // With constant refusal weight fraction the imputed composition equals the baseline.
        if (count($groupVotes) <= 1) {
            return true;
        }
        $total = [];
        $largest = [];
        foreach ($groupVotes as $group => $counts) {
            // Subtracting a multiple of the baseline can cancel every shift with this fraction.
            // Withhold the whole table if the remaining contrast would isolate one precinct.
            if ($points - ($exclusive[$group] ?? 0) < 2) {
                return false;
            }
            foreach ($counts as $option => $n) {
                $total[$option] = ($total[$option] ?? 0) + $n;
                $largest[$option] = max($largest[$option] ?? 0, $n);
            }
        }
        foreach ($total as $option => $n) {
            $outside = $n - $largest[$option];
            if ($outside > 0 && $outside < 5) {
                return false;
            }
        }
        return true;
    }
}
