<?php
// SPDX-License-Identifier: GPL-2.0-or-later

require_once __DIR__ . '/CouncilCatalog.php';
require_once __DIR__ . '/MayorCatalog.php';

/** Resolve the election, area, constituency and round together before serving results or a ballot. */
final class LcepLocalArchive
{
    const ORGANS = [
        'sejmik' => 'Sejmiki województw', 'gmina' => 'Rady gmin i miast', 'powiat' => 'Rady powiatów',
        'dzielnica' => 'Rady dzielnic Warszawy', 'mayor' => 'Wójtowie, burmistrzowie i prezydenci miast',
    ];

    public static function years($organ)
    {
        if ($organ === 'mayor') {
            return LcepMayorCatalog::years();
        }
        if (!isset(self::ORGANS[$organ]) || $organ === 'sejmik') {
            throw new InvalidArgumentException('Nieobsługiwany organ.');
        }
        return LcepCouncilCatalog::years();
    }

    private static function parent($code)
    {
        switch (substr($code, 0, 2)) {
            case 'W:': return 'PL';
            case 'P:': return 'W:' . substr($code, 2, 2);
            case 'G:':
            case 'B:': return 'P:' . substr($code, 2, 4);
            default: return null;
        }
    }

    private static function children($year, $organ, $parent)
    {
        if ($organ !== 'mayor') {
            return LcepCouncilCatalog::areas($year, $organ, $parent);
        }
        $areas = [];
        foreach (LcepMayorCatalog::metadata($year)['areas'] as $code => $info) {
            if ($parent === 'PL') {
                $areas['W:' . $info['province']] = $info['province_name'];
            } elseif ('W:' . $info['province'] === $parent) {
                $areas['P:' . $info['county']] = $info['county_name'];
            } elseif ('P:' . $info['county'] === $parent) {
                $areas[$code] = $info['name'];
            }
        }
        asort($areas, SORT_NATURAL | SORT_FLAG_CASE);
        $children = [];
        foreach ($areas as $code => $name) {
            $children[] = ['code' => $code, 'name' => $name];
        }
        return $children;
    }

    public static function name(int $year, string $organ, string $area): ?string
    {
        $parent = self::parent($area);
        if ($area === 'PL') {
            return 'Polska';
        }
        if ($parent !== null) {
            foreach (self::children($year, $organ, $parent) as $row) {
                if ($row['code'] === $area) {
                    return $row['name'];
                }
            }
        }
        return null;
    }

    public static function page(int $year, string $organ, string $area, int $district, int $round): ?array
    {
        if (!in_array($year, self::years($organ), true)
            || !preg_match('/^(?:PL|W:[0-9]{2}|P:[0-9]{4}|[GB]:[0-9]{6})$/D', $area)
            || $district < 0 || $district > 9999 || !in_array($round, [1,2], true)) {
            return null;
        }
        $parent = self::parent($area);
        $name = self::name($year, $organ, $area);
        if ($name === null) {
            return null;
        }
        $terminal = substr($area, 0, 2) === ['mayor' => 'G:', 'gmina' => 'G:', 'powiat' => 'P:', 'dzielnica' => 'B:'][$organ];
        $page = ['year' => $year, 'organ' => $organ, 'area' => $area, 'district' => $district, 'round' => $round,
            'name' => $name, 'parent' => $parent, 'children' => [], 'districts' => [], 'rounds' => [],
            'race' => null, 'terminal' => $terminal];
        if (!$terminal) {
            if ($district || $round !== 1) {
                return null;
            }
            $page['children'] = self::children($year, $organ, $area);
            return $page;
        }
        if ($organ === 'mayor') {
            if ($district) {
                return null;
            }
            $meta = LcepMayorCatalog::metadata($year);
            $page['rounds'] = $meta['areas'][$area]['rounds'];
            if (!in_array($round, $page['rounds'], true)) {
                return null;
            }
            $page['race'] = LcepMayorCatalog::area($year, $area, $round);
            return $page['race'] === null ? null : $page;
        }
        if ($round !== 1) {
            return null;
        }
        $page['districts'] = LcepCouncilCatalog::districts($year, $organ, $area);
        if ($district) {
            $page['race'] = LcepCouncilCatalog::ballot($year, $organ, $area, $district);
            if ($page['race'] === null) {
                return null;
            }
        }
        return $page;
    }

    public static function hasBallot(array $page): bool
    {
        $race = $page['race'];
        if (empty($race['options'])) {
            return false;
        }
        return $page['organ'] === 'mayor'
            ? in_array($race['card_type'], ['yes_no', 'candidates'], true)
            : $race['status'] === 'voted';
    }

    public static function title(array $page): string
    {
        $race = $page['race'];
        if ($page['organ'] === 'mayor') {
            return $race['office'] . ' · ' . $page['name'] . ' · tura ' . $page['round'];
        }
        return self::ORGANS[$page['organ']] . ' · ' . $page['name'] . ' · okręg ' . $page['district'];
    }

    public static function options(array $page): array
    {
        $options = [];
        foreach ($page['race']['options'] as $candidate) {
            $label = $candidate['label'] ?? $candidate['name'];
            if (!empty($candidate['committee']) && ($page['race']['card_type'] ?? '') !== 'yes_no') {
                $label .= ' (' . $candidate['committee'] . ')';
            }
            $options[(string) $candidate['code']] = $label;
        }
        return $options;
    }

    public static function query(array $page): array
    {
        return array_intersect_key($page, array_flip(['year','organ','area','district','round']));
    }
}
