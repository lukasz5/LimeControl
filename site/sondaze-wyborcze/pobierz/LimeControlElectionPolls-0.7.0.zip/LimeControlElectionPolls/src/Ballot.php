<?php
// SPDX-License-Identifier: GPL-2.0-or-later

require_once __DIR__ . '/PkwCatalog.php';

/** An importable, anonymous LimeSurvey wave built from the registered lists in one historical district. */
final class LcepBallot
{
    public static function lss(int $year, array $area, int $wave): string
    {
        $code = $area['code'] ?? '';
        if (!in_array($wave, [1, 2], true) || !in_array($year, LcepPkwCatalog::years(), true)
            || ($area['level'] ?? '') !== 'okreg' || !is_string($code)
            || !preg_match('/^D:(\d{2}):([1-9]\d*)$/D', $code, $parts)) {
            throw new DomainException('Wybierz okręg sejmikowy, rok wyborów i falę 1 lub 2.');
        }
        $catalog = LcepPkwCatalog::metadata($year);
        $numbers = $catalog['ballots'][$code] ?? [];
        if (!$numbers) {
            throw new DomainException('Brak zarejestrowanych list w wybranym okręgu.');
        }
        $province = LcepPkwCatalog::area($year, 'W:' . $parts[1])['name'];
        $location = 'woj. ' . $province . ', okręg nr ' . $parts[2];
        // A district ballot records all registered lists, independently of how many votes they received.
        asort($numbers, SORT_NUMERIC);
        $options = [];
        foreach ($numbers as $committee => $number) {
            $options[$committee] = 'Lista nr ' . $number . ' — ' . $catalog['committees'][$committee];
        }
        return self::survey($wave, $options,
            'Archiwalna karta do sejmiku ' . $year . ' · ' . $location,
            'Badanie na podstawie list zarejestrowanych w wyborach samorządowych w roku ' . $year . ' (' . $location . '). Źródło: PKW.',
            'Gdyby ponownie można było wybierać spośród list do sejmiku z roku ' . $year . ' (' . $location . '), na którą listę oddałaby Pani lub oddałby Pan głos?');
    }

    /** Generate a pair of comparable pre-election surveys from one explicitly identified race. */
    public static function survey(int $wave, array $options, string $title, string $description, string $question): string
    {
        if (!in_array($wave, [1, 2], true) || !$options || array_intersect(array_keys($options), ['DK','REF','NOST'])) {
            throw new DomainException('Niepoprawny wariant historycznej karty wyborczej.');
        }
        foreach (array_keys($options) as $option) {
            if (!preg_match('/^[a-zA-Z0-9]{1,5}$/D', (string) $option)) {
                throw new DomainException('Niepoprawny kod opcji w karcie.');
            }
        }
        $doc = new DOMDocument();
        $doc->preserveWhiteSpace = false;
        $doc->formatOutput = true;
        if (!$doc->load(dirname(__DIR__) . '/examples/fala-' . $wave . '.lss', LIBXML_NONET)) {
            throw new RuntimeException('Nie udało się odczytać wzoru fali w paczce wtyczki.');
        }
        $xpath = new DOMXPath($doc);
        $answers = $xpath->query('/document/answers/rows')->item(0);
        $localized = $xpath->query('/document/answer_l10ns/rows')->item(0);
        self::clear($answers);
        self::clear($localized);
        $options += ['DK' => 'Jeszcze nie wiem', 'NOST' => 'Nie zamierzam głosować', 'REF' => 'Wolę nie odpowiadać'];
        $i = 0;
        foreach ($options as $option => $label) {
            self::row($answers, ['aid' => $i + 1, 'qid' => 1, 'code' => $option, 'sortorder' => $i,
                'assessment_value' => 0, 'scale_id' => 0]);
            // Imported labels are rendered as HTML by LimeSurvey. Escape that context before XML serialization.
            self::row($localized, ['aid' => ++$i, 'language' => 'pl',
                'answer' => htmlspecialchars($label, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')]);
        }
        $fields = [
            '/document/surveys_languagesettings/rows/row/surveyls_title' => $title . ' · fala ' . $wave,
            '/document/surveys_languagesettings/rows/row/surveyls_description' => $description,
            '/document/question_l10ns/rows/row/question' => $question,
        ];
        foreach ($fields as $path => $value) {
            $field = $xpath->query($path)->item(0);
            self::clear($field);
            $field->appendChild($doc->createTextNode($value));
        }
        return $doc->saveXML();
    }

    private static function clear(DOMElement $element)
    {
        while ($element->firstChild) {
            $element->removeChild($element->firstChild);
        }
    }

    private static function row(DOMElement $rows, array $values)
    {
        $doc = $rows->ownerDocument;
        $row = $rows->appendChild($doc->createElement('row'));
        foreach ($values as $name => $value) {
            $field = $row->appendChild($doc->createElement($name));
            $field->appendChild($doc->createTextNode((string)$value));
        }
    }
}
