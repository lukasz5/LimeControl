<?php
// SPDX-License-Identifier: GPL-2.0-or-later

/** Historical council ballots. Each shard contains neighbouring authorities for one election. */
final class LcepCouncilCatalog
{
    private const DATA = __DIR__ . '/../data/councils/';
    private const LEVELS = ['W' => 'wojewodztwo', 'P' => 'powiat', 'G' => 'gmina', 'B' => 'dzielnica'];
    private const PREFIXES = ['powiat' => 'P', 'gmina' => 'G', 'dzielnica' => 'B'];
    private static $manifests = [];
    private static $bucket = '';
    private static $records = [];

    public static function years(): array
    {
        return [2014, 2018, 2024];
    }

    public static function metadata(int $year): array
    {
        if (!in_array($year, self::years(), true)) {
            throw new InvalidArgumentException('Nieobsługiwany rok wyborów do rad.');
        }
        if (!isset(self::$manifests[$year])) {
            $json = file_get_contents(self::DATA . $year . '.json');
            $meta = $json !== false ? json_decode($json, true) : null;
            if (($meta['year'] ?? 0) !== $year || ($meta['schema'] ?? 0) !== 1 ||
                !preg_match('/^' . $year . '-[a-f0-9]{16}$/D', $meta['revision'] ?? '') ||
                empty($meta['shards']) || empty($meta['coverage']) || empty($meta['areas'])) {
                throw new RuntimeException('Błąd odczytu katalogu wyborów do rad z roku ' . $year . '.');
            }
            self::$manifests[$year] = $meta;
        }
        return self::$manifests[$year];
    }

    public static function areas(int $year, string $organ, string $parent = 'PL'): array
    {
        $entries = self::metadata($year)['areas'][$organ][$parent] ?? [];
        asort($entries, SORT_NATURAL | SORT_FLAG_CASE);
        $areas = [];
        foreach ($entries as $code => $name) {
            $areas[] = ['code' => $code, 'name' => $name, 'level' => self::LEVELS[$code[0]]];
        }
        return $areas;
    }

    public static function totals(int $year, string $organ, string $area = 'PL'): ?array
    {
        $row = self::metadata($year)['totals'][$organ][$area] ?? null;
        if ($row === null) {
            return null;
        }
        return $row + ['voted' => 0, 'uncontested' => 0, 'vacant' => 0, 'precinct_candidate_vectors' => 0];
    }

    private static function load(int $year, string $organ, string $unit): bool
    {
        if (!isset(self::PREFIXES[$organ]) || !preg_match('/^(?:P:\d{4}|[BG]:\d{6})$/D', $unit) ||
            $unit[0] !== self::PREFIXES[$organ]) {
            return false;
        }
        $meta = self::metadata($year);
        $bucket = substr($unit, 2, 3);
        if (!isset($meta['shards'][$bucket])) {
            return false;
        }
        $key = $meta['revision'] . '/' . $bucket;
        if (self::$bucket !== $key) {
            $raw = file_get_contents(self::DATA . $key . '.json');
            if ($raw === false || hash('sha256', $raw) !== $meta['shards'][$bucket]) {
                throw new RuntimeException('Niekompletne archiwum wyborów do rad.');
            }
            self::$records = json_decode($raw, true);
            if (!isset(self::$records['units'], self::$records['committees'], self::$records['stations'])) {
                throw new RuntimeException('Niepoprawny format wyników wyborów do rad.');
            }
            self::$bucket = $key;
        }
        return isset(self::$records['units'][$unit]);
    }

    public static function districts(int $year, string $organ, string $unit): array
    {
        if (!self::load($year, $organ, $unit)) {
            return [];
        }
        $districts = [];
        foreach (self::$records['units'][$unit] as $number => $race) {
            $districts[] = [
                'code' => (string) $number, 'name' => 'Okręg nr ' . $number,
                'status' => $race[0], 'valid_votes' => $race[1], 'seats' => $race[2],
            ];
        }
        return $districts;
    }

    public static function ballot(int $year, string $organ, string $unit, int $district): ?array
    {
        if (!self::load($year, $organ, $unit) || !isset(self::$records['units'][$unit][$district])) {
            return null;
        }
        [$status, $valid, $seats, $candidates, $stations] = self::$records['units'][$unit][$district];
        $options = [];
        foreach ($candidates as $index => $candidate) {
            [$list, $position, $name, $committee, $votes, $elected] = $candidate;
            $options[] = ['code' => 'C' . ($index + 1), 'name' => $name,
                'committee' => self::$records['committees'][$committee], 'list_number' => $list,
                'position' => $position, 'votes' => $votes, 'elected' => (bool) $elected];
        }
        $codes = array_column($options, 'code');
        $precincts = [];
        foreach ($stations as $code => $station) {
            $precincts[$code] = ['name' => self::$records['stations'][$station[2]],
                'valid_votes' => $station[0], 'votes' => $station[1] === null ? null : array_combine($codes, $station[1])];
        }
        return ['name' => 'Okręg nr ' . $district, 'status' => $status,
            'valid_votes' => $valid, 'seats' => $seats, 'options' => $options, 'precincts' => $precincts];
    }
}
