<?php
// SPDX-License-Identifier: GPL-2.0-or-later
require_once __DIR__ . '/LocalArchive.php';
require_once __DIR__ . '/PkwCatalog.php';
require_once __DIR__ . '/ExitFrameSize.php';

/** Historical frame and ballot only. Actual official votes never enter the field estimate through this adapter. */
final class LcepExitArchive
{
    const DATES = [
        2014 => [1 => '2014-11-16', 2 => '2014-11-30'],
        2018 => [1 => '2018-10-21', 2 => '2018-11-04'],
        2024 => [1 => '2024-04-07', 2 => '2024-04-21'],
    ];

    public static function preset(array $query): ?array
    {
        $organ = $query['organ'] ?? 'sejmik';
        $year = filter_var($query['year'] ?? null, FILTER_VALIDATE_INT);
        $round = filter_var($query['round'] ?? 1, FILTER_VALIDATE_INT);
        $district = filter_var($query['district'] ?? 0, FILTER_VALIDATE_INT);
        $area = $query['area'] ?? '';
        if (!is_string($organ) || !isset(LcepLocalArchive::ORGANS[$organ]) || !isset(self::DATES[$year][$round])
            || $district === false || !is_string($area)) {
            return null;
        }
        if ($organ === 'sejmik') {
            if ($round !== 1 || $district || !in_array($year, LcepPkwCatalog::years(), true)) {
                return null;
            }
            $unit = LcepPkwCatalog::area($year, $area);
            if (!$unit || $unit['level'] !== 'okreg') {
                return null;
            }
            $meta = LcepPkwCatalog::metadata($year);
            $numbers = $meta['ballots'][$area];
            asort($numbers, SORT_NUMERIC);
            $options = [];
            foreach ($numbers as $code => $number) {
                $options[$code] = 'Lista ' . $number . ' · ' . $meta['committees'][$code];
            }
            $frame = LcepPkwCatalog::districtFrame($year, $area);
            $title = 'Sejmik · ' . LcepPkwCatalog::area($year, $unit['parent'])['name'] . ' · ' . $unit['name'];
        } else {
            $page = LcepLocalArchive::page($year, $organ, $area, $district, $round);
            if (!$page || !LcepLocalArchive::hasBallot($page)) {
                return null;
            }
            $frame = [];
            $title = LcepLocalArchive::title($page);
            $options = LcepLocalArchive::options($page);
            if ($organ !== 'mayor' && $page['race']['valid_votes'] > array_sum(array_column($page['race']['options'], 'votes'))) {
                $options['LIST'] = 'Zaznaczyłam/zaznaczyłem wyłącznie nazwisko skreślonego kandydata na liście, która uczestniczyła w wyborach';
            }
            foreach ($page['race']['precincts'] ?? [] as $id => $row) {
                $code = $organ === 'mayor' ? 'O:' . substr($area, 2) . ':' . $id : (string) $id;
                $frame[] = ['code' => $code, 'label' => $row['name'] ?: $code, 'stratum' => $area];
            }
        }
        if (!$frame) {
            return null;
        }
        $sizes = [];
        if ($organ === 'sejmik' || $organ === 'mayor') {
            $sizes = LcepExitFrameSize::forPoints($year, array_column($frame, 'code'), $organ === 'mayor' && $area === 'G:146501');
        }
        $lines = [];
        foreach ($sizes as $code => $size) {
            $lines[] = $code . ';' . $size;
        }
        return ['title' => 'Exit poll · ' . $title . ' · ' . $year, 'scope' => $title,
            'date' => self::DATES[$year][$round], 'source' => 'PKW / KBW · wybory samorządowe ' . $year . ' · ' . $area,
            'sizes_text' => implode("\n", $lines), 'size_source' => $sizes ? LcepExitFrameSize::source($year) : '',
            'options' => $options, 'frame' => $frame];
    }
}
