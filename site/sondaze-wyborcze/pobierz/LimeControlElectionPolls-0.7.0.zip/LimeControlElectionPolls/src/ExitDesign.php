<?php
// SPDX-License-Identifier: GPL-2.0-or-later
require_once __DIR__ . '/ExitStep.php';

/** Single ballot, single round, stratified SRS of precincts followed by systematic sampling at the exit. */
final class LcepExitDesign
{
    public static function text($value, int $limit, string $label, bool $optional = false): string
    {
        if (!is_string($value) || !mb_check_encoding($value, 'UTF-8') || mb_strlen($value) > $limit
            || (!$optional && trim($value) === '')) {
            throw new DomainException('Sprawdź pole „' . $label . '”.');
        }
        return trim($value);
    }

    public static function integer($v, int $min, int $max, string $label): int
    {
        if ((!is_string($v) && !is_int($v)) || !preg_match('/^\d{1,8}$/D', (string)$v) || (int)$v < $min || (int)$v > $max) {
            throw new DomainException('Pole „' . $label . '” wymaga liczby całkowitej od ' . $min . ' do ' . $max . '.');
        }
        return (int)$v;
    }

    private static function code(string $v, int $max = 64): string
    {
        if ($v === '' || strlen($v) > $max || !preg_match('/^[a-zA-Z0-9][a-zA-Z0-9:_-]*$/D', $v)) {
            throw new DomainException('Kody muszą zawierać litery bez znaków diakrytycznych, cyfry, dwukropek, myślnik lub podkreślenie.');
        }
        return $v;
    }

    private static function lines($text, int $columns, int $maxRows): array
    {
        $text = self::text($text, 750000, 'wiersze listy');
        $lines = preg_split('/\r\n|\n|\r/', $text);
        if (count($lines) > $maxRows) {
            throw new DomainException('Za dużo wierszy dla jednego projektu. Wybierz obszar jednej karty.');
        }
        $result = [];
        foreach ($lines as $i => $line) {
            if (trim($line) === '') {
                continue;
            }
            // Only fixed code fields precede the last label; labels may contain semicolons.
            $cells = array_map('trim', explode(';', $line, $columns));
            if (count($cells) !== $columns || in_array('', $cells, true)) {
                throw new DomainException('Niepełny wiersz ' . ($i + 1) . ' listy.');
            }
            $result[] = $cells;
        }
        return $result;
    }

    public static function plan(array $input): array
    {
        $plan = [];
        foreach (['title' => 200, 'scope' => 1000, 'source' => 600] as $key => $limit) {
            $plan[$key] = self::text($input[$key] ?? '', $limit, ['title'=>'badanie', 'scope'=>'populacja i wyłączenia', 'source'=>'źródło operatu'][$key]);
        }
        $date = self::text($input['date'] ?? '', 10, 'data głosowania');
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
        if (!$parsed || $parsed->format('Y-m-d') !== $date || $date < '1900-01-01') {
            throw new DomainException('Nieprawidłowa data głosowania.');
        }
        $plan['date'] = $date;
        foreach (['opening', 'change', 'closing'] as $field) {
            $time = $input[$field] ?? '';
            if (!is_string($time) || !preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $time)) {
                throw new DomainException('Podaj godziny otwarcia, zmiany i zamknięcia w formacie GG:MM.');
            }
            $plan[$field] = $time;
        }
        if (!($plan['opening'] < $plan['change'] && $plan['change'] < $plan['closing'])) {
            throw new DomainException('Dwie kolejne zmiany muszą obejmować cały zadeklarowany czas głosowania.');
        }
        $plan['step'] = self::integer($input['step'] ?? '', 1, LcepExitStep::MAX_STEP, 'krok doboru');
        $mode = $input['step_mode'] ?? 'fixed';
        if (!in_array($mode, ['fixed', 'size', 'size_small'], true)) {
            throw new DomainException('Wybierz sposób doboru kroku.');
        }
        $plan['step_mode'] = $mode;
        $per = self::integer($input['per_stratum'] ?? '', 1, 2000, 'obwody na warstwę');
        $plan['per_stratum'] = $per;
        $seed = self::text($input['seed'] ?? '', 64, 'ziarno losowania', true);
        $plan['seed'] = $seed === '' ? bin2hex(random_bytes(16)) : $seed;
        $options = [];
        foreach (self::lines($input['options_text'] ?? '', 2, 250) as [$key, $label]) {
            $key = self::code($key, 36);
            if (isset($options[$key])) {
                throw new DomainException('Powtórzony kod odpowiedzi na karcie.');
            }
            $options[$key] = self::text($label, 300, 'opcja karty');
        }
        if (count($options) < 2) {
            throw new DomainException('Podaj co najmniej dwie opcje jednej karty. Przy jednym kandydacie na włodarza wpisz TAK i NIE.');
        }
        $plan['options'] = $options;
        $frame = [];
        $pointKeys = [];
        $strata = [];
        foreach (self::lines($input['frame_text'] ?? '', 3, 12000) as [$stratum, $code, $label]) {
            $stratum = self::code($stratum);
            $code = self::code($code);
            $pointKey = strtolower($code);
            if (isset($pointKeys[$pointKey])) {
                throw new DomainException('Obwód ' . $code . ' występuje w operacie wielokrotnie.');
            }
            $pointKeys[$pointKey] = true;
            $frame[$code] = ['stratum' => $stratum, 'label' => self::text($label, 1200, 'nazwa obwodu')];
            $strata[$stratum][] = $code;
        }
        if (!$frame) {
            throw new DomainException('Operat wymaga przynajmniej jednego obwodu.');
        }
        ksort($frame, SORT_STRING);
        ksort($strata, SORT_STRING);
        if ($mode !== 'fixed') {
            $plan['size_source'] = self::text($input['size_source'] ?? '', 600, 'źródło wielkości obwodów');
            foreach (self::lines($input['sizes_text'] ?? '', 2, 12000) as [$code, $size]) {
                if (!isset($frame[$code]) || isset($frame[$code]['size'])) {
                    throw new DomainException('Lista wielkości musi obejmować dokładnie jeden wpis dla każdego kodu z operatu.');
                }
                $frame[$code]['size'] = self::integer($size, 0, 99999999, 'wielkość obwodu ' . $code);
            }
            $steps = LcepExitStep::allocate($frame, $per, $plan['step'], $mode);
        }
        $plan['frame'] = $frame;
        $plan['frame_hash'] = hash('sha256', json_encode($frame, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE));
        $plan['strata'] = [];
        $plan['points'] = [];
        foreach ($strata as $stratum => $codes) {
            $scores = [];
            foreach ($codes as $code) {
                $scores[$code] = hash_hmac('sha256', json_encode(['point', (string)$stratum, $code], JSON_THROW_ON_ERROR), $plan['seed']);
            }
            ksort($scores, SORT_STRING);
            asort($scores, SORT_STRING);
            $n = min($per, count($codes));
            $plan['strata'][$stratum] = ['total' => count($codes), 'sample' => $n];
            foreach (array_slice(array_keys($scores), 0, $n) as $code) {
                $step = $mode === 'fixed' ? $plan['step'] : $steps[$code];
                $starts = [];
                foreach ([1, 2] as $shift) {
                    // Reject the incomplete tail of the 24-bit range to obtain a uniform integer.
                    $attempt = 0;
                    do {
                        $hash = hash_hmac('sha256', 'start:' . $code . ':' . $shift . ':' . $attempt++, $plan['seed']);
                        $value = hexdec(substr($hash, 0, 6));
                    } while ($value >= intdiv(16777216, $step) * $step);
                    $starts[$shift] = 1 + $value % $step;
                }
                $plan['points'][$code] = $frame[$code] + ['step' => $step, 'starts' => $starts];
            }
        }
        $plan['algorithm'] = $mode === 'fixed' ? 'stratified-srs-hmac-sha256-v1' : 'stratified-srs-hmac-sha256-size-v1';
        return $plan;
    }

    public static function votes(array $plan, $raw): array
    {
        if (!is_array($raw) || array_diff_key($raw, $plan['options']) || array_diff_key($plan['options'], $raw)) {
            throw new DomainException('Paczka wymaga dokładnie jednego licznika dla każdej opcji tej karty.');
        }
        $votes = [];
        foreach ($plan['options'] as $code => $label) {
            $votes[$code] = self::integer($raw[$code], 0, 999999, $label);
        }
        return $votes;
    }

    public static function batch(array $plan, array $input): array
    {
        $point = self::text($input['point'] ?? '', 64, 'obwód');
        $shift = self::integer($input['shift'] ?? null, 1, 2, 'zmiana');
        if (!isset($plan['points'][$point])) {
            throw new DomainException('Obwód nie należy do wylosowanej próby.');
        }
        $id = self::code(self::text($input['batch_id'] ?? '', 56, 'numer paczki'), 56);
        $votes = self::votes($plan, $input['votes'] ?? []);
        $counts = [];
        foreach (['invited'=>'zaproszeni', 'refused'=>'odmowy udziału', 'missed'=>'pominięci', 'invalid'=>'głosy zadeklarowane jako nieważne',
            'no_ballot'=>'bez karty', 'declined'=>'odmowy odpowiedzi na pytanie'] as $key => $name) {
            $counts[$key] = self::integer($input[$key] ?? null, 0, 999999, $name);
        }
        $done = array_sum($votes) + $counts['invalid'] + $counts['no_ballot'] + $counts['declined'];
        if ($counts['invited'] !== $done + $counts['refused']) {
            throw new DomainException('Zaproszeni muszą odpowiadać sumie ukończonych ankiet i odmów udziału. Pominięci mają osobny licznik.');
        }
        $note = self::text($input['interruption'] ?? '', 600, 'przebieg zmiany', true);
        if ($done === 0 && $note === '') {
            throw new DomainException('Przy zerowej realizacji podaj przyczynę w przebiegu zmiany.');
        }
        return ['point'=>$point, 'shift'=>$shift, 'batch_id'=>$id, 'votes'=>$votes, 'completed'=>$done, 'interruption'=>$note] + $counts;
    }

    public static function protocol(array $plan, array $input): array
    {
        $point = self::text($input['point'] ?? '', 64, 'obwód');
        if (!isset($plan['points'][$point])) {
            throw new DomainException('Protokół musi dotyczyć wylosowanego obwodu i tej samej karty.');
        }
        $votes = self::votes($plan, $input['votes'] ?? []);
        $valid = self::integer($input['valid'] ?? null, 0, 9999999, 'oficjalne głosy ważne');
        if (array_sum($votes) !== $valid) {
            throw new DomainException('Suma głosów w protokole musi odpowiadać liczbie głosów ważnych.');
        }
        return ['point'=>$point, 'valid'=>$valid, 'votes'=>$votes,
            'reference'=>self::text($input['reference'] ?? '', 600, 'oznaczenie lub adres protokołu')];
    }
}
