<?php
// SPDX-License-Identifier: GPL-2.0-or-later

/** A single long-format table; accepts only the same publishable aggregates as the private panel. */
final class LcepReportCsv
{
    public static function write($stream, array $project, array $report)
    {
        $columns = ['typ', 'projekt', 'obszar', 'zleceniodawca', 'metoda', 'schemat', 'fala', 'od', 'do', 'kod', 'opis',
            'liczba', 'mianownik', 'n_mianownika', 'odsetek_surowy', 'odsetek', 'zmiana_pp', 'dolna_95', 'gorna_95',
            'status', 'uwagi', 'zrodlo'];
        fwrite($stream, "\xEF\xBB\xBF");
        fputcsv($stream, $columns, ';', '"', '');
        $base = ['projekt' => $project['title'], 'obszar' => $project['area'], 'zleceniodawca' => $project['sponsor'],
            'metoda' => $project['method'], 'schemat' => $project['design']];
        $line = static function (array $record) use ($stream, $columns, $base) {
            $record += $base;
            $fields = [];
            foreach ($columns as $column) {
                $v = $record[$column] ?? '';
                if (is_string($v) && preg_match('/^\s*[=+@-]|^[\t\r\n]/u', $v)) {
                    $v = "'" . $v;
                }
                $fields[] = $v;
            }
            fputcsv($stream, $fields, ';', '"', '');
        };
        foreach ($report['waves'] as $i => $wave) {
            $context = ['fala' => $i + 1, 'od' => $wave['start'], 'do' => $wave['end'], 'status' => $wave['status']];
            $line(['typ' => 'fala', 'liczba' => $wave['total'], 'uwagi' => $wave['reason']] + $context);
            foreach ($wave['rows'] as $row) {
                $lists = $row['kind'] === 'list';
                $line(['typ' => 'wynik', 'kod' => $row['code'], 'opis' => $row['label'], 'liczba' => $row['count'],
                    'mianownik' => $lists ? 'zdecydowani' : 'ukończone', 'n_mianownika' => $lists ? $wave['decided'] : $wave['total'],
                    'odsetek_surowy' => $row['raw_percent'], 'odsetek' => $row['percent'],
                    'dolna_95' => $row['ci'][0] ?? null, 'gorna_95' => $row['ci'][1] ?? null] + $context);
            }
        }
        foreach ($report['changes'] as $row) {
            $line(['typ' => 'zmiana', 'fala' => '2 vs 1', 'kod' => $row['code'], 'opis' => $row['label'],
                'mianownik' => $row['kind'] === 'list' ? 'zdecydowani' : 'ukończone', 'zmiana_pp' => $row['delta'],
                'dolna_95' => $row['ci'][0] ?? null, 'gorna_95' => $row['ci'][1] ?? null]);
        }
        foreach ($report['events'] as $event) {
            $line(['typ' => 'wydarzenie', 'obszar' => $event['area'], 'opis' => $event['title'], 'od' => $event['start'],
                'do' => $event['end'], 'status' => $event['status'], 'uwagi' => $event['note'], 'zrodlo' => $event['source']]);
        }
        $line(['typ' => 'metoda', 'uwagi' => $report['comparison_note']]);
    }
}
