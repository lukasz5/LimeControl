<?php
// SPDX-License-Identifier: GPL-2.0-or-later
require_once __DIR__ . '/MayorCatalog.php';
require_once __DIR__ . '/CouncilCatalog.php';
require_once __DIR__ . '/CampaignPlanner.php';

/** Territorial dictionary and spending for a comparison of disjoint areas. */
final class LcEpCommitteeAreas
{
    public const MAX_SELECTED = 4;
    private static $indexes = [];

    private static function index(int $year): array
    {
        if (!isset(self::$indexes[$year])) {
            $names = ['PL' => 'Polska'];
            $parents = ['PL' => null];
            foreach (LcepMayorCatalog::metadata($year)['areas'] as $code => $unit) {
                $province = 'W:' . $unit['province'];
                $county = 'P:' . $unit['county'];
                $names[$province] = $unit['province_name'];
                $names[$county] = $unit['county_name'];
                $names[$code] = $unit['name'];
                $parents[$province] = 'PL';
                $parents[$county] = $province;
                $parents[$code] = $county;
            }
            foreach (LcepCouncilCatalog::areas($year, 'dzielnica', 'P:1465') as $district) {
                $names[$district['code']] = $district['name'];
                $parents[$district['code']] = 'G:146501';
            }
            self::$indexes[$year] = ['names' => $names, 'parents' => $parents];
        }
        return self::$indexes[$year];
    }

    private static function knownYear(string $code): ?int
    {
        if (!preg_match('/^(?:PL|W:[0-9]{2}|P:[0-9]{4}|[GB]:[0-9]{6})$/D', $code)) {
            return null;
        }
        foreach (array_reverse(LcepMayorCatalog::years()) as $year) {
            if (isset(self::index($year)['names'][$code])) {
                return $year;
            }
        }
        return null;
    }

    public static function year(string $scope): int
    {
        $year = self::knownYear($scope);
        if ($year === null) {
            throw new DomainException('Brak obszaru projektu w archiwum PKW.');
        }
        return $year;
    }

    public static function parent(string $code, ?int $year = null): ?string
    {
        $year = $year ?? self::knownYear($code);
        return $year === null ? null : (self::index($year)['parents'][$code] ?? null);
    }

    private static function inArea(string $parent, string $child, array $index): bool
    {
        if (!isset($index['names'][$child])) {
            return false;
        }
        while ($child !== null) {
            if ($child === $parent) {
                return true;
            }
            $child = $index['parents'][$child];
        }
        return false;
    }

    public static function contains(string $parent, string $child): bool
    {
        $year = self::knownYear($child);
        return $year !== null && self::inArea($parent, $child, self::index($year));
    }

    /** Names and codes only, including the project itself. No ballot or respondent data. */
    public static function catalog(string $scope): array
    {
        $index = self::index(self::year($scope));
        $names = [];
        foreach ($index['names'] as $code => $name) {
            if (self::inArea($scope, $code, $index)) {
                $names[$code] = $name;
            }
        }
        asort($names, SORT_NATURAL | SORT_FLAG_CASE);
        return [$scope => $index['names'][$scope]] + $names;
    }

    public static function selection(string $scope, $requested): array
    {
        $index = self::index(self::year($scope));
        if ($requested === null) {
            return [$scope];
        }
        if (!is_array($requested) || count($requested) > self::MAX_SELECTED) {
            throw new DomainException('Wybierz najwyżej cztery obszary do porównania.');
        }
        $selected = [];
        foreach ($requested as $code) {
            if ($code === '') {
                continue;
            }
            if (!is_string($code) || !self::inArea($scope, $code, $index)) {
                throw new DomainException('Wybierz jednostkę z obszaru tego projektu.');
            }
            foreach ($selected as $other) {
                if (self::inArea($other, $code, $index) || self::inArea($code, $other, $index)) {
                    throw new DomainException('Wybierz odrębne obszary. Porównywane jednostki nie mogą się pokrywać.');
                }
            }
            $selected[] = $code;
        }
        return $selected ?: [$scope];
    }

    /** A wider event and a project/wave task remain common, even for a single selected area. */
    private static function spendingGroup(?string $area, array $selected, array $index, bool $historical): ?string
    {
        if ($area === null) {
            return 'shared';
        }
        foreach ($selected as $code) {
            if (self::inArea($code, $area, $index)) {
                return $historical ? 'shared' : $code;
            }
            if (self::inArea($area, $code, $index)) {
                return 'shared';
            }
        }
        return null;
    }

    /**
     * Event dates and task deadlines determine inclusion. Every displayed cost is kept
     * whole, including an event spanning the start or end of the fieldwork window.
     */
    public static function activity(array $planner, array $selected): array
    {
        $selected = self::selection($planner['area'], $selected);
        $vintage = self::year($planner['area']);
        $index = self::index($vintage);
        $groups = array_fill_keys($selected, []);
        $groups['shared'] = [];
        $outside = 0;
        $events = array_column($planner['events'], null, 'id');
        foreach (['events' => 'event', 'tasks' => 'task'] as $collection => $kind) {
            foreach ($planner[$collection] as $item) {
                $event = $kind === 'event' ? $item : null;
                $link = $item['link'] ?? null;
                if ($kind === 'task' && is_string($link) && strpos($link, 'event:') === 0) {
                    $event = $events[substr($link, 6)] ?? null;
                }
                $area = $event['area'] ?? null;
                $historical = $area !== null && !isset($index['names'][$area]);
                $areaIndex = $historical ? self::index(self::year($area)) : $index;
                $group = self::spendingGroup($area, $selected, $areaIndex, $historical);
                if ($group === null) {
                    continue;
                }
                $start = $item['start'] ?? $item['due'];
                $end = $item['end'] ?? $item['due'];
                if ($end < $planner['wave1']['start'] || $start > $planner['wave2']['end']) {
                    ++$outside;
                    continue;
                }
                $groups[$group][] = [
                    'kind' => $kind, 'id' => $item['id'], 'title' => $item['title'], 'status' => $item['status'],
                    'start' => $start, 'end' => $end, 'wave_label' => LcEpCampaignPlanner::waveLabel($start, $end, $planner),
                    'area' => $area, 'area_name' => $area === null ? null : $areaIndex['names'][$area],
                    'historical' => $historical, 'link' => $link, 'event_title' => $kind === 'task' ? ($event['title'] ?? null) : null,
                    'planned_cost' => $item['planned_cost'], 'actual_cost' => $item['actual_cost'],
                ];
            }
        }
        $report = ['areas' => [], 'outside_count' => $outside];
        foreach ($groups as $code => $items) {
            usort($items, static function ($left, $right) {
                return [$left['start'], $left['kind'], $left['title'], $left['id']]
                    <=> [$right['start'], $right['kind'], $right['title'], $right['id']];
            });
            $group = ['items' => $items, 'budget' => LcEpCampaignPlanner::budget($items, [])];
            if ($code === 'shared') {
                $report['shared'] = $group;
            } else {
                $report['areas'][$code] = $group;
            }
        }
        return $report;
    }
}
