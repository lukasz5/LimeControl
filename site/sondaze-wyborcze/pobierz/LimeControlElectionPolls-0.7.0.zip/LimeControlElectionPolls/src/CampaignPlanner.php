<?php
// SPDX-License-Identifier: GPL-2.0-or-later

final class LcEpCampaignPlanner
{
    /** An unspecified amount stays unknown. Explicit 0 means that the item has no cost. */
    public static function money($value)
    {
        if ($value === null || $value === '') {
            return null;
        }
        if ((!is_string($value) && !is_int($value))
            || !preg_match('/^([0-9]{1,9})(?:[,.]([0-9]{1,2}))?$/D', trim((string)$value), $matches)) {
            throw new DomainException('Koszt podaj w PLN od 0 do 999999999,99, z najwyżej dwiema cyframi po przecinku.');
        }
        return (int)$matches[1] * 100 + (int)str_pad($matches[2] ?? '', 2, '0');
    }

    /** Calendar labels use the recorded wave dates even while an event is only planned. */
    public static function waveLabel($start, $end, array $project)
    {
        $first = $project['wave1'];
        $second = $project['wave2'];
        if ($end < $first['start']) {
            return 'Przed falą 1';
        }
        if ($start > $second['end']) {
            return 'Po fali 2';
        }
        $inFirst = $start <= $first['end'];
        $inSecond = $end >= $second['start'];
        if ($inFirst && $inSecond) {
            return 'W trakcie fal 1 i 2';
        }
        if ($inFirst) {
            return 'W trakcie fali 1';
        }
        return $inSecond ? 'W trakcie fali 2' : 'Między falami';
    }

    public static function budget(array $events, array $tasks)
    {
        $budget = ['planned_cost'=>0, 'actual_cost'=>0, 'planned_missing'=>0, 'actual_missing'=>0,
            'items'=>count($events) + count($tasks)];
        foreach ([$events, $tasks] as $entries) {
            foreach ($entries as $entry) {
                foreach (['planned', 'actual'] as $kind) {
                    $key = $kind . '_cost';
                    if ($entry[$key] === null) {
                        ++$budget[$kind . '_missing'];
                    } else {
                        $budget[$key] += $entry[$key];
                    }
                }
            }
        }
        return $budget;
    }
}
