<?php
// SPDX-License-Identifier: GPL-2.0-or-later

/**
 * Read-only official provincial assembly results. Read one territorial shard
 * per request, including on installations without SQLite or external services.
 */
final class LcepPkwCatalog
{
    private const DATA = __DIR__ . '/../data/pkw/';
    private const LEVEL = [
        'PL' => 'kraj', 'W' => 'wojewodztwo', 'P' => 'powiat', 'G' => 'gmina',
        'B' => 'dzielnica', 'D' => 'okreg', 'O' => 'obwod',
    ];

    private static $manifests = [];
    private static $lastShard = '';
    private static $records = [];

    public static function years(): array
    {
        return [2018, 2024];
    }

    public static function metadata(int $year): array
    {
        if (!in_array($year, self::years(), true)) {
            throw new InvalidArgumentException('Nieobsługiwany rok wyborów do sejmików.');
        }
        if (!isset(self::$manifests[$year])) {
            $content = file_get_contents(self::DATA . $year . '.json');
            $meta = $content === false ? null : json_decode($content, true);
            if (!is_array($meta) || ($meta['schema'] ?? null) !== 1 || ($meta['year'] ?? null) !== $year
                || !preg_match('/^' . $year . '-[0-9a-f]{16}$/D', $meta['revision'] ?? '')
                || empty($meta['shards']) || empty($meta['ballots']) || empty($meta['committees'])) {
                throw new RuntimeException('Brak poprawnego manifestu danych PKW dla roku ' . $year . '.');
            }
            self::$manifests[$year] = $meta;
        }
        return self::$manifests[$year];
    }

    private static function records(array $meta, string $bucket): array
    {
        $cacheKey = $meta['revision'] . '/' . $bucket;
        if (self::$lastShard !== $cacheKey) {
            $contents = file_get_contents(self::DATA . $cacheKey . '.json');
            if ($contents === false || hash('sha256', $contents) !== $meta['shards'][$bucket]) {
                throw new RuntimeException('Dane PKW są niekompletne. Sprawdź instalację paczki.');
            }
            $records = json_decode($contents, true);
            if (!is_array($records)) {
                throw new RuntimeException('Nie można odczytać wyników PKW.');
            }
            self::$records = $records;
            self::$lastShard = $cacheKey;
        }
        return self::$records;
    }

    private static function summary(string $code, array $row): array
    {
        return ['code' => $code, 'name' => $row['name'], 'level' => self::LEVEL[explode(':', $code)[0]]];
    }

    /** The historical polling frame for one sejmik ballot, partitioned by powiat. */
    public static function districtFrame(int $year, string $district): array
    {
        $meta = self::metadata($year);
        if (!isset($meta['ballots'][$district])) {
            return [];
        }
        $records = self::records($meta, substr($district, 2, 2));
        $frame = [];
        foreach ($records as $code => $precinct) {
            if (strncmp($code, 'O:', 2) !== 0 || !in_array($district, $precinct['districts'], true)) {
                continue;
            }
            $parent = $records[$precinct['parent']];
            $frame[] = ['code' => $code, 'label' => $parent['name'] . ' · ' . $precinct['name'],
                'stratum' => 'P:' . substr($code, 2, 4)];
        }
        return $frame;
    }

    public static function area(int $year, string $code = 'PL'): ?array
    {
        if (!in_array($year, self::years(), true) ||
            !preg_match('/^(?:PL|W:\d{2}|P:\d{4}|[GB]:\d{6}|D:\d{2}:[1-9]\d*|O:\d{6}:[1-9]\d*)$/D', $code)) {
            return null;
        }
        $meta = self::metadata($year);
        $bucket = $code === 'PL' ? 'PL' : substr($code, 2, 2);
        if (!isset($meta['shards'][$bucket])) {
            return null;
        }
        $records = self::records($meta, $bucket);
        if (!isset($records[$code])) {
            return null;
        }
        $row = $records[$code];
        $children = [];
        foreach ($records as $id => $child) {
            if ($child['parent'] === $code && strncmp($id, 'D:', 2) !== 0) {
                $children[] = self::summary($id, $child);
            }
        }
        usort($children, static function ($a, $b) {
            return strnatcasecmp($a['name'], $b['name']);
        });

        $districts = [];
        $coverage = [];
        foreach ($row['districts'] as $district) {
            // National results already contain links to all provinces. Avoid a
            // distracting second country-wide list of 85 numbered districts.
            if ($code !== 'PL' && $district !== $code) {
                $districts[] = self::summary($district, $records[$district]);
            }
            foreach ($meta['ballots'][$district] as $party => $number) {
                $coverage[$party] = ($coverage[$party] ?? 0) + 1;
            }
        }

        $committees = [];
        $soleDistrict = count($row['districts']) === 1 ? $row['districts'][0] : null;
        foreach ($row['votes'] as $party => $votes) {
            $committees[] = [
                'code' => $party, 'name' => $meta['committees'][$party], 'votes' => $votes,
                'covered_districts' => $coverage[$party],
                'list_number' => $soleDistrict === null ? null : $meta['ballots'][$soleDistrict][$party],
            ];
        }
        usort($committees, static function ($a, $b) {
            return ($b['votes'] <=> $a['votes']) ?: strcmp($a['code'], $b['code']);
        });
        return self::summary($code, $row) + [
            'parent' => $row['parent'], 'valid_votes' => array_sum($row['votes']),
            'committees' => $committees, 'children' => $children, 'districts' => $districts,
            'district_count' => count($row['districts']),
        ];
    }
}
