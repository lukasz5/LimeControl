<?php
// SPDX-License-Identifier: GPL-2.0-or-later
require_once __DIR__ . '/PollSurvey.php';
require_once __DIR__ . '/CommitteeAreas.php';

/** Published committee estimates use the registered questionnaire and a fixed territorial partition. */
final class LcEpCommitteeSupport
{
    public static function validateGeography(string $scope, array $codes): void
    {
        if (!$codes) {
            return;
        }
        $catalog = LcEpCommitteeAreas::catalog($scope);
        foreach ($codes as $code) {
            if (!isset($catalog[$code])) {
                throw new DomainException('Kod odpowiedzi ' . $code . ' nie należy do obszaru projektu w słowniku PKW.');
            }
        }
    }

    /** Call only after checking committee report access to the complete two-wave project. */
    public static function compare(array $project, array $areas): array
    {
        $result = [];
        foreach (['wave1', 'wave2'] as $index => $key) {
            $wave = $project[$key];
            try {
                $estimates = self::wave($wave, $project, $project['question_ids'][$index], $areas);
            } catch (DomainException $error) {
                $estimates = array_fill_keys($areas, LcEpPollAnalysis::unavailable($wave, $error->getMessage()));
            }
            foreach ($estimates as $code => $estimate) {
                $result[$code]['waves'][] = self::publicWave($estimate);
            }
        }
        foreach ($result as $code => $area) {
            $result[$code]['changes'] = LcEpPollAnalysis::changes($area['waves'][0], $area['waves'][1]);
        }
        return $result;
    }

    private static function wave(array $wave, array $project, array $ids, array $areas): array
    {
        $scope = $project['area'];
        $design = $project['design'];
        $survey = new LcEpPollSurvey($wave);
        if ($survey->signature() !== $project['signature'] || $survey->identity(false) !== array_slice($ids, 0, 2)) {
            throw new DomainException('Zmieniła się karta wyboru lub przypisanie wagi. Badacz musi zweryfikować konfigurację fal.');
        }
        $mapping = ($wave['geo'] ?? '') !== '';
        $reason = 'Brak przypisanego pytania o obszar. Dostępny jest wynik całego projektu.';
        $codes = [];
        if ($mapping && array_diff($areas, [$scope])) {
            try {
                if ($survey->geoSignature() !== ($project['geo_signature'] ?? null) || $survey->identity() !== $ids) {
                    throw new DomainException('Zmieniło się pytanie o obszar lub jego słownik. Badacz musi zweryfikować mapowanie obu fal.');
                }
                $codes = $survey->geoMap();
                $reason = 'Pytanie o obszar nie pozwala przypisać wywiadów do tej jednostki.';
            } catch (DomainException $error) {
                // Whole-project estimates still use the original vote question and sample, irrespective of geography.
                $reason = $error->getMessage();
            }
        }
        $result = array_fill_keys($areas, LcEpPollAnalysis::unavailable($wave, $reason));
        if (!$codes) {
            if (array_key_exists($scope, $result)) {
                $result[$scope] = $survey->estimate($wave, $design);
                if ($mapping && $result[$scope]['status'] === 'ready') {
                    $result[$scope]['reason'] .= ' Cały projekt obejmuje również wywiady bez ustalonego obszaru.';
                }
            }
            return $result;
        }

        // Paths depend only on the questionnaire. Empty options reveal no observation-based selector metadata.
        $paths = [];
        $mapped = [];
        $year = LcEpCommitteeAreas::year($scope);
        foreach ($codes as $nativeCode => $code) {
            $chain = [$code];
            $node = $code;
            while ($node !== $scope) {
                $node = LcEpCommitteeAreas::parent($node, $year);
                if ($node === null) {
                    throw new DomainException('Sprawdź obszar projektu i kody w słowniku pytania.');
                }
                $chain[] = $node;
            }
            foreach ($chain as $node) {
                $mapped[$node] = true;
            }
            $paths[$nativeCode] = $chain;
        }
        [$groups, $note] = $survey->buckets($wave, true);
        $totals = [];
        $children = [];
        $residual = [];
        foreach ($groups as $nativeCode => $votes) {
            if (!isset($paths[$nativeCode])) {
                // Missing, declined and unrecognised codes are a single residual at the project level.
                self::add($residual, $votes);
                self::add($totals[$scope], $votes);
                continue;
            }
            $path = $paths[$nativeCode];
            foreach ($path as $index => $node) {
                self::add($totals[$node], $votes);
                if ($index > 0) {
                    $children[$node][$path[$index - 1]] = true;
                }
            }
        }
        $blocked = [];
        foreach ($areas as $code) {
            if (!isset($mapped[$code])) {
                continue;
            }
            $hidden = false;
            for ($node = $code; $node !== $scope; $node = $parent) {
                $parent = LcEpCommitteeAreas::parent($node, $year);
                if (!isset($blocked[$parent])) {
                    // All observed siblings and the residual must pass, even when only one is requested.
                    // Otherwise repeated selections could recover a small cell by subtraction from the parent.
                    $blocked[$parent] = false;
                    foreach (array_keys($children[$parent] ?? []) as $sibling) {
                        if ($survey->estimateBuckets($wave, $design, $totals[$sibling], '')['status'] !== 'ready') {
                            $blocked[$parent] = true;
                            break;
                        }
                    }
                    if ($parent === $scope && $residual && $survey->estimateBuckets($wave, $design, $residual, '')['status'] !== 'ready') {
                        $blocked[$parent] = true;
                    }
                }
                if ($blocked[$parent]) {
                    $hidden = true;
                    break;
                }
            }
            if ($hidden) {
                $result[$code] = LcEpPollAnalysis::unavailable($wave,
                    'Podział tej części projektu jest ukryty. Zestawienie obszarów pozwoliłoby odtworzyć dane małej grupy lub grupy o niepełnych danych.', 'suppressed');
            } else {
                $basis = $code === $scope ? 'Cały projekt obejmuje również wywiady bez ustalonego obszaru.'
                    : 'Ujęto wyłącznie wywiady z kodem przypisanym do tego obszaru.';
                $result[$code] = $survey->estimateBuckets($wave, $design, $totals[$code] ?? [], $note . ' ' . $basis);
            }
        }
        return $result;
    }

    private static function add(&$sum, array $votes): void
    {
        foreach ($votes as $code => $bucket) {
            if (!isset($sum[$code])) {
                $sum[$code] = $bucket;
            } else {
                $sum[$code]['count'] += $bucket['count'];
                $sum[$code]['w'] += $bucket['w'];
                $sum[$code]['w2'] += $bucket['w2'];
            }
        }
    }

    private static function publicWave(array $estimate): array
    {
        $wave = array_intersect_key($estimate, array_flip(['start', 'end', 'status', 'reason', 'total', 'decided', 'effective_n']));
        $wave['weighted'] = ($estimate['weight'] ?? '') !== '';
        $wave['rows'] = [];
        foreach ($estimate['rows'] as $row) {
            if ($row['kind'] === 'list') {
                $wave['rows'][] = array_intersect_key($row, array_flip(['code', 'label', 'kind', 'percent', 'ci']));
            }
        }
        return $wave;
    }
}
