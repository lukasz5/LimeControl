<?php
// SPDX-License-Identifier: GPL-2.0-or-later
require_once __DIR__ . '/ExitStore.php';
require_once __DIR__ . '/ExitSensitivity.php';

/** Private exit-poll workspace. Field staff can submit counts; result viewing uses a separate survey permission. */
final class LcepExitAdmin
{
    public static function canView(int $sid): bool
    {
        return self::has($sid, 'responses', 'read') || self::has($sid, 'responses', 'create');
    }

    public static function canManage(int $sid): bool
    {
        return self::has($sid, 'responses', 'read') && self::has($sid, 'surveycontent', 'update');
    }

    private static function has(int $sid, string $entity, string $right): bool
    {
        return !App()->user->isGuest && Permission::model()->hasSurveyPermission($sid, $entity, $right);
    }

    public function dispatch($action)
    {
        $request = App()->request;
        $methods = ['exitPoll'=>'GET', 'exitCreate'=>'POST', 'exitBatch'=>'POST', 'exitFreeze'=>'POST', 'exitProtocol'=>'POST'];
        header('Cache-Control: private, no-store');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: no-referrer');
        if (!isset($methods[$action])) {
            throw new CHttpException(404);
        }
        if ($request->requestType !== $methods[$action]) {
            throw new CHttpException(405);
        }
        if (App()->user->isGuest) {
            if ($action === 'exitPoll') {
                App()->user->setReturnUrl($request->getUrl());
                App()->getController()->redirect(App()->createUrl('admin/authentication/sa/login'));
            }
            throw new CHttpException(401);
        }
        $sid = filter_var($request->getQuery('sid'), FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
        if (!$sid || !Survey::model()->findByPk($sid)) {
            throw new CHttpException(404);
        }
        $canRead = self::has($sid, 'responses', 'read');
        $manage = $canRead && self::has($sid, 'surveycontent', 'update');
        $field = $manage || self::has($sid, 'responses', 'create');
        if ((!$canRead && !$field) || ($action === 'exitBatch' && !$field) || (!in_array($action,['exitPoll','exitBatch'],true) && !$manage)) {
            throw new CHttpException(403);
        }
        // New tables are also needed when an active 0.1 installation is upgraded in place.
        LcepExitStore::install();
        $error = '';
        $draft = [];
        if ($request->requestType === 'POST') {
            $token = $request->getPost($request->csrfTokenName);
            if (!is_string($token) || !hash_equals((string)$request->csrfToken, $token)) {
                throw new CHttpException(403, 'Odśwież formularz.');
            }
            $fields = [
                'exitCreate'=>['title','scope','source','date','seed','frame_text','options_text','opening','change','closing','per_stratum','step','step_mode','sizes_text','size_source'],
                'exitBatch'=>['point','shift','batch_id','votes','invited','refused','missed','invalid','no_ballot','declined','interruption','previous'],
                'exitFreeze'=>['confirmation','source'],
                'exitProtocol'=>['point','reference','valid','votes'],
            ];
            foreach ($fields[$action] as $key) {
                if ($request->getPost($key) !== null) {
                    $draft[$key] = $request->getPost($key);
                }
            }
            try {
                switch ($action) {
                    case 'exitCreate': LcepExitStore::create($sid, $draft); break;
                    case 'exitBatch': LcepExitStore::batch($sid, $draft, $manage); break;
                    case 'exitFreeze': LcepExitStore::freeze($sid, $draft); break;
                    case 'exitProtocol': LcepExitStore::protocol($sid, $draft); break;
                }
                App()->user->setState('exit-ok-' . $sid, 'Zapisano dane exit poll.');
                App()->getController()->redirect(LcepAdmin::url($sid, 'exitPoll'));
            } catch (DomainException $e) {
                http_response_code(422);
                $error = $e->getMessage();
            }
        }
        $project = LcepExitStore::project($sid);
        $plan = $project['plan'] ?? null;
        if (!$project && $action !== 'exitCreate') {
            $draft = [];
        }
        $assets = App()->assetManager->publish(dirname(__DIR__) . '/assets');
        header('Content-Type: text/html; charset=UTF-8');
        header("Content-Security-Policy: default-src 'none'; style-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'self'; base-uri 'none'");
        if ($action === 'exitPoll' && $request->getQuery('paper') === '1') {
            if (!$plan) {
                throw new CHttpException(404);
            }
            // Only the blank questionnaire is needed here. Do not load pack or protocol records.
            require dirname(__DIR__) . '/views/exitPaper.php';
            App()->end();
            return;
        }
        if (!$project && $manage && $action === 'exitPoll' && $request->getQuery('preset') !== null) {
            require_once __DIR__ . '/ExitArchive.php';
            try {
                $preset = $request->getQuery('preset') === '1' ? LcepExitArchive::preset($_GET) : null;
                if (!$preset) {
                    throw new DomainException('Brak kompletnej karty lub operatu dla wybranego głosowania.');
                }
                $draft = $preset;
                $formRows = [];
                foreach ($preset['frame'] as $p) {
                    $formRows[] = $p['stratum'] . ';' . $p['code'] . ';' . $p['label'];
                }
                $draft['frame_text'] = implode("\n", $formRows);
                $formRows = [];
                foreach ($preset['options'] as $code => $name) {
                    $formRows[] = $code . ';' . $name;
                }
                $draft['options_text'] = implode("\n", $formRows);
            } catch (DomainException $e) {
                http_response_code(422);
                $error = $e->getMessage();
            }
        }
        $batches = $project ? LcepExitStore::records($sid) : [];
        $closed = (bool)($project['closed'] ?? false);
        $protocols = $canRead && $closed ? LcepExitStore::records($sid, true) : [];
        $exit = $canRead && $closed ? LcepExitEstimate::calculate($plan, $batches) : null;
        $sensitivity = $exit && $exit['status'] === 'ready' ? LcepExitSensitivity::calculate($plan, $batches, $exit) : null;
        $late = $protocols ? LcepExitEstimate::calculate($plan, $batches, $protocols) : null;
        $comparison = $protocols ? LcepExitEstimate::compareProtocols($plan, $batches, $protocols) : [];
        $entryDraft = $action === 'exitBatch' ? $draft : [];
        $at = $entryDraft['point'] ?? ($action === 'exitPoll' ? $request->getQuery('point') : null);
        $shiftArg = $entryDraft['shift'] ?? ($action === 'exitPoll' ? $request->getQuery('shift', '1') : '1');
        $point = $at === null ? (string)array_key_first($plan['points'] ?? []) : $at;
        if (!is_string($point) || !isset($plan['points'][$point]) || !in_array($shiftArg, ['1','2'], true)) {
            if ($action === 'exitPoll' && ($at !== null || $request->getQuery('shift') !== null)) {
                throw new CHttpException(404);
            }
            $point = '';
        }
        $shift = $shiftArg === '2' ? 2 : 1;
        $byPoint = [];
        foreach ($batches as $batch) {
            $byPoint[$batch['point']][$batch['shift']] = $batch;
        }
        $notice = LcepAdmin::takeNotice('exit-ok-' . $sid);
        require dirname(__DIR__) . '/views/exit.php';
        App()->end();
    }
}
