<?php
// SPDX-License-Identifier: GPL-2.0-or-later
require_once __DIR__ . '/ExitInterval.php';

/** Hájek ratio of weighted valid choices; official counts substitute an entire sampled precinct. */
final class LcepExitEstimate
{
    /** Compare exactly the precincts with a verified protocol, without extrapolating to unsampled precincts. */
    public static function compareProtocols(array $plan, array $batches, array $protocols): array
    {
        $matched = array_column($protocols, null, 'point');
        $plan['points'] = array_intersect_key($plan['points'], $matched);
        if (!$plan['points']) {
            return [];
        }
        // Here the estimand is the set of known matched precincts. The person-level sampling design still applies.
        foreach ($plan['strata'] as $key => $stratum) {
            $plan['strata'][$key]['sample'] = $stratum['total'];
        }
        $estimated = self::summarize($plan, $batches, [], false);
        $benchmark = self::summarize($plan, [], $protocols, false);
        if ($estimated['status'] !== 'ready' || $benchmark['status'] !== 'ready') {
            return [];
        }
        $rows = [];
        foreach ($estimated['shares'] as $code => $share) {
            $official = $benchmark['shares'][$code];
            $rows[$code] = ['exit'=>$share, 'official'=>$official, 'difference'=>$share - $official];
        }
        return $rows;
    }

    public static function calculate(array $plan, array $batches, array $protocols = []): array
    {
        return self::summarize($plan, $batches, $protocols, !$protocols);
    }

    private static function summarize(array $plan, array $batches, array $protocols, bool $estimateIntervals): array
    {
        $sums = array_fill_keys(array_keys($plan['options']), 0.0);
        $raw = array_fill_keys(array_keys($sums), 0);
        $byPoint = [];
        foreach ($batches as $batch) {
            $byPoint[$batch['point']][$batch['shift']] = $batch;
        }
        $byProtocol = array_column($protocols, null, 'point');
        $covered = 0.0;
        $actual = 0;
        $missing = 0;
        foreach ($plan['points'] as $code => $point) {
            $stratum = $plan['strata'][$point['stratum']];
            $firstWeight = $stratum['total'] / $stratum['sample'];
            if (isset($byProtocol[$code])) {
                $official = $byProtocol[$code];
                $actual += $official['valid'];
                $covered += $firstWeight * $official['valid'];
                foreach ($official['votes'] as $answer => $count) {
                    $raw[$answer] += $count;
                    $sums[$answer] += $firstWeight * $count;
                }
                continue;
            }
            $step = LcepExitStep::forPoint($plan, $point);
            foreach ([1, 2] as $shift) {
                $batch = $byPoint[$code][$shift] ?? null;
                if (!$batch || !$batch['completed']) {
                    ++$missing;
                    continue;
                }
                $selected = $batch['invited'] + $batch['missed'];
                $w = $firstWeight * $step * $selected / $batch['completed'];
                foreach ($batch['votes'] as $answer => $count) {
                    $raw[$answer] += $count;
                    $sums[$answer] += $count * $w;
                }
            }
        }
        $total = array_sum($sums);
        $result = ['status'=>'ready', 'note'=>'', 'shares'=>[], 'protocol_count'=>count($byProtocol),
            'sample_points'=>count($plan['points']), 'official_valid'=>$actual,
            'estimated_official_share'=>null, 'missing_shifts'=>$missing];
        if ($missing) {
            $result['status'] = 'incomplete';
            $result['note'] = 'Brak ukończonych ankiet w ' . $missing . ' zmianach nieobjętych protokołami. Potrzebne jest pełne pokrycie wylosowanych punktów i zmian.';
        } elseif ($total <= 0 || array_sum($raw) < 30 || array_filter($raw, static function ($n) { return $n > 0 && $n < 5; })) {
            $result['status'] = 'suppressed';
            $result['note'] = 'Wynik ukryty. Wymagane jest co najmniej 30 ważnych wskazań i co najmniej 5 w każdej niepustej opcji.';
        } else {
            foreach ($sums as $code => $weighted) {
                $result['shares'][$code] = 100.0 * $weighted / $total;
            }
            $result['estimated_official_share'] = 100.0 * $covered / $total;
        }
        if ($estimateIntervals && $result['status'] === 'ready') {
            return $result + LcepExitInterval::calculate($plan, $byPoint, $result['shares'], $total);
        }
        return $result + ['intervals' => [], 'interval_reasons' => [], 'interval_note' => ''];
    }
}
