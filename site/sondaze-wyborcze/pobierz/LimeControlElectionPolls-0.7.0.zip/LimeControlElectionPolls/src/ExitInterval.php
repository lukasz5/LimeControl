<?php
// SPDX-License-Identifier: GPL-2.0-or-later
require_once __DIR__ . '/ExitStep.php';

/** Two-stage Taylor variance for a ratio of weighted valid choices. Inputs come from the private, releasable exit poll. */
final class LcepExitInterval
{
    /** All public numerical outputs use percentages or percentage points. */
    public static function calculate(array $plan, array $byPoint, array $shares, float $validTotal): array
    {
        $result = ['intervals' => [], 'interval_reasons' => [], 'interval_note' => ''];
        $designDf = 0;
        foreach ($plan['strata'] as $stratum) {
            if ($stratum['sample'] < $stratum['total']) {
                if ($stratum['sample'] < 2) {
                    $result['interval_note'] = 'W co najmniej jednej warstwie wylosowano tylko jeden z kilku obwodów. Do oszacowania zmienności między obwodami potrzeba co najmniej dwóch.';
                    return $result;
                }
                $designDf += $stratum['sample'] - 1;
            }
        }

        $census = $designDf === 0;
        $stations = [];
        foreach ($plan['points'] as $code => $point) {
            $shifts = [];
            $step = LcepExitStep::forPoint($plan, $point);
            foreach ($byPoint[$code] as $batch) {
                $m = $batch['completed'];
                // Reconstruct the stream size under random arrival ordering and ignorable response in this shift.
                $stream = $step * ($batch['invited'] + $batch['missed']);
                if ($m < 2 && $m < $stream) {
                    $result['interval_note'] = 'W co najmniej jednej zmianie z częściową realizacją jest tylko jedna ukończona ankieta. Potrzeba co najmniej dwóch, aby oszacować zmienność w tej zmianie.';
                    return $result;
                }
                if ($m < $stream || !empty($batch['declined']) || !empty($batch['interruption'])) {
                    $census = false;
                }
                $shifts[] = [
                    'm' => $m, 'stream' => $stream, 'scale' => $stream / $m,
                    'valid' => array_sum($batch['votes']), 'votes' => $batch['votes'],
                ];
            }
            $stations[$point['stratum']][] = $shifts;
        }

        foreach ($shares as $option => $share) {
            if ($census) {
                $result['intervals'][$option] = [
                    'lower' => $share, 'upper' => $share, 'se' => 0.0, 'df' => null, 'status' => 'census',
                ];
                continue;
            }
            $p = $share / 100;
            if ($p <= 0 || $p >= 1) {
                $result['interval_reasons'][$option] = 'Udział na granicy 0% lub 100%. Próba nie pozwala wyznaczyć przedziału t na skali logitowej.';
                continue;
            }

            [$variance, $withinDfDivisor] = self::variance($plan['strata'], $stations, $option, $p);
            $se = sqrt($variance) / $validTotal;
            if ($se <= 16 * PHP_FLOAT_EPSILON) {
                $result['interval_reasons'][$option] = 'Brak szacowalnej zmienności dla tej opcji przy niepełnych danych. Szerokość przedziału jest nieokreślona.';
                continue;
            }
            // If every PSU is included, use the independent shift components and their individual respondent df.
            $df = $designDf ?: max(1, (int) floor($variance * $variance / $withinDfDivisor));
            $logOdds = log($p / (1 - $p));
            $halfWidth = self::critical95($df) * $se / ($p * (1 - $p));
            $result['intervals'][$option] = [
                'lower' => self::inverseLogitPercent($logOdds - $halfWidth),
                'upper' => self::inverseLogitPercent($logOdds + $halfWidth),
                'se' => 100 * $se, 'df' => $df, 'status' => 'estimated',
            ];
        }
        return $result;
    }

    private static function variance(array $strata, array $stations, $option, float $p): array
    {
        $variance = 0.0;
        $withinDfDivisor = 0.0;
        foreach ($strata as $h => $stratum) {
            $population = $stratum['total'];
            $sample = $stratum['sample'];
            $firstWeight = $population / $sample;
            $mean = 0.0;
            $betweenSquares = 0.0;
            foreach ($stations[$h] as $index => $shifts) {
                $residual = 0.0;
                foreach ($shifts as $shift) {
                    $m = $shift['m'];
                    $a = $shift['votes'][$option];
                    $b = $shift['valid'] - $a;
                    $c = $m - $shift['valid'];
                    $residual += $shift['scale'] * ($a - $p * $shift['valid']);
                    if ($m === $shift['stream']) {
                        continue;
                    }
                    // z=1-p, -p or 0 (all other completed ballots). Pairwise differences avoid cancellation.
                    $shiftS2 = ($a * $b + $a * $c * (1 - $p) ** 2 + $b * $c * $p ** 2) / ($m * ($m - 1));
                    $component = $firstWeight * $shift['scale'] * ($shift['stream'] - $m) * $shiftS2;
                    $variance += $component;
                    $withinDfDivisor += $component * $component / ($m - 1);
                }
                // Welford's sum of squares of estimated PSU residual totals within this stratum.
                $difference = $residual - $mean;
                $mean += $difference / ($index + 1);
                $betweenSquares += $difference * ($residual - $mean);
            }
            if ($sample < $population) {
                $variance += $firstWeight * ($population - $sample) * $betweenSquares / ($sample - 1);
            }
        }
        return [$variance, $withinDfDivisor];
    }

    private static function inverseLogitPercent(float $value): float
    {
        $exp = exp(-abs($value));
        return $value >= 0 ? 100 / (1 + $exp) : 100 * $exp / (1 + $exp);
    }

    /** Student's t 0.975 quantile, tabulated for small df and expanded in inverse powers of df above 30. */
    private static function critical95(int $df): float
    {
        static $small = [
            1 => 12.7062047362, 4.3026527297, 3.1824463053, 2.7764451052, 2.5705818356,
            2.4469118511, 2.3646242516, 2.3060041352, 2.2621571628, 2.2281388520,
            2.2009851601, 2.1788128297, 2.1603686565, 2.1447866879, 2.1314495456,
            2.1199052992, 2.1098155778, 2.1009220402, 2.0930240544, 2.0859634473,
            2.0796138447, 2.0738730679, 2.0686576104, 2.0638985616, 2.0595385528,
            2.0555294386, 2.0518305165, 2.0484071418, 2.0452296421, 2.0422724563,
        ];
        if (isset($small[$df])) {
            return $small[$df];
        }
        $z = 1.959963984540054;
        return $z + ($z ** 3 + $z) / (4 * $df)
            + (5 * $z ** 5 + 16 * $z ** 3 + 3 * $z) / (96 * $df ** 2)
            + (3 * $z ** 7 + 19 * $z ** 5 + 17 * $z ** 3 - 15 * $z) / (384 * $df ** 3);
    }
}
