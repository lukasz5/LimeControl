<?php
// SPDX-License-Identifier: GPL-2.0-or-later

require_once __DIR__ . '/PollSurvey.php';
require_once __DIR__ . '/CampaignPlanner.php';

/** One project belongs to the first survey. The second survey keeps its own access boundary. */
final class LcEpPollStore
{
    const PROJECT = '{{lcep_projects}}';
    const EVENT = '{{lcep_events}}';
    const TASK = '{{lcep_tasks}}';
    const OPERATION = '{{lcep_planner_ops}}';

    public static function install()
    {
        $db = App()->db;
        if (!$db->schema->getTable($db->tablePrefix . 'lcep_projects', true)) {
            $db->createCommand()->createTable(self::PROJECT, [
                'sid' => 'integer PRIMARY KEY', 'wave2_sid' => 'integer NOT NULL',
                'revision' => 'integer NOT NULL', 'settings' => 'text NOT NULL',
            ]);
        }
        if (!$db->schema->getTable($db->tablePrefix . 'lcep_events', true)) {
            $db->createCommand()->createTable(self::EVENT, [
                'sid' => 'integer NOT NULL', 'request_id' => 'varchar(64) NOT NULL',
                'payload' => 'text NOT NULL', 'PRIMARY KEY (sid, request_id)',
            ]);
        }
        self::installPlanner();
    }

    /** Also supports an in-place file upgrade of an already active plugin. */
    private static function installPlanner()
    {
        $db = App()->db;
        foreach (['lcep_tasks'=>'payload', 'lcep_planner_ops'=>'digest'] as $table => $column) {
            if ($db->schema->getTable($db->tablePrefix . $table) !== null) {
                continue;
            }
            try {
                $db->createCommand()->createTable('{{' . $table . '}}', [
                    'sid'=>'integer NOT NULL', 'request_id'=>'varchar(64) NOT NULL',
                    $column=>$column === 'payload' ? 'text NOT NULL' : 'varchar(64) NOT NULL',
                    'PRIMARY KEY (sid, request_id)',
                ]);
            } catch (CDbException $error) {
                // Another first request after the upgrade can have created the same table.
                if (!$db->schema->getTable($db->tablePrefix . $table, true)) {
                    throw $error;
                }
            }
        }
    }

    /** Native afterSurveyDelete hook. Retire projects in which the deleted survey served either wave. */
    public static function onSurveyDeleted($sid)
    {
        $sid = (int)$sid;
        if ($sid < 1) {
            return;
        }
        $db = App()->db;
        $ownTransaction = $db->getCurrentTransaction() === null ? $db->beginTransaction() : null;
        try {
            $matching = $db->createCommand()->select('sid')->from(self::PROJECT)
                ->where('sid = :anchor OR wave2_sid = :linked', [':anchor' => $sid, ':linked' => $sid]);
            $sql = $matching->getText();
            if (in_array($db->driverName, ['mysql', 'pgsql'], true)) {
                $sql .= ' FOR UPDATE';
            }
            $anchors = $db->createCommand($sql)->queryColumn($matching->params);
            if ($anchors) {
                // All planner writes take the same project lock first. An upgraded active
                // instance may receive this hook before the first visit to its planner.
                foreach (['lcep_tasks'=>self::TASK, 'lcep_planner_ops'=>self::OPERATION] as $name=>$table) {
                    if ($db->schema->getTable($db->tablePrefix . $name)) {
                        $db->createCommand()->delete($table, ['in', 'sid', $anchors]);
                    }
                }
                $db->createCommand()->delete(self::EVENT, ['in', 'sid', $anchors]);
                $db->createCommand()->delete(self::PROJECT, ['in', 'sid', $anchors]);
            }
            if ($ownTransaction) {
                $ownTransaction->commit();
            }
        } catch (Throwable $error) {
            if ($ownTransaction && $ownTransaction->active) {
                $ownTransaction->rollback();
            }
            throw $error;
        }
    }

    private static function projectRow($sid, $lock = false)
    {
        $db = App()->db;
        $query = $db->createCommand()->select('sid, wave2_sid, revision, settings')->from(self::PROJECT)
            ->where('sid = :s', [':s' => (int)$sid]);
        if ($lock && in_array($db->driverName, ['mysql', 'pgsql'], true)) {
            return $db->createCommand($query->getText() . ' FOR UPDATE')->queryRow(true, $query->params);
        }
        return $query->queryRow();
    }

    private static function permitted($sid, $area, $action)
    {
        return !App()->user->isGuest && Permission::model()->hasSurveyPermission((int)$sid, $area, $action);
    }

    private static function canAccess($sid, $row, $editing)
    {
        return self::permitted($sid, 'responses', 'read')
            && (!$editing || self::permitted($sid, 'surveycontent', 'update'))
            && (!$row || self::permitted($row['wave2_sid'], 'responses', 'read'));
    }

    public static function canRead($sid)
    {
        return self::canAccess($sid, self::projectRow($sid), false);
    }

    public static function canEdit($sid)
    {
        return self::canAccess($sid, self::projectRow($sid), true);
    }

    private static function plannerAccess($sid, $row, $editing)
    {
        if (self::canAccess($sid, $row, $editing)) {
            return true;
        }
        if (!$row || App()->user->isGuest) {
            return false;
        }
        $permissions = Permission::model();
        return $permissions->hasGlobalPermission('lcep_planner', 'read')
            && (!$editing || $permissions->hasGlobalPermission('lcep_planner', 'update'))
            && self::permitted($sid, 'survey', 'read') && self::permitted($row['wave2_sid'], 'survey', 'read');
    }

    public static function canReadPlanner($sid)
    {
        return self::plannerAccess($sid, self::projectRow($sid), false);
    }

    public static function canEditPlanner($sid)
    {
        return self::plannerAccess($sid, self::projectRow($sid), true);
    }

    private static function committeeAccess($sid, $row)
    {
        return self::canAccess($sid, $row, false) || ($row && !App()->user->isGuest
            && Permission::model()->hasGlobalPermission('lcep_committee_report', 'read')
            && self::permitted($sid, 'survey', 'read') && self::permitted($row['wave2_sid'], 'survey', 'read'));
    }

    public static function canReadCommittee($sid)
    {
        return self::committeeAccess($sid, self::projectRow($sid));
    }

    public static function plannerProjects(bool $includeEntryTab = false): array
    {
        if (App()->user->isGuest) {
            return [];
        }
        $rows = App()->db->createCommand()->select('sid, wave2_sid, settings')->from(self::PROJECT)
            ->order('sid')->queryAll();
        $projects = [];
        foreach ($rows as $row) {
            $sid = (int)$row['sid'];
            $planner = self::plannerAccess($sid, $row, false);
            if ($planner || self::committeeAccess($sid, $row)) {
                $settings = json_decode($row['settings'], true, 64, JSON_THROW_ON_ERROR);
                $project = ['sid'=>$sid, 'title'=>$settings['title'], 'area'=>$settings['area']];
                if ($includeEntryTab) {
                    $project['entryTab'] = $planner ? 'planner' : 'committee';
                }
                $projects[] = $project;
            }
        }
        return $projects;
    }

    private static function authorizedRow($sid, $editing, $planner = false, $lock = false)
    {
        $row = self::projectRow($sid, $lock);
        $permitted = $planner ? self::plannerAccess($sid, $row, $editing) : self::canAccess($sid, $row, $editing);
        if (!$permitted) {
            throw new CHttpException(403);
        }
        return $row;
    }

    private static function settings($row)
    {
        $data = json_decode($row['settings'], true, 64, JSON_THROW_ON_ERROR);
        $data['revision'] = (int)$row['revision'];
        return $data;
    }

    public static function load($sid)
    {
        $row = self::authorizedRow($sid, false);
        return $row ? self::settings($row) : null;
    }

    private static function text(array $input, $key, $max, $optional = false)
    {
        $value = $input[$key] ?? '';
        if (!is_string($value)) {
            throw new DomainException('Pole formularza ma nieprawidłowy typ.');
        }
        $value = trim($value);
        if ((!$optional && $value === '') || !mb_check_encoding($value, 'UTF-8') || mb_strlen($value, 'UTF-8') > $max) {
            throw new DomainException('Sprawdź wymagane pola i długość wpisanych wartości.');
        }
        return $value;
    }

    private static function integer($value, $min)
    {
        if (!is_int($value) && !is_string($value)) {
            throw new DomainException('Podaj prawidłowy numer ankiety lub wersji formularza.');
        }
        $num = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => $min, 'max_range' => 2147483647]]);
        if ($num === false) {
            throw new DomainException('Podaj prawidłowy numer ankiety lub wersji formularza.');
        }
        return $num;
    }

    private static function date(array $input, $key)
    {
        $value = self::text($input, $key, 10);
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
        if (!$date || $date->format('Y-m-d') !== $value || $value < '1900-01-01' || $value >= '9999-01-01') {
            throw new DomainException('Podaj poprawną datę w formacie RRRR-MM-DD.');
        }
        return $value;
    }

    private static function dates(array $input)
    {
        $dates = ['start'=>self::date($input, 'start'), 'end'=>self::date($input, 'end')];
        if ($dates['start'] > $dates['end']) {
            throw new DomainException('Koniec okresu nie może poprzedzać jego początku.');
        }
        return $dates;
    }

    private static function geography(array $input)
    {
        $code = self::text($input, 'area', 8);
        if ($code === 'PL') {
            return $code;
        }
        if (preg_match('/^(?:W:\d{2}|P:\d{4}|[GB]:\d{6})$/D', $code)) {
            require_once __DIR__ . '/LocalArchive.php';
            $organ = $code[0] === 'B' ? 'dzielnica' : 'mayor';
            foreach (array_reverse(LcepLocalArchive::years($organ)) as $year) {
                if (LcepLocalArchive::name($year, $organ, $code) !== null) {
                    return $code;
                }
            }
        }
        throw new DomainException('Wskaż kod obszaru PKW z archiwum, np. PL, W:22, P:2204 lub G:220404.');
    }

    private static function related($left, $right)
    {
        if ($left === 'PL' || $right === 'PL') {
            return true;
        }
        if (($left === 'G:146501' && $right[0] === 'B') || ($right === 'G:146501' && $left[0] === 'B')) {
            return true;
        }
        $a = substr($left, 2);
        $b = substr($right, 2);
        return substr($a, 0, strlen($b)) === $b || substr($b, 0, strlen($a)) === $a;
    }

    private static function wave($input)
    {
        if (!is_array($input)) {
            throw new DomainException('Uzupełnij obie fale badania.');
        }
        return self::dates($input) + [
            'sid' => self::integer($input['sid'] ?? null, 1),
            'question' => self::text($input, 'question', 64), 'weight' => self::text($input, 'weight', 64, true),
            'geo' => self::text($input, 'geo', 64, true),
        ];
    }

    private static function conflict()
    {
        return new CHttpException(409, 'Projekt zmienił się od otwarcia formularza. Odśwież panel i ponów zapis.');
    }

    public static function save($sid, array $input)
    {
        $sid = (int)$sid;
        $old = self::authorizedRow($sid, true);
        $revision = self::integer($input['revision'] ?? null, 0);
        if ($revision !== (int)($old['revision'] ?? 0)) {
            throw self::conflict();
        }
        $config = [
            'title' => self::text($input, 'title', 180), 'area' => self::geography($input),
            'sponsor' => self::text($input, 'sponsor', 180), 'method' => self::text($input, 'method', 500),
            'design' => self::text($input, 'design', 24),
            'wave1' => self::wave($input['wave1'] ?? null), 'wave2' => self::wave($input['wave2'] ?? null),
        ];
        $first = $config['wave1'];
        $second = $config['wave2'];
        if ($first['sid'] !== $sid || $second['sid'] === $sid || $first['end'] >= $second['start']) {
            throw new DomainException('Fala 1 musi być ankietą bieżącą, a fala 2 osobną ankietą rozpoczynającą się po zakończeniu fali 1.');
        }
        if (!self::permitted($second['sid'], 'responses', 'read')) {
            throw new CHttpException(403);
        }
        if (!in_array($config['design'], ['descriptive', 'independent_srs'], true)) {
            throw new DomainException('Wybierz sposób wnioskowania dla dwóch fal.');
        }
        if (($first['weight'] === '') !== ($second['weight'] === '')
            || ($first['weight'] !== '' && $config['design'] !== 'descriptive')) {
            throw new DomainException('Wagi wymagają pola liczbowego w obu falach i analizy opisowej.');
        }
        $one = new LcEpPollSurvey($first);
        $two = new LcEpPollSurvey($second);
        if ($first['geo'] !== '' || $second['geo'] !== '') {
            if ($first['geo'] === '' || $second['geo'] === '' || $one->geoSignature() !== $two->geoSignature()) {
                throw new DomainException('W obu falach wskaż porównywalne pytania o obszar z tymi samymi kodami odpowiedzi.');
            }
            require_once __DIR__ . '/CommitteeSupport.php';
            LcEpCommitteeSupport::validateGeography($config['area'], $one->geoCodes());
            $config['geo_signature'] = $one->geoSignature();
        }
        $config['signature'] = $one->signature();
        if ($config['signature'] !== $two->signature()) {
            throw new DomainException('Porównanie wymaga tego samego języka bazowego, brzmienia pytania, kodów, kolejności oraz etykiet odpowiedzi w obu falach.');
        }
        $config['question_ids'] = [$one->identity(), $two->identity()];

        $fields = ['wave2_sid' => $second['sid'], 'revision' => $revision + 1,
            'settings' => json_encode($config, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)];
        $db = App()->db;
        if (!$old) {
            try {
                $db->createCommand()->insert(self::PROJECT, ['sid' => $sid] + $fields);
            } catch (CDbException $error) {
                if (self::projectRow($sid)) {
                    throw self::conflict();
                }
                throw $error;
            }
        } else {
            $updated = $db->createCommand()->update(self::PROJECT, $fields, 'sid = :s AND revision = :v',
                [':s' => $sid, ':v' => $revision]);
            if (!$updated) {
                throw self::conflict();
            }
        }
        $config['revision'] = $revision + 1;
        return $config;
    }

    private static function plannerId($value)
    {
        if (!is_string($value) || !preg_match('/^[a-f0-9]{32,64}$/D', $value)) {
            throw new DomainException('Nieprawidłowy identyfikator wpisu lub zapisu w planerze.');
        }
        return $value;
    }

    private static function plannerPayload($kind, array $input)
    {
        $status = self::text($input, 'status', 12);
        if ($kind === 'event') {
            if (!in_array($status, ['planned', 'held'], true)) {
                throw new DomainException('Wybierz poprawny status wydarzenia.');
            }
            $entry = self::dates($input) + [
                'title'=>self::text($input, 'title', 180), 'source'=>self::text($input, 'source', 500),
                'area'=>self::geography($input), 'status'=>$status,
            ];
        } else {
            if (!in_array($status, ['todo', 'doing', 'done'], true)) {
                throw new DomainException('Wybierz poprawny status zadania.');
            }
            $link = self::text($input + ['link'=>'project'], 'link', 70);
            if (!in_array($link, ['wave1', 'wave2', 'project'], true) && !preg_match('/^event:[0-9a-f]{32,64}$/D', $link)) {
                throw new DomainException('Wskaż projekt, falę albo wydarzenie tego projektu.');
            }
            $entry = ['title'=>self::text($input, 'title', 180), 'status'=>$status, 'due'=>self::date($input, 'due'), 'link'=>$link];
        }
        return $entry + [
            'responsible'=>self::text($input, 'responsible', 180, $kind === 'event'),
            'planned_cost'=>LcEpCampaignPlanner::money($input['planned_cost'] ?? null),
            'actual_cost'=>LcEpCampaignPlanner::money($input['actual_cost'] ?? null),
        ];
    }

    private static function itemQuery($table, $sid, $id)
    {
        return App()->db->createCommand()->from($table)
            ->where('sid = :s AND request_id = :id', [':s'=>$sid, ':id'=>$id]);
    }

    private static function eventDefaults()
    {
        return ['responsible'=>'', 'planned_cost'=>null, 'actual_cost'=>null];
    }

    private static function operationDigest($kind, $id, $create, array $entry)
    {
        return hash('sha256', json_encode([$kind, $id, $create, $entry], JSON_THROW_ON_ERROR));
    }

    /** Legacy event entry with the original poll-editor permission and create-only semantics. */
    public static function addEvent($sid, array $input)
    {
        unset($input['id']);
        self::writePlannerItem($sid, 'event', $input, false);
    }

    public static function saveEvent($sid, array $input)
    {
        self::writePlannerItem($sid, 'event', $input, true);
    }

    public static function saveTask($sid, array $input)
    {
        self::writePlannerItem($sid, 'task', $input, true);
    }

    private static function writePlannerItem($sid, $kind, array $input, $usePlannerGrant)
    {
        $sid = (int)$sid;
        self::authorizedRow($sid, true, $usePlannerGrant);
        $operation = self::plannerId($input['request_id'] ?? '');
        $create = !isset($input['id']) || $input['id'] === '';
        $id = $create ? $operation : self::plannerId($input['id']);
        if (!$create && $id === $operation) {
            throw self::conflict();
        }
        $revision = self::integer($input['revision'] ?? null, 1);
        $entry = self::plannerPayload($kind, $input);
        $digest = self::operationDigest($kind, $id, $create, $entry);
        $table = $kind === 'event' ? self::EVENT : self::TASK;
        self::installPlanner(); // DDL precedes the write transaction on MariaDB.
        $db = App()->db;
        $tx = $db->beginTransaction();
        try {
            $row = self::authorizedRow($sid, true, $usePlannerGrant, true);
            if (!$row) {
                throw new DomainException('Najpierw skonfiguruj projekt i obie fale.');
            }
            $receipt = self::itemQuery(self::OPERATION, $sid, $operation)->select('digest')->queryScalar();
            if ($receipt !== false) {
                if ($receipt !== $digest) {
                    throw self::conflict();
                }
                $tx->commit();
                return;
            }
            // Existing 0.5 event IDs also serve as reserved creation tokens.
            if ((!$create || $kind !== 'event')
                && self::itemQuery(self::EVENT, $sid, $operation)->select('request_id')->queryScalar() !== false) {
                throw self::conflict();
            }
            $prior = self::itemQuery($table, $sid, $id)->select('payload')->queryScalar();
            if ($create && $prior !== false) {
                // A 0.5 event has a stable ID but no receipt. Recognize its original form retry.
                if ($kind !== 'event' || (json_decode($prior, true, 16, JSON_THROW_ON_ERROR) + self::eventDefaults()) !== $entry) {
                    throw self::conflict();
                }
                $tx->commit();
                return;
            }
            if (!$create && $prior === false) {
                throw new DomainException('Wpis nie należy do tego projektu.');
            }
            if ((int)$row['revision'] !== $revision) {
                throw self::conflict();
            }
            if ($kind === 'event' && !self::related(self::settings($row)['area'], $entry['area'])) {
                throw new DomainException('Obszar wydarzenia musi pokrywać się z obszarem projektu.');
            }
            if ($kind === 'task' && strncmp($entry['link'], 'event:', 6) === 0
                && self::itemQuery(self::EVENT, $sid, substr($entry['link'], 6))->select('request_id')->queryScalar() === false) {
                throw new DomainException('Powiązane wydarzenie nie należy do tego projektu.');
            }
            $updated = $db->createCommand()->update(self::PROJECT, ['revision'=>$revision+1],
                'sid = :s AND revision = :v', [':s'=>$sid, ':v'=>$revision]);
            if (!$updated) {
                throw self::conflict();
            }
            $data = ['payload'=>json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)];
            if ($create) {
                $db->createCommand()->insert($table, ['sid'=>$sid, 'request_id'=>$id] + $data);
            } else {
                if ($kind === 'event' && self::itemQuery(self::OPERATION, $sid, $id)->select('digest')->queryScalar() === false) {
                    $old = json_decode($prior, true, 16, JSON_THROW_ON_ERROR) + self::eventDefaults();
                    $db->createCommand()->insert(self::OPERATION, ['sid'=>$sid, 'request_id'=>$id,
                        'digest'=>self::operationDigest('event', $id, true, $old)]);
                }
                $db->createCommand()->update($table, $data, 'sid = :s AND request_id = :id', [':s'=>$sid, ':id'=>$id]);
            }
            $db->createCommand()->insert(self::OPERATION, ['sid'=>$sid, 'request_id'=>$operation, 'digest'=>$digest]);
            $tx->commit();
        } catch (Throwable $error) {
            if ($tx->active) {
                $tx->rollback();
            }
            throw $error;
        }
    }

    public static function planner($sid)
    {
        $sid = (int)$sid;
        $row = self::authorizedRow($sid, false, true);
        if (!$row) {
            return null;
        }
        $data = self::plannerData($sid, $row);
        self::checkRevision(self::authorizedRow($sid, false, true), $data['revision']);
        return $data;
    }

    private static function checkRevision($row, $revision)
    {
        if (!$row || (int)$row['revision'] !== $revision) {
            throw self::conflict();
        }
    }

    private static function plannerData($sid, array $row)
    {
        self::installPlanner();
        $project = self::settings($row);
        $data = ['sid'=>$sid, 'revision'=>$project['revision'], 'title'=>$project['title'], 'area'=>$project['area']];
        foreach (['wave1','wave2'] as $wave) {
            $data[$wave] = array_intersect_key($project[$wave], ['start'=>true, 'end'=>true]);
        }
        foreach ([self::EVENT=>'events', self::TASK=>'tasks'] as $table=>$collection) {
            $records = App()->db->createCommand()->select('request_id, payload')->from($table)
                ->where('sid = :s', [':s'=>$sid])->order('request_id')->queryAll();
            $entries = [];
            foreach ($records as $record) {
                $entry = json_decode($record['payload'], true, 16, JSON_THROW_ON_ERROR);
                if ($collection === 'events') {
                    $entry += self::eventDefaults() + LcEpPollAnalysis::eventRelation($entry, $data['wave1'], $data['wave2']);
                }
                $entries[] = $entry + ['id'=>$record['request_id'], 'wave_label'=>LcEpCampaignPlanner::waveLabel(
                    $entry['start'] ?? $entry['due'], $entry['end'] ?? $entry['due'], $data)];
            }
            $day = $collection === 'events' ? 'start' : 'due';
            usort($entries, static function ($a, $b) use ($day) {
                return [$a[$day], $a['title'], $a['id']] <=> [$b[$day], $b['title'], $b['id']];
            });
            $data[$collection] = $entries;
        }
        $data['budget'] = LcEpCampaignPlanner::budget($data['events'], $data['tasks']);
        return $data;
    }

    private static function committeeRow($sid)
    {
        $row = self::projectRow($sid);
        if (!self::committeeAccess($sid, $row)) {
            throw new CHttpException(403);
        }
        return $row;
    }

    public static function committeeReport($sid, $requested)
    {
        $sid = (int)$sid;
        $row = self::committeeRow($sid);
        if (!$row) {
            return null;
        }
        require_once __DIR__ . '/CommitteeAreas.php';
        require_once __DIR__ . '/CommitteeSupport.php';
        $project = self::settings($row);
        $report = ['title'=>$project['title'], 'area'=>$project['area'], 'design'=>$project['design'],
            'mapped'=>!empty($project['geo_signature']), 'weighted'=>($project['wave1']['weight'] ?? '') !== '',
            'catalog'=>LcEpCommitteeAreas::catalog($project['area']), 'selected'=>[], 'support'=>[], 'activity'=>null];
        foreach (['wave1','wave2'] as $wave) {
            $report[$wave] = array_intersect_key($project[$wave], ['start'=>true, 'end'=>true]);
        }
        try {
            $report['selected'] = LcEpCommitteeAreas::selection($project['area'], $requested);
        } catch (DomainException $error) {
            $report['selection_error'] = $error->getMessage();
            $report['inputAreas'] = array_filter(array_slice((array)$requested, 0, 4), 'is_string');
        }
        if ($report['selected']) {
            $report['support'] = LcEpCommitteeSupport::compare($project, $report['selected']);
            $report['activity'] = LcEpCommitteeAreas::activity(self::plannerData($sid, $row), $report['selected']);
        }
        self::checkRevision(self::committeeRow($sid), $project['revision']);
        return $report;
    }

    public static function report($sid)
    {
        $project = self::load($sid);
        if (!$project) {
            return null;
        }
        $waves = [];
        foreach (['wave1', 'wave2'] as $index => $key) {
            $wave = $project[$key];
            try {
                $native = new LcEpPollSurvey($wave);
                if ($native->signature() !== $project['signature'] || $native->identity(false) !== array_slice($project['question_ids'][$index], 0, 2)) {
                    throw new DomainException('Po zapisaniu projektu zmieniła się karta lub przypisane pytanie. Zweryfikuj konfigurację fal.');
                }
                $waves[] = $native->estimate($wave, $project['design']);
            } catch (DomainException $error) {
                $waves[] = LcEpPollAnalysis::unavailable($wave, $error->getMessage());
            }
        }
        $records = App()->db->createCommand()->select('payload')->from(self::EVENT)
            ->where('sid = :s', [':s' => (int)$sid])->order('request_id')->queryColumn();
        $events = [];
        foreach ($records as $json) {
            $event = json_decode($json, true, 16, JSON_THROW_ON_ERROR);
            if (self::related($project['area'], $event['area'])) {
                $events[] = $event + LcEpPollAnalysis::eventRelation($event, $waves[0], $waves[1]);
            }
        }
        usort($events, static function ($a, $b) {
            return [$a['start'], $a['end'], $a['title']] <=> [$b['start'], $b['end'], $b['title']];
        });

        $note = 'Obszar projektu opisuje populację zrekrutowaną przez pracownię w obu ankietach. Obliczenie obejmuje tę populację jako całość. Zmiana to różnica udziałów między falami. Zbieżność z wydarzeniem nie ustala jego efektu.';
        if ($project['design'] === 'independent_srs') {
            $note .= ' Badacz zadeklarował niezależne proste próby losowe bez wag. Przybliżone przedziały 95% obliczono metodą Wilsona dla udziałów i Newcombe’a dla różnic (mała frakcja losowania).';
        } else {
            $note .= ' Analiza opisowa. Klasyczny margines błędu losowania nie jest wyliczany.';
        }
        // An editor may replace the linked survey or append an event while a large wave is aggregated.
        $latest = self::authorizedRow($sid, false);
        if (!$latest || (int)$latest['revision'] !== $project['revision']) {
            throw self::conflict();
        }
        return ['waves' => $waves, 'changes' => LcEpPollAnalysis::changes($waves[0], $waves[1]),
            'events' => $events, 'comparison_note' => $note];
    }
}
