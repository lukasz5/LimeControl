<?php
// SPDX-License-Identifier: GPL-2.0-or-later
require_once __DIR__ . '/ReportCsv.php';
require_once __DIR__ . '/LocalArchive.php';

class LcepAdmin
{
    public static function projectsUrl()
    {
        return App()->createUrl('plugins/direct', ['plugin' => 'LimeControlElectionPolls', 'function' => 'plannerProjects']);
    }

    public static function url($sid, $action, array $query = [])
    {
        return App()->createUrl('plugins/direct', [
            'plugin' => 'LimeControlElectionPolls',
            'function' => $action,
            'sid' => (int) $sid,
        ] + $query);
    }

    public static function takeNotice(string $key): string
    {
        $user = App()->user;
        $notice = (string) $user->getState($key, '');
        if ($notice !== '') {
            $user->removeState($key);
        }
        return $notice;
    }

    public function dispatch($action)
    {
        $methods = ['panel' => 'GET', 'plannerProjects' => 'GET', 'export' => 'GET', 'ballot' => 'GET', 'save' => 'POST', 'addEvent' => 'POST',
            'savePlannerEvent' => 'POST', 'savePlannerTask' => 'POST'];
        $request = App()->request;
        header('Cache-Control: private, no-store');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: no-referrer');
        if (!isset($methods[$action])) {
            throw new CHttpException(404);
        }
        if ($request->requestType !== $methods[$action]) {
            throw new CHttpException(405);
        }
        if (App()->user->isGuest) {
            if (in_array($action, ['panel', 'plannerProjects'], true)) {
                App()->user->setReturnUrl($request->getUrl());
                App()->getController()->redirect(App()->createUrl('admin/authentication/sa/login'));
            }
            throw new CHttpException(401);
        }
        if ($action === 'plannerProjects') {
            $projects = LcEpPollStore::plannerProjects(true);
            foreach ($projects as $index => $project) {
                $projects[$index]['url'] = self::url($project['sid'], 'panel', ['tab' => $project['entryTab']]);
            }
            $model = ['projects' => $projects, 'assets' => App()->assetManager->publish(dirname(__DIR__) . '/assets'),
                'backUrl' => App()->createUrl('dashboard/view')];
            $this->htmlHeaders();
            require dirname(__DIR__) . '/views/plannerProjects.php';
            App()->end();
            return;
        }
        $sid = filter_var($request->getQuery('sid'), FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if (!$sid || !Survey::model()->findByPk($sid)) {
            throw new CHttpException(404);
        }
        $tab = $request->getQuery('tab', 'report');
        $planning = ($action === 'panel' && $tab === 'planner') || in_array($action, ['savePlannerEvent', 'savePlannerTask'], true);
        $committee = $action === 'panel' && $tab === 'committee';
        $readable = $committee ? LcEpPollStore::canReadCommittee($sid)
            : ($planning ? LcEpPollStore::canReadPlanner($sid) : LcEpPollStore::canRead($sid));
        if (!$readable) {
            throw new CHttpException(403);
        }
        $canEdit = $planning ? LcEpPollStore::canEditPlanner($sid) : LcEpPollStore::canEdit($sid);
        if ($action === 'panel') {
            $this->render($sid, $canEdit, $tab);
        } elseif ($action === 'export') {
            $this->export($sid);
        } elseif ($action === 'ballot') {
            $this->ballot();
        } else {
            if (!$canEdit) {
                throw new CHttpException(403);
            }
            $submitted = $request->getPost($request->csrfTokenName);
            if (!is_string($submitted) || !hash_equals((string) $request->csrfToken, $submitted)) {
                throw new CHttpException(403, 'Odśwież formularz i spróbuj ponownie.');
            }
            $this->write($sid, $action);
        }
        App()->end();
    }

    private function ballot()
    {
        $request = App()->request;
        $year = filter_var($request->getQuery('year'), FILTER_VALIDATE_INT);
        $wave = filter_var($request->getQuery('wave'), FILTER_VALIDATE_INT);
        $code = $request->getQuery('area');
        $organ = $request->getQuery('organ', 'sejmik');
        if (!is_int($year) || !in_array($wave, [1, 2], true) || !is_string($code) || !is_string($organ)
            || !isset(LcepLocalArchive::ORGANS[$organ])) {
            throw new CHttpException(404);
        }
        require_once __DIR__ . '/Ballot.php';
        if ($organ === 'sejmik') {
            if (!preg_match('/^D:\d{2}:[1-9]\d?$/D', $code)) {
                throw new CHttpException(404);
            }
            $district = LcepPkwCatalog::area($year, $code);
            if (!$district) {
                throw new CHttpException(404);
            }
            $xml = LcepBallot::lss($year, $district, $wave);
            $filename = sprintf('sejmik-%d-%s-fala-%d.lss', $year, str_replace(':', '-', $code), $wave);
        } else {
            $page = $this->localPage($year, $organ, $code);
            if (!LcepLocalArchive::hasBallot($page)) {
                throw new CHttpException(404, 'W tym okręgu lub turze brak karty do głosowania.');
            }
            $title = LcepLocalArchive::title($page);
            $question = ($page['race']['card_type'] ?? '') === 'yes_no'
                ? 'Którą odpowiedź wybrałaby Pani lub wybrałby Pan na tej karcie z jednym kandydatem?'
                : 'Na kogo oddałaby Pani lub oddałby Pan głos spośród kandydatów na tej karcie?';
            $xml = LcepBallot::survey($wave, LcepLocalArchive::options($page), $title . ' · ' . $year,
                'Rekonstrukcja historycznej karty z danych PKW. ' . $title . ' · ' . $year,
                $question . ' ' . $title . ' · ' . $year);
            $filename = sprintf('%s-%d-%s-okreg-%d-tura-%d-fala-%d.lss', $organ, $year,
                str_replace(':', '-', $code), $page['district'], $page['round'], $wave);
        }
        header('Content-Type: application/xml; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo $xml;
    }

    private function localPage($year, $organ, $area)
    {
        $district = filter_var(App()->request->getQuery('district', 0), FILTER_VALIDATE_INT);
        $round = filter_var(App()->request->getQuery('round', 1), FILTER_VALIDATE_INT);
        if ($district === false || $round === false) {
            throw new CHttpException(400);
        }
        $page = LcepLocalArchive::page($year, $organ, $area, $district, $round);
        if (!$page) {
            throw new CHttpException(404, 'Brak wyników dla wybranego organu, obszaru, okręgu lub tury.');
        }
        return $page;
    }

    private function canExport($config)
    {
        if (!$config) {
            return false;
        }
        foreach (['wave1', 'wave2'] as $wave) {
            if (!Permission::model()->hasSurveyPermission((int) $config[$wave]['sid'], 'responses', 'export')) {
                return false;
            }
        }
        return true;
    }

    private function export($sid)
    {
        $config = LcEpPollStore::load($sid);
        if (!$this->canExport($config)) {
            throw new CHttpException(403);
        }
        try {
            $report = LcEpPollStore::report($sid);
        } catch (DomainException $e) {
            throw new CHttpException(422, $e->getMessage());
        }
        $current = LcEpPollStore::load($sid);
        if (!$current || $current['revision'] !== $config['revision'] || !$this->canExport($current)) {
            throw new CHttpException(409, 'Projekt uległ zmianie. Odśwież raport.');
        }
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="sondaz-' . (int) $sid . '.csv"');
        $stream = fopen('php://output', 'wb');
        LcepReportCsv::write($stream, $config, $report);
        fclose($stream);
    }

    private function write($sid, $action)
    {
        $request = App()->request;
        $eventFields = ['title', 'area', 'source', 'status', 'start', 'end', 'revision', 'request_id'];
        $fields = [
            'save' => ['title', 'area', 'sponsor', 'method', 'design', 'wave1', 'wave2', 'revision'],
            'addEvent' => $eventFields,
            'savePlannerEvent' => array_merge($eventFields, ['id', 'responsible', 'planned_cost', 'actual_cost']),
            'savePlannerTask' => ['id', 'request_id', 'revision', 'title', 'responsible', 'due', 'status', 'link', 'planned_cost', 'actual_cost'],
        ];
        $tab = ['save' => 'setup', 'addEvent' => 'events', 'savePlannerEvent' => 'planner', 'savePlannerTask' => 'planner'][$action];
        $redirectQuery = ['tab' => $tab === 'setup' ? 'report' : $tab];
        if ($tab === 'planner' && ($month = $this->plannerMonth($request)) !== null) {
            $redirectQuery['month'] = $month;
        }
        $input = [];
        foreach ($fields[$action] as $key) {
            $value = $request->getPost($key);
            if ($value !== null) {
                $input[$key] = $value;
            }
        }
        try {
            switch ($action) {
                case 'save': LcEpPollStore::save($sid, $input); break;
                case 'addEvent': LcEpPollStore::addEvent($sid, $input); break;
                case 'savePlannerEvent': LcEpPollStore::saveEvent($sid, $input); break;
                case 'savePlannerTask': LcEpPollStore::saveTask($sid, $input); break;
            }
            $message = ['save' => 'Zapisano konfigurację fal.', 'addEvent' => 'Zapisano wydarzenie.',
                'savePlannerEvent' => 'Zapisano wydarzenie.', 'savePlannerTask' => 'Zapisano zadanie.'];
            App()->user->setState('lcep-notice-' . $sid, $message[$action]);
            App()->getController()->redirect(self::url($sid, 'panel', $redirectQuery));
        } catch (DomainException $e) {
            http_response_code(422);
            $this->render($sid, true, $tab, $e->getMessage(), $input, $action);
        }
    }

    private function plannerMonth($request): ?string
    {
        $month = $request->getQuery('month');
        if ($month !== null && (!is_string($month) || !preg_match('/^\d{4}-(?:0[1-9]|1[0-2])$/D', $month)
                || $month < '1900-01' || $month > '9998-12')) {
            throw new CHttpException(400, 'Wybierz poprawny miesiąc kalendarza.');
        }
        return $month;
    }

    private function plannerEntry($id, array $entries, $canEdit)
    {
        if ($id === null || $id === '') {
            return null;
        }
        if (!$canEdit) {
            throw new CHttpException(403);
        }
        if (is_string($id)) {
            foreach ($entries as $entry) {
                if ($entry['id'] === $id) {
                    return $entry;
                }
            }
        }
        throw new CHttpException(404, 'Brak wpisu w tym projekcie.');
    }

    private function render($sid, $canEdit, $tab, $error = '', array $input = [], $action = '')
    {
        if (!in_array($tab, ['report', 'setup', 'events', 'history', 'planner', 'committee'], true)) {
            throw new CHttpException(404);
        }
        $request = App()->request;
        if ($tab === 'setup' && !$canEdit) {
            throw new CHttpException(403);
        }
        $planner = $editEvent = $editTask = $month = $committee = null;
        if ($tab === 'committee') {
            $committee = LcEpPollStore::committeeReport($sid, $request->getQuery('areas', []));
            $config = $committee ? array_intersect_key($committee, array_flip(['title','area','wave1','wave2'])) : null;
            if (!empty($committee['selection_error'])) {
                http_response_code(422);
                $error = $committee['selection_error'];
            }
        } elseif ($tab === 'planner') {
            $month = $this->plannerMonth($request);
            $planner = LcEpPollStore::planner($sid);
            $config = $planner;
            $eventId = $action === 'savePlannerEvent' ? ($input['id'] ?? null) : $request->getQuery('edit_event');
            $taskId = $action === 'savePlannerTask' ? ($input['id'] ?? null) : $request->getQuery('edit_task');
            if ($eventId && $taskId) {
                throw new CHttpException(400, 'Wybierz jeden wpis do edycji.');
            }
            $editEvent = $this->plannerEntry($eventId, $planner['events'] ?? [], $canEdit);
            $editTask = $this->plannerEntry($taskId, $planner['tasks'] ?? [], $canEdit);
        } else {
            $config = LcEpPollStore::load($sid);
        }
        $report = null;
        if ($config && in_array($tab, ['report', 'events'], true)) {
            try {
                $report = LcEpPollStore::report($sid);
            } catch (DomainException $e) {
                $error = $error ?: $e->getMessage();
            }
        }
        $organ = $tab === 'history' ? $request->getQuery('organ', 'sejmik') : 'sejmik';
        if (!is_string($organ) || !isset(LcepLocalArchive::ORGANS[$organ])) {
            throw new CHttpException(404);
        }
        $years = $organ === 'sejmik' ? LcepPkwCatalog::years() : LcepLocalArchive::years($organ);
        $year = filter_var($request->getQuery('year', 2024), FILTER_VALIDATE_INT);
        if (!in_array($year, $years, true)) {
            throw new CHttpException(404, 'Ten rocznik jest niedostępny.');
        }
        $code = $request->getQuery('area', 'PL');
        if (!is_string($code) || strlen($code) > 64) {
            throw new CHttpException(400);
        }
        $sejmikHistory = $tab === 'history' && $organ === 'sejmik';
        $local = $organ === 'sejmik' ? null : $this->localPage($year, $organ, $code);
        $precinct = $request->getQuery('precinct');
        if ($precinct !== null && (!is_string($precinct) || !isset($local['race']['precincts'][$precinct]))) {
            throw new CHttpException(404, 'Brak obwodu na wybranej karcie.');
        }
        $localYearAreas = [];
        if ($local) {
            foreach ($years as $vintage) {
                if ($vintage === $year || LcepLocalArchive::name($vintage, $organ, $code) !== null) {
                    $localYearAreas[$vintage] = $code;
                }
            }
        }
        $area = $sejmikHistory ? LcepPkwCatalog::area($year, $code) : null;
        if ($sejmikHistory && $area === null) {
            throw new CHttpException(404, 'Brak jednostki w wybranej elekcji.');
        }
        $historicalLinks = [];
        $yearAreas = [];
        $scope = $tab === 'history' ? $code : ($config['area'] ?? '');
        if (($tab === 'report' || $sejmikHistory) && preg_match('/^(?:PL|W:\d{2}|P:\d{4}|[GB]:\d{6})$/D', $scope)) {
            foreach ($years as $vintage) {
                $match = $area && $vintage === $year ? $area : LcepPkwCatalog::area($vintage, $scope);
                if ($match) {
                    $yearAreas[$vintage] = $scope;
                    $historicalLinks[] = ['year' => $vintage, 'name' => $match['name'],
                        'url' => self::url($sid, 'panel', ['tab' => 'history', 'year' => $vintage, 'area' => $scope])];
                }
            }
        }
        $raceQuery = [];
        $canDraw = false;
        if ($area && $area['level'] === 'okreg') {
            $raceQuery = ['year' => $year, 'area' => $code];
            $canDraw = true;
        } elseif ($local && LcepLocalArchive::hasBallot($local)) {
            $raceQuery = LcepLocalArchive::query($local);
            $canDraw = !empty($local['race']['precincts']);
        }
        $canManageExit = LcepExitAdmin::canManage($sid);
        $model = [
            'planner' => $planner, 'editEvent' => $editEvent, 'editTask' => $editTask,
            'committee' => $committee, 'canReadCommittee' => LcEpPollStore::canReadCommittee($sid),
            'canReadPlanner' => LcEpPollStore::canReadPlanner($sid),
            'plannerOnly' => in_array($tab, ['planner','committee'], true) && !LcEpPollStore::canRead($sid),
            'canConfigure' => $tab === 'planner' ? LcEpPollStore::canEdit($sid) : $canEdit,
            'calendarMonth' => $month,
            'plannerEventUrl' => self::url($sid, 'savePlannerEvent', $month === null ? [] : ['month' => $month]),
            'plannerTaskUrl' => self::url($sid, 'savePlannerTask', $month === null ? [] : ['month' => $month]),
            'plannerEventInput' => $action === 'savePlannerEvent' ? $input : [],
            'plannerTaskInput' => $action === 'savePlannerTask' ? $input : [],
            'sid' => $sid, 'config' => $config, 'report' => $report, 'events' => $report['events'] ?? [],
            'area' => $area, 'years' => $years, 'year' => $year,
            'metadata' => $area ? LcepPkwCatalog::metadata($year) : [],
            'historicalLinks' => $historicalLinks, 'yearAreas' => $yearAreas,
            'organ' => $organ, 'local' => $local, 'localYearAreas' => $localYearAreas, 'precinct' => $precinct,
            'exitUrl' => LcepExitAdmin::canView($sid) ? self::url($sid, 'exitPoll') : '',
            'exitPresetUrl' => $canManageExit && $canDraw ? self::url($sid, 'exitPoll', ['preset' => 1] + $raceQuery) : '',
            'ballotUrls' => $raceQuery ? [
                1 => self::url($sid, 'ballot', ['wave' => 1] + $raceQuery),
                2 => self::url($sid, 'ballot', ['wave' => 2] + $raceQuery),
            ] : [],
            'tab' => $tab, 'canEdit' => $canEdit, 'error' => $error,
            'projectInput' => $tab === 'setup' ? $input : [],
            'eventInput' => $tab === 'events' ? $input : [],
            'notice' => self::takeNotice('lcep-notice-' . $sid),
            'assets' => App()->assetManager->publish(dirname(__DIR__) . '/assets'),
            'csrfName' => $request->csrfTokenName, 'csrfToken' => $request->csrfToken,
            'url' => self::url($sid, 'panel'),
            'scope' => is_string($request->getQuery('scope')) && preg_match('/^(?:PL|W:\d{2}|P:\d{4}|[GB]:\d{6})$/D', $request->getQuery('scope'))
                ? $request->getQuery('scope') : null,
            'exportUrl' => $report && $this->canExport($config) ? self::url($sid, 'export') : '',
            'panelUrl' => static function (array $params) use ($sid) { return self::url($sid, 'panel', $params); },
            'saveUrl' => self::url($sid, 'save'), 'eventUrl' => self::url($sid, 'addEvent'),
            'backUrl' => App()->createUrl('surveyAdministration/view', ['surveyid' => $sid]),
        ];
        if ($model['plannerOnly']) {
            $model['backUrl'] = self::projectsUrl();
        }
        $this->htmlHeaders();
        require dirname(__DIR__) . '/views/panel.php';
    }

    private function htmlHeaders()
    {
        header('Content-Type: text/html; charset=UTF-8');
        header("Content-Security-Policy: default-src 'none'; style-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'self'; base-uri 'none'");
    }
}
