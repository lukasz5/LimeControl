<?php
// SPDX-License-Identifier: GPL-2.0-or-later

/** Size proxies from a prior election. Current election results never enter the allocation. */
final class LcepExitFrameSize
{
    private const DIRECTORY = __DIR__ . '/../data/frame-size/';
    private const PREVIOUS = [2018 => 2015, 2024 => 2023];
    private static $cachedYear;
    private static $sizes = [];

    public static function source(int $year): string
    {
        return isset(self::PREVIOUS[$year])
            ? 'KBW · liczba wyborców w wykazie obwodów z ' . self::PREVIOUS[$year] . ' r. · zgodne obwody lub mediana tego samego typu'
            : '';
    }

    /** Return no preset if any of these points cannot be linked to the historical frame. */
    public static function forPoints(int $year, array $codes, bool $warsawMayor = false): array
    {
        if (!isset(self::PREVIOUS[$year]) || !$codes) {
            return [];
        }
        if (self::$cachedYear !== $year) {
            $manifest = json_decode(file_get_contents(self::DIRECTORY . 'manifest.json'), true);
            $data = file_get_contents(self::DIRECTORY . $year . '.json');
            if ($data === false || ($manifest[$year]['sha256'] ?? '') !== hash('sha256', $data)) {
                throw new RuntimeException('Niespójne dane o wielkości obwodów. Sprawdź paczkę wtyczki.');
            }
            $sizes = json_decode($data, true);
            if (!is_array($sizes) || count($sizes) !== $manifest[$year]['precincts']) {
                throw new RuntimeException('Nieprawidłowy wykaz wielkości obwodów.');
            }
            self::$sizes = $sizes;
            self::$cachedYear = $year;
        }
        $lookup = self::$sizes;
        if ($warsawMayor) {
            // The mayor archive uses the city's TERYT. The sejmik frame uses the borough's.
            $lookup = [];
            foreach (self::$sizes as $code => $size) {
                if (strncmp($code, 'O:1465', 6) === 0) {
                    $cityCode = 'O:146501:' . explode(':', $code)[2];
                    if (isset($lookup[$cityCode])) {
                        throw new RuntimeException('Niejednoznaczny numer obwodu w Warszawie.');
                    }
                    $lookup[$cityCode] = $size;
                }
            }
        }
        $result = [];
        foreach ($codes as $code) {
            if (!isset($lookup[$code])) {
                return [];
            }
            $result[$code] = $lookup[$code];
        }
        return $result;
    }
}
