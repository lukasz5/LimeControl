<?php
// SPDX-License-Identifier: GPL-2.0-or-later
require_once __DIR__ . '/ExitDesign.php';
require_once __DIR__ . '/ExitEstimate.php';

final class LcepExitStore
{
    const PLAN = '{{lcep_exit_plan}}';
    const PACK = '{{lcep_exit_pack}}';
    const PROTOCOL = '{{lcep_exit_protocol}}';

    public static function install()
    {
        $db = App()->db;
        $long = $db->driverName === 'mysql' ? 'mediumtext NOT NULL' : 'text NOT NULL';
        $tables = [
            'lcep_exit_plan'=>['sid'=>'integer PRIMARY KEY', 'definition'=>$long, 'closed'=>'string(32)', 'closure_source'=>'text'],
            'lcep_exit_pack'=>['sid'=>'integer NOT NULL', 'point'=>'string(64) NOT NULL', 'shift_no'=>'integer NOT NULL',
                'batch_key'=>'string(56) NOT NULL', 'payload'=>'text NOT NULL', 'PRIMARY KEY (sid, point, shift_no)', 'UNIQUE (sid, batch_key)'],
            'lcep_exit_protocol'=>['sid'=>'integer NOT NULL', 'point'=>'string(64) NOT NULL', 'recorded'=>'string(32) NOT NULL',
                'payload'=>'text NOT NULL', 'PRIMARY KEY (sid, point)'],
        ];
        foreach ($tables as $table => $schema) {
            $name = $db->tablePrefix . $table;
            if (!$db->schema->getTable($name)) {
                try {
                    $db->createCommand()->createTable('{{' . $table . '}}', $schema);
                } catch (CDbException $e) {
                    // Another request can complete the same first-run upgrade between lookup and CREATE.
                    if (!$db->schema->getTable($name, true)) {
                        throw $e;
                    }
                    continue;
                }
                $db->schema->getTable($name, true);
            }
        }
    }

    public static function onSurveyDeleted($sid)
    {
        $sid = (int)$sid;
        $db = App()->db;
        if ($sid < 1 || !$db->schema->getTable($db->tablePrefix . 'lcep_exit_plan')) {
            return;
        }
        self::transaction(static function () use ($db, $sid) {
            self::row($sid, true);
            foreach ([self::PACK, self::PROTOCOL, self::PLAN] as $table) {
                $db->createCommand()->delete($table, 'sid=:sid', [':sid'=>$sid]);
            }
        });
    }

    private static function transaction(callable $fn)
    {
        $db = App()->db;
        $tx = $db->getCurrentTransaction() ? null : $db->beginTransaction();
        try {
            $result = $fn();
            if ($tx) {
                $tx->commit();
            }
            return $result;
        } catch (Throwable $e) {
            if ($tx && $tx->active) {
                $tx->rollback();
            }
            throw $e;
        }
    }

    private static function row(int $sid, bool $lock = false)
    {
        $db = App()->db;
        if ($lock && in_array($db->driverName, ['sqlsrv', 'dblib', 'mssql'], true)) {
            return $db->createCommand('SELECT * FROM {{lcep_exit_plan}} WITH (UPDLOCK, HOLDLOCK) WHERE sid=:sid')
                ->queryRow(true, [':sid'=>$sid]);
        }
        $query = $db->createCommand()->select('*')->from(self::PLAN)->where('sid=:sid', [':sid'=>$sid]);
        if (!$lock || !in_array($db->driverName, ['mysql','pgsql'], true)) {
            return $query->queryRow();
        }
        return $db->createCommand($query->getText() . ' FOR UPDATE')->queryRow(true, $query->params);
    }

    public static function project(int $sid): ?array
    {
        $row = self::row($sid);
        return $row ? ['plan'=>self::decode($row['definition']), 'closed'=>$row['closed'], 'source'=>$row['closure_source']] : null;
    }

    private static function json(array $v): string { return json_encode($v, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR); }
    private static function decode(string $v): array { return json_decode($v, true, 32, JSON_THROW_ON_ERROR); }
    private static function now(): string { return gmdate('Y-m-d\TH:i:s\Z'); }
    private static function fingerprint(int $sid, string $payload): string
    {
        // Before freeze, revision tokens must not allow guessing candidate tallies from small packs.
        return hash_hmac('sha256', 'lcep-exit-pack:' . $sid . ':' . $payload, App()->securityManager->validationKey);
    }

    public static function create(int $sid, array $input)
    {
        $plan = LcepExitDesign::plan($input);
        try {
            App()->db->createCommand()->insert(self::PLAN, ['sid'=>$sid, 'definition'=>self::json($plan)]);
        } catch (CDbException $error) {
            if (self::row($sid)) {
                throw new DomainException('Ta ankieta ma już własne losowanie. Dla innej karty lub tury wybierz osobną ankietę.');
            }
            throw $error;
        }
    }

    private static function withProject(int $sid, callable $fn)
    {
        self::transaction(static function () use ($sid, $fn) {
            $row = self::row($sid, true);
            if (!$row) {
                throw new DomainException('Najpierw zapisz operat i wylosuj obwody.');
            }
            $fn(self::decode($row['definition']), $row);
        });
    }

    public static function batch(int $sid, array $input, bool $canCorrect)
    {
        self::withProject($sid, static function ($plan, $row) use ($sid, $input, $canCorrect) {
            $batch = LcepExitDesign::batch($plan, $input);
            $json = self::json($batch);
            $db = App()->db;
            $args = [':sid'=>$sid, ':point'=>$batch['point'], ':shift'=>$batch['shift']];
            $where = 'sid=:sid AND point=:point AND shift_no=:shift';
            $old = $db->createCommand()->select('batch_key,payload')->from(self::PACK)->where($where, $args)->queryRow();
            if ($old && $old['payload'] === $json) {
                return;
            }
            if ($row['closed']) {
                throw new DomainException('Exit poll został zamrożony.');
            }
            if ($old) {
                $prior = $input['previous'] ?? '';
                if (!$canCorrect || !is_string($prior) || !hash_equals(self::fingerprint($sid, $old['payload']), $prior)
                    || $old['batch_key'] !== $batch['batch_id']) {
                    throw new DomainException('Ta zmiana ma już zapis. Korektę może nanieść koordynator na aktualnej wersji tej samej paczki.');
                }
                $db->createCommand()->update(self::PACK, ['payload'=>$json], $where, $args);
            } else {
                $duplicate = $db->createCommand()->select('point')->from(self::PACK)
                    ->where('sid=:sid AND batch_key=:id', [':sid'=>$sid, ':id'=>$batch['batch_id']])->queryScalar();
                if ($duplicate !== false) {
                    throw new DomainException('Numer paczki został użyty w innym obwodzie lub na innej zmianie.');
                }
                $db->createCommand()->insert(self::PACK, ['sid'=>$sid, 'point'=>$batch['point'], 'shift_no'=>$batch['shift'],
                    'batch_key'=>$batch['batch_id'], 'payload'=>$json]);
            }
        });
    }

    public static function freeze(int $sid, array $input)
    {
        self::withProject($sid, static function ($plan, $row) use ($sid, $input) {
            if ($row['closed']) {
                return;
            }
            $source = LcepExitDesign::text($input['source'] ?? '', 600, 'potwierdzenie zakończenia głosowania');
            $scheduled = new DateTimeImmutable($plan['date'] . ' ' . $plan['closing'], new DateTimeZone('Europe/Warsaw'));
            if (($input['confirmation'] ?? '') !== '1' || time() < $scheduled->getTimestamp()) {
                throw new DomainException('Potwierdź rzeczywiste zakończenie głosowania po planowanym terminie.');
            }
            $received = (int)App()->db->createCommand()->select('COUNT(*)')->from(self::PACK)->where('sid=:sid', [':sid'=>$sid])->queryScalar();
            if ($received !== 2 * count($plan['points'])) {
                throw new DomainException('Uzgodnij paczki dla obu zmian w każdym punkcie. Zerową realizację zapisz wraz z przyczyną.');
            }
            App()->db->createCommand()->update(self::PLAN, ['closed'=>self::now(), 'closure_source'=>$source], 'sid=:sid', [':sid'=>$sid]);
        });
    }

    public static function protocol(int $sid, array $input)
    {
        self::withProject($sid, static function ($plan, $row) use ($sid, $input) {
            if (!$row['closed']) {
                throw new DomainException('Najpierw zamroź exit poll po zakończeniu głosowania.');
            }
            $proto = LcepExitDesign::protocol($plan, $input);
            $json = self::json($proto);
            $db = App()->db;
            $old = $db->createCommand()->select('payload')->from(self::PROTOCOL)
                ->where('sid=:sid AND point=:point', [':sid'=>$sid, ':point'=>$proto['point']])->queryScalar();
            if ($old === $json) {
                return;
            }
            if ($old !== false) {
                throw new DomainException('Obwód ma już inny zweryfikowany protokół.');
            }
            $db->createCommand()->insert(self::PROTOCOL, ['sid'=>$sid, 'point'=>$proto['point'], 'recorded'=>self::now(), 'payload'=>$json]);
        });
    }

    public static function records(int $sid, bool $protocol = false): array
    {
        $q = App()->db->createCommand()->select($protocol ? 'payload,recorded' : 'payload')
            ->from($protocol ? self::PROTOCOL : self::PACK)->where('sid=:sid', [':sid'=>$sid])
            ->order($protocol ? 'recorded,point' : 'point,shift_no');
        $records = [];
        foreach ($q->queryAll() as $row) {
            $item = self::decode($row['payload']);
            if ($protocol) {
                $item['recorded'] = $row['recorded'];
            } else {
                $item['fingerprint'] = self::fingerprint($sid, $row['payload']);
            }
            $records[] = $item;
        }
        return $records;
    }
}
