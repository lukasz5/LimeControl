<?php
// SPDX-License-Identifier: GPL-2.0-or-later
require_once __DIR__ . '/src/PkwCatalog.php';
require_once __DIR__ . '/src/PollStore.php';
require_once __DIR__ . '/src/Admin.php';
require_once __DIR__ . '/src/ExitAdmin.php';

class LimeControlElectionPolls extends PluginBase
{
    protected static $name = 'LimeControlElectionPolls';
    protected static $description = 'Sondaże samorządowe, planer kampanii, archiwum PKW i exit poll';

    public function init()
    {
        $this->subscribe('beforeActivate');
        $this->subscribe('afterSurveyDelete');
        $this->subscribe('beforeToolsMenuRender');
        $this->subscribe('beforeAdminMenuRender');
        $this->subscribe('getGlobalBasePermissions');
        $this->subscribe('newDirectRequest');
    }

    public function beforeActivate()
    {
        LcEpPollStore::install();
        LcepExitStore::install();
    }

    public function getGlobalBasePermissions()
    {
        $this->getEvent()->append('globalBasePermissions', ['lcep_planner' => [
            'title' => 'Planer kampanii wyborczej', 'description' => 'Odczyt lub edycja kalendarza, zadań i kosztów w projektach, do których użytkownik ma dostęp do obu ankiet.',
            'img' => 'ri-calendar-line', 'read' => true, 'update' => true,
            'create' => false, 'delete' => false, 'import' => false, 'export' => false,
        ], 'lcep_committee_report' => [
            'title' => 'Raport dla komitetu', 'description' => 'Porównanie zbiorczego poparcia, wydarzeń i kosztów w projektach, do których użytkownik ma dostęp do obu ankiet.',
            'img' => 'ri-bar-chart-line', 'read' => true, 'update' => false,
            'create' => false, 'delete' => false, 'import' => false, 'export' => false,
        ]]);
    }

    public function afterSurveyDelete()
    {
        $survey = $this->getEvent()->get('model');
        if ($survey instanceof Survey) {
            LcEpPollStore::onSurveyDeleted((int) $survey->sid);
            LcepExitStore::onSurveyDeleted((int) $survey->sid);
        }
    }

    public function beforeToolsMenuRender()
    {
        $event = $this->getEvent();
        $sid = (int) $event->get('surveyId');
        if (!$sid || App()->user->isGuest) {
            return;
        }
        $items = $event->get('menuItems') ?: [];
        if (LcEpPollStore::canRead($sid)) {
            $items[] = new \LimeSurvey\Menu\MenuItem(['label' => 'Sondaże wyborcze',
                'href' => LcepAdmin::url($sid, 'panel'), 'iconClass' => 'ri-bar-chart-line']);
        }
        if (LcEpPollStore::canReadPlanner($sid)) {
            $items[] = new \LimeSurvey\Menu\MenuItem(['label' => 'Planer kampanii',
                'href' => LcepAdmin::url($sid, 'panel', ['tab' => 'planner']), 'iconClass' => 'ri-calendar-line']);
        }
        if (LcEpPollStore::canReadCommittee($sid)) {
            $items[] = new \LimeSurvey\Menu\MenuItem(['label' => 'Raport dla komitetu',
                'href' => LcepAdmin::url($sid, 'panel', ['tab' => 'committee']), 'iconClass' => 'ri-bar-chart-line']);
        }
        if (LcepExitAdmin::canView($sid)) {
            $items[] = new \LimeSurvey\Menu\MenuItem(['label' => 'Exit poll',
                'href' => LcepAdmin::url($sid, 'exitPoll'), 'iconClass' => 'ri-survey-line']);
        }
        $event->set('menuItems', $items);
    }

    public function beforeAdminMenuRender()
    {
        if (!App()->user->isGuest) {
            $this->getEvent()->append('extraMenus', [new \LimeSurvey\Menu\Menu([
                'label' => 'Planery kampanii', 'href' => LcepAdmin::projectsUrl(), 'iconClass' => 'ri-calendar-line',
            ])]);
        }
    }

    public function newDirectRequest()
    {
        $event = $this->getEvent();
        if ($event->get('target') === self::$name) {
            $action = (string) $event->get('function');
            if (in_array($action, ['exitPoll', 'exitCreate', 'exitBatch', 'exitFreeze', 'exitProtocol'], true)) {
                (new LcepExitAdmin())->dispatch($action);
                return;
            }
            (new LcepAdmin())->dispatch($action);
        }
    }
}
