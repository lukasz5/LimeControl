# Jak często przedział exit poll obejmował wynik PKW w 2024 r.

Przy losowaniu czterech obwodów na warstwę, zaproszeniu co piątej osoby i pełnej odpowiedzi **99 415 ze 106 503 wyznaczonych przedziałów objęło rzeczywisty udział listy w okręgu**. Pokrycie wyniosło **93,34%** przy nominalnym poziomie 95%. Wtyczka mogła podać przedział w **50,28%** zaplanowanych porównań. Wśród wszystkich 211 800 porównań odsetek, w którym przedział powstał i obejmował wynik, wyniósł **46,94%**.

## Co sprawdzono

W każdym z 85 okręgów wyborów do sejmików z 7 kwietnia 2024 r. wzorcem był oficjalny udział każdej zarejestrowanej tam listy w ważnych głosach tego okręgu. Każda para lista–okręg ma jednakową wagę w podsumowaniu pokrycia. Operat obejmował wszystkie 31 456 obwodów, w tym obwody odrębne. Przed losowaniem program sprawdził zgodność liczników obwodów z sumą dla każdej listy w każdym okręgu oraz sumę krajową 14 417 065 ważnych głosów. [Pliki KBW](https://danewyborcze.kbw.gov.pl/indexbea2.html) · [Obwieszczenie PKW](https://eli.gov.pl/eli/DU/2024/543/ogl)

Jedna replikacja obejmowała wszystkie okręgi, 382 warstwy wyznaczone przez powiat w obrębie okręgu i 706 par lista–okręg. W każdej warstwie losowano obwody bez zwracania, z jednakową szansą. Dobór po cztery obwody dawał 1 528 punktów łącznie. Losowa podpróba po dwa obwody dawała 764 punkty. Wykonano 300 niezależnych replikacji. W każdym scenariuszu daje to 25 500 symulowanych badań okręgowych i 211 800 prób wyznaczenia przedziału. Granice obliczał ten sam kod PHP, który obsługuje prywatny raport w LimeSurvey. Porównanie z wynikiem PKW odbywało się przed zaokrągleniem granic.

| Scenariusz | Wyznaczone | Obejmujące wynik PKW | Pokrycie wśród wyznaczonych | Błąd standardowy Monte Carlo (p.p.) | Wyznaczone i trafne wśród wszystkich prób | Średnia szerokość (p.p.) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 4 obwody, wszystkie ważne głosy w wybranych obwodach | 198 890 | 183 087 | 92,05% | 0,070 | 86,44% | 4,82 |
| 4 obwody, co piąta osoba, pełna odpowiedź | 106 503 | 99 415 | 93,34% | 0,080 | 46,94% | 5,77 |
| 4 obwody, co piąta osoba, odpowiedź zależna od wyboru | 83 388 | 66 506 | 79,75% | 0,137 | 31,40% | 6,42 |
| 2 obwody, co piąta osoba, pełna odpowiedź | 98 303 | 91 672 | 93,25% | 0,087 | 43,28% | 10,35 |

Pierwszy scenariusz wykorzystuje pełne wyniki wylosowanych obwodów i izoluje wpływ doboru samych obwodów. W pozostałych scenariuszach oficjalne liczniki odtwarzają pulę ważnych głosów, której kolejność w każdym wylosowanym obwodzie jest losowo permutowana. Strumień dzieli się na dwie zmiany o możliwie równej liczebności. Na każdej zmianie losuje się start od 1 do 5 i następnie zaprasza co piątą osobę. Porównywane scenariusze korzystają z tych samych punktów i tych samych modelowanych wyjść. W scenariuszu nierównej odpowiedzi prawdopodobieństwo odpowiedzi wynosi 60% dla listy o najwyższym wyniku w danym okręgu i 85% dla pozostałych. Parametry te służą do sprawdzenia wrażliwości.

PKW dostarcza wyniki obwodowe. Kolejność wyjść, podział na zmiany i odmowy są symulowane. Badanie obejmuje populację ważnych głosów z protokołów, również z małych lokali. W rzeczywistym terenie dostęp do części wyborców może być ograniczony. W eksperymencie każdy uczestnik, który odpowiedział, ujawnił swój wybór zgodnie z zapisanym głosem.

## Dostępność przedziałów

Liczby poniżej dotyczą par lista–okręg w kolejnych replikacjach. Pusta zmiana lub próg prywatności wyłącza raport całego okręgu w danej replikacji. Jedna odpowiedź w niepełnej zmianie pozostawia szacunek punktowy, ale uniemożliwia oszacowanie zmienności w tej zmianie. Skrajny udział może uniemożliwić wyznaczenie przedziału dla pojedynczej listy.

| Przyczyna braku przedziału | 4 obwody, pełne protokoły | 4 obwody, co piąta osoba | 4 obwody, różne odmowy | 2 obwody, co piąta osoba |
| --- | ---: | ---: | ---: | ---: |
| Co najmniej jedna zmiana bez ukończonego wywiadu | 5 466 | 32 804 | 55 772 | 17 022 |
| Progi prywatności raportu | 7 428 | 31 825 | 35 098 | 77 716 |
| Tylko jedna odpowiedź w częściowo zbadanej zmianie | 0 | 40 451 | 37 318 | 18 289 |
| Udział próbny równy 0% lub 100% | 16 | 217 | 224 | 470 |
| **Łącznie niedostępne** | **12 910** | **105 297** | **128 412** | **113 497** |

W przypadku pełnych protokołów do odtworzenia dwóch zmian ważne głosy przydzielono naprzemiennie. W obwodzie z najwyżej jednym ważnym głosem co najmniej jedna zmiana pozostaje pusta. W przypadku kroku pięć pusta zmiana może powstać także wtedy, gdy wylosowany start przekracza liczbę wychodzących. Zachowanie zasad prywatności i kompletności w trakcie symulacji powoduje, że wynik pokrycia wśród dostępnych przedziałów opisuje wyselekcjonowaną część prób.

## Wpływ odmów i wielkości próby

Przy pełnej odpowiedzi i czterech obwodach na warstwę pokrycie wśród wyznaczonych przedziałów wyniosło **93,67%** dla list poniżej 5% rzeczywistego poparcia w okręgu i **93,12%** dla pozostałych. Średni błąd bezwzględny oszacowania wśród prób z dostępnym przedziałem wyniósł **1,09 p.p.** Przy dwóch obwodach na warstwę wzrósł do **1,51 p.p.**, a przeciętny przedział poszerzył się z 5,77 do 10,35 p.p.

Po wprowadzeniu różnic w odpowiedzi pokrycie dla list poniżej 5% wyniosło **90,63%**, a dla list z wynikiem co najmniej 5% spadło do **72,24%**. Dla listy prowadzącej w danym okręgu odchylenie oszacowania od wyniku PKW wyniosło przeciętnie **−7,59 p.p.**, średni błąd bezwzględny **7,61 p.p.**, a przedział objął wynik w **3 327 z 10 358 przypadków (32,12%)**. Korekta wag oparta na łącznej liczbie odmów w obrębie zmiany nie usuwa w tym scenariuszu błędu zależnego od preferencji.

We wszystkich czterech scenariuszach obserwowane pokrycie było niższe od nominalnych 95%. Błąd standardowy Monte Carlo w tabeli opisuje zmienność częstości wynikającą z liczby replikacji. Dla każdej pełnej replikacji liczone są trafienia H i liczba dostępnych przedziałów I. Dla łącznego pokrycia p = suma(H) / suma(I) błąd standardowy w punktach procentowych wynosi 100 × odch.std.(H − p × I) / (√300 × średnia(I)). Jednostką powtórzenia jest cały zestaw okręgów, co zachowuje współzależność wyników list z tej samej próby. Przedziały na poszczególne listy mają charakter marginalny. Wynik walidacji dotyczy jednej elekcji, przy zadanych scenariuszach pomiaru.

## Odtworzenie

W repozytorium wtyczki polecenie poniżej odtwarza pełne podsumowanie, wyniki dla grup list oraz dla każdego okręgu. Wymaga PHP 8.2 lub nowszego oraz lokalnego pakietu danych sejmikowych 2024. Ziarno główne to `LimeControl-PKW-2024-coverage-v1`. Generator Xoshiro256StarStar otrzymuje osobne ziarna z SHA-256 dla okręgu, replikacji i etapu symulacji. Program sprawdza sumy kontrolne danych. Dwa pełne przebiegi na PHP 8.3.28 dały identyczny plik JSON.

```sh
php scripts/coverage-2024.php > /tmp/lcep-coverage-2024.json
cmp /tmp/lcep-coverage-2024.json scripts/coverage-2024.json
```
