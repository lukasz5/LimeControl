# Jak odmowy mogą zmienić wynik exit poll

Liczba odmów mówi, ile zaproszeń zakończyło się bez wywiadu. Nie ujawnia, na kogo te osoby głosowały. W tabeli **Wrażliwość na odmowy udziału** pracownia może sprawdzić, jakie znaczenie dla wyniku miałaby założona różnica w preferencjach. Tabela dotyczy całego zamrożonego exit poll i jest dostępna przy uprawnieniach do odczytu wyniku. Podstawą są zbiorcze paczki z obwodów i zmian. [AAPOR, *Standard Definitions*](https://aapor.org/standards-and-ethics/standard-definitions/)

## Czytanie wiersza

W jednym wierszu porównujemy daną opcję ze wszystkimi pozostałymi ważnymi wyborami. Jeżeli jej udział wynosi 40%, szansa wynosi 40/60. Mnożnik 2 oznacza dwukrotność tej **szansy**, czyli udział 80/(60 + 80) = 57,14% w modelowanej części głosów. Zmianę stosujemy wyłącznie do ważnych wskazań przypisanych osobom, które odmówiły udziału. Pozostała część wyniku zachowuje pierwotne wagi.

Przykładowo, gdy zgadza się 80% zaproszonych, wszyscy odpowiadający podają ważne wskazanie, a dana opcja ma w każdej zmianie 40%, otrzymamy następujący wiersz.

| Mnożnik szansy wśród odmawiających | Założony udział opcji w ważnych wskazaniach odmawiających | Udział w całym exit poll w tym scenariuszu |
| ---: | ---: | ---: |
| 0,25 | 14,29% | 34,86% |
| 0,5 | 25,00% | 37,00% |
| 1 | 40,00% | 40,00% |
| 2 | 57,14% | 43,43% |
| 4 | 72,73% | 46,55% |

Wariant 1 odtwarza bazowy wynik exit poll. W pozostałych kolumnach każdy wiersz opisuje osobny scenariusz dla jednej opcji. Udziałów z różnych scenariuszy nie sumuje się do 100%. Rozpiętość wyników zależy od przyjętych mnożników. Poziom 95% odnosi się do przedziału ufności wyliczonego dla bazowego wyniku.

## Rachunek dla agregatów z terenu

Dla każdej zmiany oznaczmy przez `m` liczbę ukończonych wywiadów, przez `V` sumę ważnych wskazań, przez `vⱼ` wskazania na opcję j, przez `R` odmowy udziału, a przez `S` wszystkie osoby wskazane przez krok (zaproszone i pominięte). Waga `w = (N/n) × k` uwzględnia dobór obwodu w warstwie i zapisany dla tego obwodu krok doboru osób.

- `D = Σ w S V/m` to ważona liczba ważnych wskazań w bazowym oszacowaniu.
- `B = Σ w R V/m` to część tej sumy przypisywana odmawiającym. Udział ważnych wskazań u odmawiających przyjmujemy taki jak u odpowiadających w tej samej zmianie.
- `qⱼ = (Σ w R vⱼ/m) / B` to bazowy udział opcji w modelowanej grupie odmawiających. Obwody i zmiany, w których było więcej odmów, odpowiednio wpływają na tę bazę.
- Przy mnożniku szans `θ` zakładany udział opcji w tej grupie to `q' = θ qⱼ / (1 − qⱼ + θ qⱼ)`. Jeżeli bazowy udział opcji w całym badaniu to `pⱼ`, scenariusz daje `p' = pⱼ + (B/D) × (q' − qⱼ)`. Wzory używają udziałów od 0 do 1. Gdy odmów udziału nie odnotowano, ta składowa nie zmienia oszacowania.

Zmianie podlegają wyłącznie preferencje przypisane osobom, które odmówiły wywiadu. Osoby pominięte, odmowa ujawnienia wyboru po rozpoczęciu wywiadu, deklaracja głosu nieważnego i brak danej karty zachowują znaczenie z bazowego estymatora. Tabela nie wyznacza nieznanej skali selekcji. Wiarygodność mnożników pracownia może oceniać na podstawie pilotażu i porównań ze zweryfikowanymi protokołami tych samych obwodów. Takie przesuwanie założonych proporcji na skali logitu jest zastosowaniem analizy wrażliwości na brak danych zależny od wyniku. [National Research Council, *Principles and Methods of Sensitivity Analyses*](https://www.nationalacademies.org/read/12955/chapter/7)

Weryfikacja historyczna bada, jak często **bazowy przedział ufności** obejmuje wynik PKW. W scenariuszu, w którym odpowiada 60% wyborców lidera i 85% pozostałych wyborców, iloraz szans głosu na lidera u odmawiających względem odpowiadających wynosi w jednorodnej grupie około 3,78. Kolumna 4 × pokazuje podobną skalę selekcji. Wynik dla całego badania zależy również od struktury obwodów i zmian. [Porównanie liczby obwodów i kroku w dwóch elekcjach](design-2018-2024.md)
