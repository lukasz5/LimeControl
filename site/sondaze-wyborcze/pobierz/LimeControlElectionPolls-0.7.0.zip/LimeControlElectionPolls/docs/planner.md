# Planer kampanii

Po zalogowaniu wybierz **Planery kampanii** w menu administracyjnym LimeSurvey, a następnie nazwę projektu. W klasycznym widoku pierwszej ankiety możesz też użyć **Narzędzia → Planer kampanii**. Jeśli dopiero zakładasz projekt, połącz ankiety i ustaw daty wywiadów w zakładce **Ustawienia fal**. W istniejącym projekcie planer od razu pokazuje obie fale oraz zapisane wcześniej wydarzenia.

## Od wydarzenia do rozliczenia

1. Wybierz **Dodaj wydarzenie**. Podaj nazwę, daty rozpoczęcia i zakończenia, obszar, źródło informacji i status. Możesz od razu wpisać osobę odpowiedzialną oraz planowany koszt, np. 1200,10 zł za wynajem sali. W polu kwoty wpisz `1200,10`.
2. Wybierz **Dodaj zadanie**, wpisz nazwę, osobę odpowiedzialną i termin. Przypisz zadanie do wydarzenia, jednej z fal lub całej kampanii. Na przykład przygotowanie materiałów może należeć do debaty i mieć termin na dzień przed nią. Przygotowanie kwestionariusza może być powiązane z drugą falą, nawet gdy termin zadania przypada między falami.
3. W **Kalendarzu miesięcznym** wybierz dzień z wpisem, aby przejść do jego szczegółów. Obie fale oraz wielodniowe wydarzenia zajmują wszystkie dni od rozpoczęcia do zakończenia włącznie. **Lista terminów** pokazuje cały projekt w kolejności dat. Zmiana dat w ustawieniach fal aktualizuje kalendarz i położenie wpisów względem wywiadów.
4. Po realizacji edytuj istniejący wpis. Przy wydarzeniu zaznacz **Odbyło się**, a przy zadaniu **Zakończone**. Rzeczywisty koszt możesz uzupełnić, kiedy poznasz kwotę. Edycja wydarzenia aktualizuje również wydarzenie na osi czasu raportu badawczego.

## Jak liczyć budżet

Przy wydarzeniu zapisuj jego bezpośrednie koszty. Wydatki przypisane do zadań wpisuj tylko przy tych zadaniach. Powiązanie zadania z wydarzeniem wskazuje, czego dotyczył wydatek. W podsumowaniu każda pozycja liczy się raz.

| Pozycja | Koszt planowany | Koszt rzeczywisty |
| --- | ---: | ---: |
| Debata – wynajem sali | 1 200,10 zł | 1 300,05 zł |
| Zadanie – przygotowanie materiałów | 250,25 zł | 350,10 zł |
| **Razem** | **1 450,35 zł** | **1 650,15 zł** |

W tym przykładzie wydano **199,80 zł ponad plan**. Pole puste oznacza kwotę jeszcze nieustaloną, a `0` oznacza potwierdzony brak kosztu. Jeśli brakuje kwot, budżet pokazuje sumy znanych wartości i liczbę braków. Łączna różnica między wykonaniem a planem pojawia się po uzupełnieniu obu kwot we wszystkich pozycjach. Wydarzenia przeniesione z wcześniejszej wersji mają początkowo puste pola kosztów.

## Dostęp osób z komitetu

Administrator nadaje osobie z komitetu prawo odczytu ankiety w każdej z dwóch fal projektu. W uprawnieniach globalnych LimeSurvey wybiera **Planer kampanii wyborczej** i zaznacza odczyt. Do dodawania i zmieniania wpisów potrzebna jest także aktualizacja. Taki zestaw uprawnień daje dostęp do kalendarza, osób odpowiedzialnych i budżetu bez udostępniania odpowiedzi ankietowych ani eksportu wyników.

W polu osoby odpowiedzialnej można podać imię i nazwisko lub nazwę zespołu. Dostęp do projektu administrator nadaje osobno w LimeSurvey. Osoby z dotychczasowymi uprawnieniami badawczymi zachowują odpowiedni odczyt lub edycję w planerze. Jeżeli dwie osoby zmienią projekt równocześnie, druga otrzyma komunikat o zmianie wersji i może wczytać aktualny planer przed ponowieniem edycji.
