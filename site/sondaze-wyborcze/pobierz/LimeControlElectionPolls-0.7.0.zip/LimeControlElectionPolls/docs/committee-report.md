# Raport dla komitetu

W menu administracyjnym wybierz **Planery kampanii**, otwórz projekt, a następnie **Raport dla komitetu**. Konto z dostępem wyłącznie do raportu przechodzi do niego bezpośrednio po wybraniu projektu. Na początku tabela opisuje cały obszar badania.

## Przygotowanie dwóch fal

1. W każdej anonimowej ankiecie przygotuj zamknięte pytanie jednokrotnego wyboru o obszar, np. „W którym powiecie Pani lub Pan mieszka?”. Obie ankiety powinny mieć taki sam język, treść pytania oraz kody i etykiety opcji. Każda opcja terytorialna powinna odpowiadać rzeczywistej jednostce na tym samym poziomie i mieścić się w obszarze projektu.
2. Pole kodu odpowiedzi LimeSurvey mieści pięć znaków. Dla województwa i powiatu można wpisać kod bez dwukropka, np. `W22`, `P2204` (powiat gdański) albo `P2205` (powiat kartuski). Dla gminy użyj krótkiego kodu, np. `A01`, i umieść pełny identyfikator na początku etykiety odpowiedzi, np. `G:220404 · gm. Pruszcz Gdański`. Dla dzielnicy Warszawy użyj np. `A01` z etykietą `B:146502 · Bemowo`. Zachowaj te same przypisania w obu ankietach. Kod `REF` oznacza odmowę podania obszaru, a `DK` odpowiedź „nie wiem”.
3. W **Ustawieniach fal** wpisz kod pytania o obszar osobno dla każdej ankiety. W przykładowych formularzach dostarczonych z wtyczką jest to `AREA` w obu falach, a pytanie o listę ma kod `VOTE`. Pytanie na poziomie gminy pozwala zestawiać również wyniki powiatów i województw. Jeżeli zapisano tylko powiat, dostępne są obliczenia dla powiatu i jego jednostek nadrzędnych.
4. W raporcie wpisz nazwę lub kod, wybierz jednostki z podpowiedzi i kliknij **Porównaj obszary**. Można zestawić od jednego do czterech rozłącznych obszarów. Powiat i należącą do niego gminę można obejrzeć w osobnych widokach. Wyczyszczenie wszystkich pól przywraca cały projekt. W projektach bez pytania o obszar nadal można porównywać terytorialne koszty i wydarzenia oraz odczytać poparcie dla całego projektu.

Słownik korzysta z geografii PKW 2024. Dla jednostki projektu istniejącej wyłącznie w starszych danych wybiera najnowszy dostępny rocznik zawierający tę jednostkę. Źródłem poparcia są ukończone wywiady w dwóch falach badania.

## Odczyt tabeli

Przykład na danych fikcyjnych. W każdym powiecie w każdej fali ukończono 40 wywiadów, w tym 25 osób wskazało listę. W kolumnie zmiany druga fala jest punktem końcowym.

| Obszar | Lista A w fali 1 | Lista A w fali 2 | Zmiana | Koszt planowany | Koszt rzeczywisty |
| --- | ---: | ---: | ---: | ---: | ---: |
| Powiat gdański | 5 z 25 · 20% | 20 z 25 · 80% | +60 p.p. | 1 450,35 zł | 1 650,15 zł |
| Powiat kartuski | 15 z 25 · 60% | 10 z 25 · 40% | −20 p.p. | 90,16 zł | Brak kwoty |

W tym przykładzie dodatkowe działanie wojewódzkie kosztowało 740,15 zł przy planie 700,13 zł. Raport pokazuje ten wydatek raz we wspólnej części pod tabelą.

Obok poparcia zobaczysz liczbę ukończonych wywiadów, liczbę zdecydowanych i koszty działań dla każdej jednostki. Wynik całego projektu w przykładzie zmienił się z 40% do 60%. Rozbicie według powiatu ujawnia, że zmiany miały przeciwne kierunki. Daty działań pozwalają ustalić, z którą falą się pokrywały. Wniosek o wpływie konkretnego wydarzenia lub wydatku na poparcie wymaga osobnego badania.

Raport stosuje reguły i wagi tego samego badania co raport pracowni. Mianownikiem udziału listy są zdecydowani, a liczebności w tabeli to liczby wywiadów. Po zadeklarowaniu dwóch niezależnych prostych prób losowych bez wag tabela pokazuje także przybliżony 95% przedział ufności dla zmiany. W trybie opisowym rozkład dotyczy zebranych odpowiedzi.

Wynik fali dla jednostki wymaga co najmniej 30 ukończonych wywiadów oraz co najmniej pięciu odpowiedzi w każdej niepustej kategorii pytania o wybór. Raport ukrywa też przekroje, których odjęcie od wyniku obszaru nadrzędnego pozwoliłoby odtworzyć małą grupę. Reguła działa również przy otwieraniu obszarów po kolei. Jeśli wynik którejś fali jest ukryty lub niedostępny, zmiana pozostaje niedostępna. Wywiad bez rozpoznanego kodu obszaru wchodzi do wyniku całego projektu.

## Koszty i okres porównania

- Okres zaczyna się pierwszego dnia fali 1 i kończy ostatniego dnia fali 2. Obejmuje również przerwę między falami. Liczy się czas trwania wydarzenia lub termin zadania. Kwoty opisują działania przypadające w tym okresie. Planer przechowuje również pozycje spoza niego.
- Przy wydarzeniu uwzględniany jest jego koszt bezpośredni. Zadanie powiązane z wydarzeniem dziedziczy jego obszar i ma własny termin oraz osobną kwotę. Dla wydarzenia na granicy okresu raport zachowuje pełną wpisaną kwotę. Plan i wykonanie są podane w złotych, puste pole wskazuje kwotę jeszcze nieznaną, a zero oznacza potwierdzony brak kosztu.
- Przy porównaniu dwóch powiatów wydarzenie wojewódzkie trafia raz do **Działań wspólnych**. Tak samo rozliczane są zadania dotyczące całego projektu lub fali. Zmiana wyboru obszarów nie dzieli faktury na części. Status przy wpisie pozwala odróżnić działania planowane od zrealizowanych.

## Dostęp

Administrator zaznacza globalne uprawnienie odczytu **Raport dla komitetu** i nadaje odczyt ankiety w obu falach. Takie konto może porównywać zagregowane wyniki i działania bez dostępu do odpowiedzi pojedynczych osób, eksportu badawczego czy edycji budżetu. Do edycji planera służy osobne uprawnienie **Planer kampanii wyborczej**. Osoby z badawczym odczytem odpowiedzi obu fal mogą otworzyć raport w swoim dotychczasowym panelu.
