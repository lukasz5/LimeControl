# Skąd pochodzi wielkość obwodu

Dla wyborów samorządowych 2018 r. przyjęliśmy liczbę wyborców w obwodzie z wykazu do wyborów parlamentarnych 2015 r. Dla wyborów samorządowych 2024 r. źródłem jest analogiczny wykaz z wyborów parlamentarnych 2023 r. W obu przypadkach zmienna pochodzi z kolumny **Wyborcy** z wcześniejszej elekcji. Miara opisuje wcześniejszy cykl wyborczy. W metadanych arkusza z 2015 r. figurują data utworzenia 15 października 2015 r. i ostatniej modyfikacji 14 grudnia 2022 r., dlatego identyczności archiwalnej rewizji z wersją dostępną w 2018 r. nie dało się potwierdzić. Plik z wykazem 2023 ma w ZIP datę 18 października 2023 r. [KBW, wykaz 2015](https://danewyborcze.kbw.gov.pl/dane/2015/obwody2015parl.xlsx) · [KBW, wykaz 2023](https://danewyborcze.kbw.gov.pl/dane/2023/sejmsenat/obwody_glosowania_csv.zip)

Wykazy z roku badanego głosowania służą do identyfikacji punktów. Odczytujemy z nich TERYT gminy lub dzielnicy, numer, typ obwodu i adres lokalu. Liczby mieszkańców, wyborców, wydanych kart i głosów z badanego głosowania nie wchodzą do miary wielkości. Przed importem sprawdzamy zgodność zbioru identyfikatorów z pełnym operatem w archiwum sejmikowym. [Wykaz 2018](https://danewyborcze.kbw.gov.pl/dane/2018/samorzad/obwody_glosowania.zip) · [Wykaz 2024](https://danewyborcze.kbw.gov.pl/dane/2024/samorzad/obwody_glosowania_csv.zip)

## Jak przypisujemy wielkość

1. Z wcześniejszego wykazu bierzemy dodatnią liczbę wyborców, jeżeli zgadzają się TERYT, numer, typ i adres obwodu. Porównanie adresu obejmuje miejscowość, ulicę i numer posesji po ujednoliceniu wielkości liter, znaków interpunkcyjnych i odstępów. Wymagamy miejscowości i numeru posesji. Zmiana granic między elekcjami może wpłynąć na wielkość obwodu mimo zachowania jego numeru i lokalu.
2. Przy nowym obwodzie, rozbieżności identyfikacyjnej albo nieprzydatnej wielkości historycznej przyjmujemy **dolną medianę** spośród wcześniejszych obwodów tego samego typu. Szukamy kolejno w gminie (w Warszawie w dzielnicy), powiecie, województwie i kraju. Typy obwodów są szczegółowe, np. szpital i dom pomocy społecznej mają własne grupy. Przy parzystej liczbie obserwacji wybieramy niższą ze środkowych wartości.
3. Przed wyznaczeniem median pomijamy zagranicę, statki, brakujące i zerowe liczebności. W obwodach stałych historyczny wpis uznajemy za skrajnie niespójny, gdy liczba wyborców przewyższa 5 000 i jest ponad trzykrotnie większa od dodatniej liczby mieszkańców w tym samym wcześniejszym wykazie. Takie kryterium spełnił jeden obwód. Dla obwodu nr 2 w gminie Bytom Odrzański wykaz z 2015 r. podaje 22 113 wyborców i 2 818 mieszkańców. Zastosowaliśmy medianę dla obwodów tego samego typu.
4. Formularz historycznej karty sejmiku lub włodarza wpisuje wielkości dla wszystkich obwodów danej karty. Dla kart rad, gdzie jeden obwód może obsługiwać kilka okręgów, koordynator podaje operat odpowiadający lokalnemu sposobowi zapraszania. W projekcie terenowym można wpisać własne wielkości i źródło dla całego operatu.

| Sposób przypisania | Samorząd 2018 | Samorząd 2024 |
| --- | ---: | ---: |
| Zgodny identyfikator, typ i adres, prawidłowa wielkość | 17 155 | 29 705 |
| Mediana w gminie lub dzielnicy Warszawy | 9 694 | 1 723 |
| Mediana w powiecie | 34 | 21 |
| Mediana w województwie | 94 | 6 |
| Mediana w kraju | 6 | 1 |
| Razem | 26 983 | 31 456 |

W wykazie krajowych obwodów z 2015 r. 26 liczebności było pustych i 78 zerowych. W wykazie z 2023 r. wszystkie krajowe obwody miały dodatnią liczebność. Każdy obwód w obu operatach docelowych otrzymał dodatnią miarę. Na 2018 r. wielkości dla obwodów stałych wyniosły od 31 do 2 535 wyborców, a na 2024 r. od 40 do 4 102. Dla obwodów w zakładach leczniczych zakresy wyniosły odpowiednio 20–894 i 3–712. Liczba uprawnionych w wyborach parlamentarnych może słabo przybliżać rzeczywisty ruch w wyborach samorządowych, szczególnie w obwodach odrębnych. Ta różnica pozostaje częścią porównania planów.

## Odtworzenie operatu

W repozytorium wtyczki polecenie poniżej odtwarza oba roczniki z czterech plików źródłowych pobranych z KBW. Import sprawdza SHA-256 każdego pliku. Nazwy lokalne można zmienić w argumentach polecenia. Zestawienie zawierające adresy źródeł, sumy kontrolne, liczby dopasowań i powody zastąpienia liczebności medianą zapisano w pliku `data/frame-size/manifest.json` wewnątrz wtyczki.

```sh
python3 -B scripts/import-exit-frame-sizes.py \
  --file-2015 obwody2015parl.xlsx \
  --file-2018 obwody_glosowania.zip \
  --file-2023 obwody_2023.zip \
  --file-2024 obwody_2024.zip \
  --output /tmp/lcep-frame-rebuild
```
