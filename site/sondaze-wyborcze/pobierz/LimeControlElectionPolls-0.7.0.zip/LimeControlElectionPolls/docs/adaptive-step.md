# Krok doboru zależny od wielkości obwodu

Przy czterech obwodach na warstwę i kroku odniesienia 10 obie reguły zmiennego kroku dały więcej przedziałów przy podobnej liczbie wywiadów. W dodatkowej serii 2024 odsetek wyników z wyznaczonym przedziałem wzrósł z 17,98% do 29,45% przy regule dla małych obwodów i do 48,53% przy pełnej proporcjonalności. Pokrycie tych przedziałów wyniosło odpowiednio 93,92% i 93,60%. Przyjęte przed analizą pasmo 94–96% nie potwierdziło się dla obu lat łącznie według oszacowań punktowych.

## Jak ustawić badanie

W formularzu **Dobór i zmiany** wybierz regułę kroku, liczbę obwodów na warstwę i krok odniesienia. Przy zmiennym kroku wpisz w sekcji **Wielkości obwodów** po jednym wierszu `kod;liczba` dla każdego obwodu. Podaj też datę i źródło miary znanej przed rozpoczęciem badania. Jeżeli dwa obwody mają odpowiednio 100 i 900 wyborców, jeden wiersz będzie miał postać `P1;100`, a drugi `P2;900`. Przy obu obwodach wybranych do badania i kroku odniesienia 5 wtyczka rozdzieli nakład na częstsze zaproszenia w mniejszym lokalu i rzadsze w większym.

Ankieter znajdzie przy swoim obwodzie krok obowiązujący na obu zmianach i osobny numer pierwszej osoby na każdej zmianie. Po odmowie wciąż odlicza ten sam krok. Szacunek, przedział i scenariusze odmów wykorzystują faktycznie zaplanowany krok tego obwodu. Przy zastąpieniu obwodu protokołem late poll waga protokołu zależy wyłącznie od szansy wylosowania obwodu. W projektach zapisanych w wersji 0.4 lub wcześniejszej wtyczka odczytuje dawny wspólny krok.

## Jak działa przydział

Każdy obwód ma wielkość planistyczną `sᵢ` i szansę wylosowania `πᵢ = nₕ/Nₕ` w swojej warstwie. Dla stałego kroku odniesienia `k` nakład liczony w jednostkach miary planistycznej wynosi `Σ πᵢ sᵢ/k`. Wtyczka dobiera lokalne kroki całkowite od 1 do 1000 tak, aby `Σ πᵢ sᵢ/kᵢ` było jak najbliżej tej wartości w ramach wybranej reguły. Równe wielkości dostają ten sam krok. Przy jednakowej bezwzględnej różnicy wygrywa mniejszy nakład. Faktyczna liczba zebranych wywiadów zależy od frekwencji, ruchu na zmianach i odmów.

- **Krok proporcjonalny do wielkości obwodu** stosuje `kᵢ = zaokrąglij(c × sᵢ)` z ograniczeniem do przedziału 1–1000. Dąży do zbliżonej liczby zaproszeń na obwód, gdy frekwencja jest proporcjonalna do wielkości.
- **Mniejszy krok w małych obwodach** w tej samej regule zaokrąglania używa `min(sᵢ, próg)`, gdzie próg wynosi ¼ średniej wielkości obwodu ważonej prawdopodobieństwem wylosowania. Powyżej progu krok jest wspólny. Przy obliczaniu nakładu wciąż uwzględniamy pełną wielkość każdego obwodu.

Stałą `c` wyznaczamy na całym operacie przed losowaniem punktów. Każdy wylosowany obwód zachowuje własny krok przez cały czas badania. Wielkość zero wymaga wyraźnego wpisu i prowadzi do kroku 1. Brak liczby wymaga uzupełnienia operatu. [Pochodzenie miar wielkości z PKW](exit-frame-sizes.md)

## Kryteria porównania

Przed obliczeniami przyjęliśmy trzy plany odniesienia. W pierwszym losujemy cztery obwody w każdej warstwie i zapraszamy co dziesiątą osobę. Kolejne dwa plany zapraszają co piątą osobę, przy czterech albo ośmiu obwodach na warstwę. Jedna warstwa odpowiada powiatowi lub jego części w granicach okręgu sejmikowego. Każdy plan ze zmiennym krokiem porównujemy z odpowiadającym mu planem stałym na tych samych losowaniach.

Badamy dwie reguły. Pierwsza wykorzystuje pełne zróżnicowanie wielkości obwodów. Druga zmniejsza krok przede wszystkim w małych obwodach, w których cała zmiana może mieć tylko kilku wychodzących. W obu przypadkach całkowita planowana liczba zaproszeń wynika z tego samego kroku odniesienia.

Za podobny nakład przyjmujemy średnią liczbę **ukończonych wywiadów** w granicach ±5% planu stałego. Przez pokrycie bliskie nominalnym 95% rozumiemy przedział od 94% do 96% wśród wyznaczonych przedziałów. Osobno podajemy dostępność oraz odsetek wszystkich zaplanowanych wyników list w okręgach, dla których przedział wyznaczono i objął on wynik PKW. To rozróżnienie ma znaczenie, gdy część zmian ma za mało odpowiedzi.

W podstawowym porównaniu prawdopodobieństwo odpowiedzi wynosi 80% dla każdej osoby. W pierwszej kolejności oceniamy plan czterech obwodów i kroku odniesienia 10. Dla każdego planu wybieramy na danych z 2018 r. regułę spełniającą progi nakładu i pokrycia oraz dającą dodatnie zmiany dostępności i odsetka wyznaczonych i trafnych. Jeśli obie spełniają kryteria, wybieramy większy wzrost ostatniej miary. Weryfikujemy ten sam wariant w 2024 r. i pokazujemy również wyniki obu reguł. Wariant z odpowiedzią 60% u wyborców lidera i 85% u pozostałych sprawdza wrażliwość wniosku na selektywne odmowy.

## Wyniki głównego porównania

Każdy wiersz poniżej obejmuje 100 powtórzeń dla każdego z 85 okręgów sejmikowych w każdym roku. Losowano bez zwracania identyczne obwody dla porównywanych reguł. W każdym obwodzie losowo mieszano ważne głosy i dzielono je na dwie zmiany. Gdy reguły zapraszały tę samą osobę, dzieliły także jej wylosowaną skłonność do odpowiedzi. Przedziały obliczał standardowy estymator wtyczki, łącznie z kontrolami kompletności i poufności. Każda para lista–okręg waży tyle samo. PKW dostarcza wyniku do sprawdzenia trafienia. Kolejność wychodzących i odpowiedzi są symulowane. [Archiwum KBW 2018](https://danewyborcze.kbw.gov.pl/indexd795.html) · [Archiwum KBW 2024](https://danewyborcze.kbw.gov.pl/indexbea2.html)

| Obwody na warstwę / krok odniesienia | Reguła | Dostępność 2018 | Pokrycie 2018 | Dostępność 2024 | Pokrycie 2024 | Wyznaczono i objął wynik 2024 | Wywiady / okręg 2024 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 4 / 10 | Stały | 18,73% | 94,56% | 18,08% | 94,24% | 17,04% | 629 |
| 4 / 10 | Proporcjonalny | 47,94% | 94,19% | 48,75% | 93,58% | 45,62% | 628 |
| 4 / 10 | Mniejsze obwody | 31,14% | 94,38% | 29,48% | 93,99% | 27,71% | 633 |
| 4 / 5 | Stały | 42,04% | 93,70% | 40,12% | 93,68% | 37,58% | 1 258 |
| 4 / 5 | Proporcjonalny | 71,90% | 93,44% | 74,16% | 93,06% | 69,01% | 1 264 |
| 4 / 5 | Mniejsze obwody | 61,60% | 93,65% | 62,72% | 93,73% | 58,78% | 1 264 |
| 8 / 5 | Stały | 30,76% | 94,08% | 25,87% | 93,97% | 24,30% | 2 513 |
| 8 / 5 | Proporcjonalny | 77,92% | 94,03% | 73,51% | 93,74% | 68,91% | 2 527 |
| 8 / 5 | Mniejsze obwody | 59,16% | 93,92% | 56,45% | 94,00% | 53,06% | 2 526 |

Według ustalonej reguły wyboru dane z 2018 r. wskazały krok proporcjonalny w planach 4/10 oraz 8/5. W głównym planie 4/10 w 2018 r. dostępność wzrosła o 29,21 p.p., a odsetek wyznaczonych i trafnych o 27,45 p.p. W roku 2024 wzrost wyniósł odpowiednio 30,67 i 28,58 p.p. Błędy standardowe Monte Carlo tych dwóch sparowanych różnic wyniosły 0,52 i 0,49 p.p. Pokrycie w 2024 r. wyniosło 93,576%, przy 94,242% planu stałego. Różnica to −0,666 p.p., a jej błąd standardowy Monte Carlo 0,252 p.p. Średnia szerokość wyznaczonego przedziału wyniosła odpowiednio 7,21 i 7,42 p.p.

Dla kroku zmniejszanego głównie w małych obwodach główne porównanie w 2024 r. dało 93,9936% pokrycia (błąd Monte Carlo 0,166 p.p.). W planie 8/5 wynik tej reguły wyniósł 93,9981%. Oba oszacowania znajdowały się niecałe 0,01 p.p. poniżej granicy przyjętego pasma. Selekcję wykonano na wartościach przed zaokrągleniem. Żaden z sześciu wariantów adaptacyjnych nie osiągnął w 2024 r. wszystkich punktowych kryteriów tej pierwszej serii. Dla 4/5 już w 2018 r. żadna reguła nie spełniła kryterium pokrycia.

Na całej siatce rozkład wyników odmów zależnych od preferencji odbiegał od scenariusza z równą odpowiedzią. W 2024 r. przy 4/10 i pełnej proporcjonalności pokrycie spadło z 93,58% do 81,96%, a wśród list prowadzących w okręgu wyniosło 39,40%. [Jak czytać scenariusze odmów](refusal-sensitivity.md)

Zmiana kroku pomogła ograniczyć liczbę pustych zmian. W głównym porównaniu za 2024 r. na 8 500 symulowanych badań okręgowych niekompletnych było 3 303 przy kroku stałym, 457 przy proporcjonalnym i 1 395 przy regule dla małych obwodów. Do puli wyznaczonych przedziałów weszły więc dodatkowe pomiary. Pokrycie warunkowe poszczególnych reguł obejmuje częściowo różne przypadki. Wspólny mianownik dla oceny korzyści daje odsetek wszystkich porównań, w których przedział wyznaczono i objął on wynik PKW.

## Dodatkowe 500 losowań na okręg

W pierwszej serii dwie oceny pokrycia w 2024 r. różniły się od dolnej granicy 94% o mniej niż 0,01 p.p. Dlatego dla głównego planu 4/10 przeprowadziliśmy osobno **500 nowych replik** dla każdego okręgu i roku. Wykorzystaliśmy indeksy losowań 100–599, rozłączne z pierwszą serią 0–99. Zbadaliśmy wszystkie trzy reguły bez zmiany ich parametrów i bez ponownego wyboru na 2018 r. Tę serię wyświetla formularz planowania. Jeden wariant w 2018 r. obejmuje 468 500 porównań lista–okręg, w 2024 r. 353 000.

| Rok | Reguła przy 4 obwodach i kroku odniesienia 10 | Ukończone wywiady na okręg | Wyznaczono przedział | Pokrycie wyznaczonych | Wyznaczono i objął wynik | Błąd Monte Carlo pokrycia (p.p.) |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 2018 | Stały | 777,7 | 18,98% | 94,23% | 17,89% | 0,082 |
| 2018 | Proporcjonalny | 770,2 | 47,62% | 93,89% | 44,70% | 0,055 |
| 2018 | Mniejszy krok w małych obwodach | 781,8 | 31,42% | 94,14% | 29,57% | 0,064 |
| 2024 | Stały | 629,6 | 17,98% | 94,03% | 16,91% | 0,099 |
| 2024 | Proporcjonalny | 628,0 | 48,53% | 93,60% | 45,42% | 0,062 |
| 2024 | Mniejszy krok w małych obwodach | 633,5 | 29,45% | 93,92% | 27,66% | 0,080 |

W 2024 r. krok proporcjonalny zwiększył odsetek wszystkich wyznaczonych i trafnych przedziałów o 28,51 p.p. (sparowany błąd Monte Carlo 0,23 p.p.). Średnia liczba wywiadów na okręg spadła o 0,25%. Pokrycie 93,60% leży około 0,40 p.p. poniżej dolnej granicy 94%. To odchylenie jest ponad sześciokrotnie większe od błędu Monte Carlo dla samego pokrycia. Także w 2018 r. większy sprawdzian dał 93,89% dla reguły wybranej wcześniej na 100 replikach.

Reguła dla małych obwodów zwiększyła w 2024 r. dostępność o 11,47 p.p. i odsetek wyznaczonych i trafnych o 10,75 p.p., przy wzroście liczby wywiadów o 0,61%. Pokrycie wyniosło 94,14% w 2018 i 93,92% w 2024 r. Przybliżony 95% zakres niepewności numerycznej dla tego ostatniego oszacowania wynosi 93,76–94,07%. Próg 94% wypada w tym zakresie. To niepewność oszacowania częstości w symulacji. Zakres nie opisuje błędu przyszłego badania terenowego.

Przy odmowach zależnych od preferencji w dodatkowej serii 2024 pokrycie dla wszystkich list wyniosło 82,06% przy kroku stałym, 81,94% przy proporcjonalnym i 81,67% przy regule dla małych obwodów. Zmiana kroku zwiększyła możliwość obliczenia przedziałów. Systematyczne różnice w odpowiedziach nadal silnie ograniczały ich trafność.

## Odtworzenie badania

W źródłach wtyczki dla PHP 8.2+ i Python 3 poniższe polecenia odtwarzają symulację oraz sprawdzają liczby użyte przez panel. W plikach JSON są również wyniki dla list poniżej 5%, pozostałych list i liderów, rozkłady kroków, powody braku przedziału i błędy standardowe Monte Carlo. Dla różnic między regułami błąd standardowy wyliczono ze sparowanych replik całego kraju. Uwzględnia to współzależność wyników list w tym samym badaniu. Porównanie na dwóch elekcjach dotyczy użytego tu operatu, modelu ruchu i realizacji wywiadów.

```sh
php scripts/adaptive-grid.php 2018 100 > /tmp/exit-adaptive-2018.json
php scripts/adaptive-grid.php 2024 100 > /tmp/exit-adaptive-2024.json
php scripts/adaptive-precision.php 2018 > /tmp/exit-precision-2018.json
php scripts/adaptive-precision.php 2024 > /tmp/exit-precision-2024.json
cmp /tmp/exit-adaptive-2018.json scripts/adaptive-grid-2018.json
cmp /tmp/exit-adaptive-2024.json scripts/adaptive-grid-2024.json
cmp /tmp/exit-precision-2018.json scripts/adaptive-precision-2018.json
cmp /tmp/exit-precision-2024.json scripts/adaptive-precision-2024.json
python3 scripts/check-adaptive.py
```
