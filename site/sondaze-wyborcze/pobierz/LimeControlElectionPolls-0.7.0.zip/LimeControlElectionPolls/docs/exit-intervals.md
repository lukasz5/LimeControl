# Przedział ufności dla udziału opcji w exit poll

Pracownia widzi 95% przedział obok udziału każdej opcji w zamrożonym exit poll. Szacowaną wielkością jest udział w ważnych głosach na daną kartę w populacji objętej operatem. Jeśli badanie pomija określone lokale albo głosujących poza lokalem, wniosek wymaga uwzględnienia tego ograniczenia. Pokrycie oznacza częstość, z jaką procedura zastosowana do kolejnych prób obejmuje znany udział. Dla wyborów z 2024 r. zmierzyliśmy tę częstość osobno dla kilku scenariuszy. [Wyniki symulacji](coverage-2024.md)

## Dane i wagi

Każda warstwa zawiera `N` obwodów, z których wtyczka losuje `n` bez zwracania, z równą szansą. Dla obwodu zapisujemy krok `k`, a dla każdej z dwóch zmian osobno losujemy start od 1 do `k`. Przy zmiennym kroku w poniższych wzorach podstawiamy wartość z danego obwodu. W zmianie liczba wybranych to suma zaproszonych i pominiętych mimo wskazania przez krok. Oznaczmy przez `M = k × liczba wybranych` oszacowaną liczbę osób w strumieniu, a przez `m` liczbę ukończonych ankiet. Jedna ukończona ankieta reprezentuje `M/m` osób w zmianie. Łączna waga obejmuje również czynnik `N/n` dla obwodu. Mianownikiem udziału jest ważona suma ważnych wskazań.

Systematyczny dobór z jednym startem na zmianę nie ujawnia, jakie byłyby odpowiedzi przy innym starcie. Wtyczka dysponuje licznikami zbiorczymi. Do oszacowania zmienności w obrębie zmiany traktuje więc osoby z odpowiedzią jak prostą próbę losową o tej samej liczebności z oszacowanego strumienia. To przybliżenie działa najlepiej przy kolejności wychodzących niezwiązanej z preferencją. Korekta realizacji zakłada ponadto, że osoby bez odpowiedzi mają w obrębie zmiany podobne preferencje do uczestników. [Statistics Canada, *Survey Methods and Practices*, rozdz. 6](https://www150.statcan.gc.ca/n1/en/pub/12-587-x/12-587-x2003001-eng.pdf)

## Obliczenie wariancji

Dla jednej opcji `p` oznacza oszacowany udział w skali od 0 do 1, a `X` ważoną liczbę ważnych wskazań w całym badaniu. Dla osoby z ukończoną ankietą zmienna zlinearyzowana wynosi `z = I(wskazano tę opcję) − p × I(wskazanie ważne)`. W efekcie odpowiedź na inną ważną opcję i odpowiedź spoza mianownika mają różne wartości. Wariancję próbkową `s²(z)` wtyczka odtwarza z trzech liczników. [Metoda linearyzacji w badaniach wielostopniowych](https://r-survey.r-forge.r-project.org/pkgdown/docs/reference/svyrecvar.html)

1. Dla każdej zmiany składnik wariancji sumy ma postać `M² × (1 − m/M) × s²(z)/m`. Suma składników obu zmian daje `vᵢ` obwodu.
2. Dla obwodu wyliczamy `eᵢ = oszacowane głosy na opcję − p × oszacowane głosy ważne`. Obie sumy w obwodzie uwzględniają wagi zmian.
3. W warstwie z częściowym doborem obwodów składnik międzyobwodowy wynosi `N² × (1 − n/N) × s²(eᵢ)/n`. W warstwie obejmującej wszystkie obwody ten składnik jest zerowy. Do każdej warstwy dodajemy `(N/n) × suma(vᵢ)` dla wylosowanych obwodów.
4. Suma po warstwach podzielona przez `X²` jest oszacowaniem wariancji udziału. Dla udziału wewnątrz przedziału (0, 1) przeliczamy błąd standardowy na skalę logitu przez podzielenie go przez `p × (1 − p)`. Granice wyznaczamy rozkładem t Studenta, następnie odwrotnie przekształcamy je na procenty. Każda opcja ma własny przedział marginalny. Panel zaokrągla dolną granicę w dół i górną w górę do 0,1 punktu procentowego. W walidacji sprawdzamy granice obliczone z pełną precyzją. [Przedziały dla proporcji w badaniach reprezentacyjnych](https://r-survey.r-forge.r-project.org/pkgdown/docs/reference/svyciprop.html)

Jeżeli losowano część obwodów, liczba stopni swobody wynosi sumę `n − 1` po takich warstwach. Gdy objęto wszystkie obwody, stopnie swobody są przybliżone metodą Satterthwaite’a na podstawie dodatnich składników wariancji zmian i liczebności ukończonych ankiet. Przy małej liczbie obwodów stopnie swobody mogą być niskie nawet po zebraniu wielu wywiadów.

## Kiedy przedział jest dostępny

- W każdej warstwie z częściowym doborem potrzeba co najmniej dwóch wylosowanych obwodów. Jeden obwód wystarcza na pierwszym etapie, jeśli jest jedynym w warstwie.
- Do oszacowania zmienności zmiany przy częściowym doborze osób potrzeba co najmniej dwóch ukończonych ankiet. Braki realizacji i progi poufności podlegają dotychczasowym regułom całego raportu.
- Gdy obserwacje dają wyłącznie 0% lub 100%, logit jest nieokreślony. Gdy przy częściowym doborze oszacowana wariancja jest zerowa, raport podaje przyczynę braku przedziału. Przy pełnym zliczeniu wszystkich obwodów i osób bez zgłoszonych przerw i odmów raport oznacza pełne zliczenie wskazań w operacie.
- Przedziały dotyczą zamrożonego exit poll. Późniejsze zastępowanie wybranych obwodów protokołami ma własny mechanizm spływu danych, dlatego late poll przedstawia udziały punktowe.

Przedział opisuje niepewność doboru w ramach przyjętych założeń. Pominięcie lokali, odmowy zależne od preferencji, błędne deklaracje lub powtarzalny rytm wychodzenia mogą obciążyć wynik nawet przy dużej próbie.
